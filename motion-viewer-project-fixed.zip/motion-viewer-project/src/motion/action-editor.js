/* ------------------------------------------------------------------ "+ Action" sheet */
const TEMPLATE = `registerAction({
  name: "Nod",
  category: "Custom",
  aliases: ["nod"],
  update(c, t, dt) {
    c.arm('Left', 0, 1.36, 0.15);
    c.arm('Right', 0, 1.36, 0.15);
    c.head(0.28 * Math.sin(t * 3), 0);
    c.torso(0.03, 0);
  }
});`;
const DSL_TEMPLATE = JSON.stringify({
  name:'RunToTired',
  category:'Custom',
  steps:[
    { command:'run', duration:4, action:'Run' },
    { command:'transitionTo', duration:1.2, fromAction:'Run', targetPose:'tiredPose', options:{ hipDrop:0.12, hipBack:0.05, kneeBend:70, torsoLean:70, headDown:10, feetSpread:0.14 } },
    { command:'tiredPose', duration:4.8, options:{ hipDrop:0.12, hipBack:0.05, kneeBend:70, torsoLean:70, headDown:10, feetSpread:0.14, breathingIntensity:0.8 } },
    { command:'pant', duration:2, options:{ intensity:0.8, basePose:{ hipDrop:0.12, hipBack:0.05, kneeBend:70, torsoLean:70, headDown:10, feetSpread:0.14 } } },
  ],
}, null, 2);
let actionEditorMode = 'javascript';
const dslCode = $('#dslCode');
function setActionEditorMode(mode){
  actionEditorMode = mode === 'dsl' ? 'dsl' : 'javascript';
  $('#code').hidden = actionEditorMode !== 'javascript';
  dslCode.hidden = actionEditorMode !== 'dsl';
  document.querySelectorAll('[data-action-mode]').forEach(button=>button.setAttribute('aria-pressed', String(button.dataset.actionMode === actionEditorMode)));
}
function renderMine(){
  el.mine.textContent = '';
  for(const e of custom){
    const row = document.createElement('div'); row.className = 'item';
    const s = document.createElement('span'); s.textContent = 'Saved: ' + e.names.join(', ');
    const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Remove';
    b.addEventListener('click', ()=>{
      e.names.forEach(n=>{ const a = actions.get(n); if(a && !a.builtin) actions.delete(n); });
      custom = custom.filter(x=>x!==e); persistCustom();
      if(current && !actions.has(current.name)) selectAction('T-pose');
      buildChips(); syncUI(); renderMine();
    });
    row.append(s, b); el.mine.appendChild(row);
  }
}
function openSheet(){
  el.err.textContent = '';
  if(!el.code.value.trim()) el.code.value = TEMPLATE;
  if(!dslCode.value.trim()) dslCode.value = DSL_TEMPLATE;
  setActionEditorMode(actionEditorMode);
  renderMine(); el.sheetWrap.hidden = false;
}
function closeSheet(){ el.sheetWrap.hidden = true; }
$('#addBtn').addEventListener('click', openSheet);
$('#closeSheet').addEventListener('click', closeSheet);
document.querySelectorAll('[data-action-mode]').forEach(button=>button.addEventListener('click', ()=>setActionEditorMode(button.dataset.actionMode)));
el.sheetWrap.addEventListener('pointerdown', e=>{ if(e.target === el.sheetWrap) closeSheet(); });
$('#saveAct').addEventListener('click', ()=>{
  const code = actionEditorMode === 'dsl' ? dslCode.value : el.code.value; el.err.textContent = '';
  const names = [], prev = new Map();
  try{
    if(actionEditorMode === 'dsl'){
      const action = window.actionCompiler.compile(code);
      if(actions.has(action.name) && actions.get(action.name).builtin) throw new Error('"' + action.name + '" is a built-in action. Pick another name.');
      if(actions.has(action.name)) prev.set(action.name, actions.get(action.name));
      registerAction(action, false); names.push(action.name);
    } else {
      new Function('registerAction', code)(def=>{
        if(def && actions.has(def.name) && actions.get(def.name).builtin) throw new Error('"' + def.name + '" is a built-in action. Pick another name.');
        if(def && actions.has(def.name)) prev.set(def.name, actions.get(def.name));
        registerAction(def, false); names.push(def.name);
      });
      if(!names.length) throw new Error('Nothing was registered. Your code must call registerAction({ ... }).');
    }
    if(rig){                                           // dry run so a broken action never reaches the character
      for(const n of names){ ctrl._d = {}; ctrl.lift = 0; actions.get(n).update(ctrl, 0.3, 0.016); }
      ctrl._d = {}; ctrl.lift = 0;
    }
  }catch(e){
    names.forEach(n=>{ if(prev.has(n)) actions.set(n, prev.get(n)); else actions.delete(n); });
    el.err.textContent = (e && e.name === 'EvalError')
      ? 'This page does not allow pasted code to run here (browser security policy).'
      : 'Error: ' + (e.message||e);
    return;
  }
  custom = custom.filter(x=>!x.names.some(n=>names.includes(n)));
  custom.push({ code, names, type:actionEditorMode === 'dsl' ? 'dsl' : 'javascript' }); persistCustom();
  buildChips(); selectAction(names[0]); closeSheet();
  toast('Added "' + names[0] + '". Tap it any time.');
});

/* ------------------------------------------------------------------ delete a custom action */
// Only actions made from Action Code. Built-in actions and imported clips are never touched.
function deleteCustom(name){
  const a = actions.get(name);
  if(!a || a.builtin || a.imported) return;
  actions.delete(name);
  for(const e of custom.slice()){
    if(!e.names.includes(name)) continue;
    e.names = e.names.filter(n=>n !== name);
    if(!e.names.length) custom = custom.filter(x=>x !== e);          // last action of this code: the saved code goes too
    else e.skip = (e.skip || []).concat(name);                       // same code also makes other actions: keep it, but never bring this one back
  }
  persistCustom();
  if(current === a) selectAction('T-pose');
  buildChips(); syncUI(); renderMine();
}
const confirmWrap = $('#confirmWrap'); let pendingDelete = null;
function askDelete(name){
  pendingDelete = name; $('#confirmText').textContent = 'Delete "' + name + '"?';
  confirmWrap.hidden = false; $('#confirmCancel').focus();
}
function closeConfirm(){ pendingDelete = null; confirmWrap.hidden = true; }
$('#confirmCancel').addEventListener('click', closeConfirm);
$('#confirmOk').addEventListener('click', ()=>{ const n = pendingDelete; closeConfirm(); if(n){ deleteCustom(n); toast('Deleted "' + n + '".'); } });
confirmWrap.addEventListener('pointerdown', e=>{ if(e.target === confirmWrap) closeConfirm(); });
window.addEventListener('keydown', e=>{ if(e.key === 'Escape' && !confirmWrap.hidden) closeConfirm(); });

