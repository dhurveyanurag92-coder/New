# Motion

Playback, action registry, custom-action persistence, pose overrides, and pose editing live here. Each built-in motion owns a folder under `motions/<name>/`; edit its `motion.js` to change only that action. Character bone-name normalization and Mixamo rig construction live in `../character/skeleton-map.js` and `../character/rig-setup.js`.

To add a motion, create `motions/<name>/motion.js` and register it with `reg({...})`. `build.py` discovers those modules automatically, so no existing motion or build manifest entry needs editing. Keep configuration/data files in that folder only when they have a separate responsibility. Do not place viewer camera directions here: Front/Back/Left/Right are viewer camera presets, not separate motion implementations. Shared sampling/formatting stays in `core/motion-data/`.
