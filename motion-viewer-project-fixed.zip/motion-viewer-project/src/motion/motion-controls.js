/* ------------------------------------------------------------------ playback state */
window.motionRuntime = {
  getModel: () => model,
  getCurrent: () => current,
  getActions: () => [...actions.values()],
  hasAction: name => actions.has(name),
  selectAction,
  getTime: () => t,
  setTime: value => { t = value; },
  getActionDuration: actionDuration,
  getPlaybackTime: playbackTime,
  getLooping: () => loopPlayback,
  setLooping: setPlaybackLoop,
  seekPlayback,
  resetPlayback,
  withAction(action, callback){
    const previous = current;
    current = action;
    try{ return callback(); }
    finally{ current = previous; }
  },
  evaluatePose: (time, delta) => evalPose(time, delta),
  restoreBind: () => restoreBind(),
  getHolder: () => holder,
  getMixer: () => mixer,
  getActiveAction: () => activeAct,
  getRig: () => rig
};
function buildChips(){
  el.chips.textContent = '';
  const cats = new Map();
  for(const a of actions.values()){ if(!cats.has(a.category)) cats.set(a.category, []); cats.get(a.category).push(a); }
  const names = [...cats.keys()].sort((a,b)=>{ const ia = CAT_ORDER.indexOf(a), ib = CAT_ORDER.indexOf(b); return (ia<0?99:ia)-(ib<0?99:ib); });
  for(const cat of names){
    const g = document.createElement('div'); g.className = 'grp';
    const l = document.createElement('div'); l.className = 'cat'; l.textContent = cat; g.appendChild(l);
    const row = document.createElement('div'); row.className = 'chs'; g.appendChild(row);
    for(const a of cats.get(cat)){
      const w = document.createElement('div'); w.className = 'chipw';
      const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = a.name;
      b.dataset.name = a.name; b.setAttribute('aria-pressed', String(a === current));
      b.addEventListener('click', ()=>selectAction(a.name));
      w.appendChild(b);
      if(!a.builtin && !a.imported){                     // only actions made from Action Code can be deleted
        w.classList.add('has-del');
        const d = document.createElement('button'); d.type = 'button'; d.className = 'del';
        d.setAttribute('aria-label', 'Delete ' + a.name); d.title = 'Delete';
        d.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 10v6M14 10v6"/></svg>';
        d.addEventListener('click', e=>{ e.stopPropagation(); askDelete(a.name); });
        w.appendChild(d);
      }
      row.appendChild(w);
    }
    el.chips.appendChild(g);
  }
    buildMotionPicker();
}
function syncUI(){
  el.play.textContent = playing ? 'Pause' : 'Play';
  for(const b of el.chips.querySelectorAll('.chip')){
    const on = actions.get(b.dataset.name) === current;
    b.setAttribute('aria-pressed', String(on)); b.parentNode.classList.toggle('on', on);
  }
  syncPlaybackUI();
}
function selectAction(name){
  const a = actions.get(name); if(!a) return;
  const holder=window.motionRuntime.getHolder();
  if(current&&current.learnedMotion){
    if(current.motionRootOrigin) holder.position.copy(current.motionRootOrigin);
    if(current.motionRootRotation) holder.quaternion.copy(current.motionRootRotation);
  }
  beginPoseTransition();
  current = a; t = 0; playing = (name !== 'T-pose');
  if(a.learnedMotion){
    a.motionRootOrigin=holder.position.clone();
    a.motionRootRotation=holder.quaternion.clone();
  }
  if(a.imported) startImported(a);                    // original AnimationClip via AnimationMixer
  else { stopImported(); evalPose(0, 0); }            // procedural action
  syncUI();
}
function playbackTime(){
  if(current && current.imported && activeAct) return activeAct.time;
  const duration = actionDuration(current);
  return duration > 0 ? ((t % duration) + duration) % duration : 0;
}
function formatPlaybackTime(value){
  const seconds = Math.max(0, Number(value) || 0);
  return Math.floor(seconds / 60) + ':' + String(Math.floor(seconds % 60)).padStart(2, '0');
}
function syncPlaybackUI(){
  if(!el.motionTimeline) return;
  const duration = Math.max(0.01, actionDuration(current));
  const time = Math.min(duration, playbackTime());
  el.motionTimeline.max = String(duration);
  if(document.activeElement !== el.motionTimeline) el.motionTimeline.value = String(time);
  el.motionTimeline.disabled = !current;
  el.motionTime.textContent = formatPlaybackTime(time) + ' / ' + formatPlaybackTime(duration);
  el.motionLoop.setAttribute('aria-pressed', String(loopPlayback));
  el.motionLoop.disabled = !(current && current.imported);
}
function setPlaybackLoop(value){
  loopPlayback = !!value;
  if(activeAct && current && current.imported){
    activeAct.setLoop(loopPlayback ? THREE.LoopRepeat : THREE.LoopOnce, loopPlayback ? Infinity : 1);
    activeAct.clampWhenFinished = !loopPlayback;
    if(loopPlayback && activeAct.time >= current.clip.duration){
      window.characterRuntime.resetImportedRootMotion(current);
      activeAct.reset();
      activeAct.play();
      if(mixer) mixer.update(0);
    }
  }
  syncPlaybackUI();
}
function seekPlayback(value){
  if(!current) return;
  const duration = actionDuration(current);
  const time = Math.max(0, Math.min(duration, Number(value) || 0));
  if(current.imported && activeAct && mixer){
    window.characterRuntime.resetImportedRootMotion(current);
    activeAct.enabled = true;
    activeAct.paused = false;
    activeAct.play();
    activeAct.time = time;
    mixer.update(0);
  }else{
    t = time;
    if(rig) evalPose(t, 0);
  }
  syncPlaybackUI();
}
function resetPlayback(){
  playing = false;
  t = 0;
  if(current && current.imported && activeAct && mixer){
    window.characterRuntime.resetImportedRootMotion(current);
    activeAct.enabled = true;
    activeAct.paused = false;
    activeAct.setLoop(loopPlayback ? THREE.LoopRepeat : THREE.LoopOnce, loopPlayback ? Infinity : 1);
    activeAct.clampWhenFinished = !loopPlayback;
    activeAct.reset();
    activeAct.play();
    mixer.update(0);
  }else if(rig) evalPose(0, 0);
  syncUI();
}
function buildMotionPicker(){
  if(!el.motionList) return;
  el.motionList.textContent = '';
  const categories = new Map();
  for(const action of actions.values()){
    if(!categories.has(action.category)) categories.set(action.category, []);
    categories.get(action.category).push(action);
  }
  for(const [category, entries] of categories){
    const group = document.createElement('section');
    group.className = 'motion-list-group';
    const heading = document.createElement('div');
    heading.className = 'motion-list-heading';
    heading.textContent = category;
    group.appendChild(heading);
    for(const action of entries){
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'motion-list-button';
      button.textContent = action.name;
      button.setAttribute('aria-pressed', String(action === current));
      button.addEventListener('click', ()=>{
        selectAction(action.name);
        closeMotionPicker();
      });
      group.appendChild(button);
    }
    el.motionList.appendChild(group);
  }
  if(!categories.size){
    const empty = document.createElement('p');
    empty.className = 'motion-list-empty';
    empty.textContent = 'No motions are available.';
    el.motionList.appendChild(empty);
  }
}
function openMotionPicker(){
  buildMotionPicker();
  el.motionPicker.hidden = false;
  el.motionsBtn.setAttribute('aria-expanded', 'true');
  const selected = el.motionList.querySelector('[aria-pressed="true"]') || el.motionList.querySelector('button');
  if(selected) selected.focus({ preventScroll:true });
}
function closeMotionPicker(){
  el.motionPicker.hidden = true;
  el.motionsBtn.setAttribute('aria-expanded', 'false');
  el.motionsBtn.focus({ preventScroll:true });
}
el.motionsBtn.addEventListener('click', openMotionPicker);
el.closeMotionPicker.addEventListener('click', closeMotionPicker);
el.motionPicker.addEventListener('pointerdown', event=>{ if(event.target === el.motionPicker) closeMotionPicker(); });
el.motionLoop.addEventListener('click', ()=>setPlaybackLoop(!loopPlayback));
el.motionTimeline.addEventListener('input', ()=>seekPlayback(parseFloat(el.motionTimeline.value)));
el.motionReset.addEventListener('click', resetPlayback);
window.addEventListener('keydown', event=>{ if(event.key === 'Escape' && !el.motionPicker.hidden) closeMotionPicker(); });
el.play.addEventListener('click', ()=>{
  if(current && current.name === 'T-pose'){ toast('Pick a movement first, then Play and Pause work on it.'); return; }
  if(!playing && current && current.imported && activeAct && activeAct.time >= current.clip.duration){
    window.characterRuntime.resetImportedRootMotion(current);
    activeAct.reset();
    activeAct.play();
    if(mixer) mixer.update(0);
  }
  playing = !playing; syncUI();
});
el.speed.addEventListener('input', ()=>{ speed = parseFloat(el.speed.value); el.spv.textContent = speed.toFixed(2).replace(/0$/,'') + '×'; });
window.addEventListener('keydown', e=>{
  if(e.code === 'Space' && $('#confirmWrap').hidden && !/^(TEXTAREA|INPUT)$/.test((e.target||{}).tagName||'')){ e.preventDefault(); el.play.click(); }
});

