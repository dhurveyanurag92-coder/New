/* ------------------------------------------------------------------ action registry */
const actions = new Map();
const CAT_ORDER = ['Basic','Locomotion','Air','Hands','Imported','Custom'];
function registerAction(def, builtin){
  if(!def || typeof def.name !== 'string' || typeof def.update !== 'function')
    throw new Error('An action needs a name and an update(c, t, dt) function.');
  def.category = def.category || 'Custom';
  def.builtin = !!builtin;
  actions.set(def.name, def);
}
const reg = def => registerAction(def, true);

