/* ------------------------------------------------------------------ Pose Edit: per-action, per-bone, per-frame
   Rotation corrections dialled in by hand and saved as keys: { action: { bone: [ {t, d:[x,y,z]} ] } }.
   The interpolated delta is added on top of the bone's normal rotation each frame, so it also keeps
   tracking a moving IK target (e.g. handsOnKnees). */
const OV_KEY = 'motion_viewer_pose_overrides_v1';
let poseOverrides = {};                              // { [actionName]: { [boneName]: [ {t seconds, d:[dx,dy,dz] radians} ] } }
function loadOverrides(){
  try{ const raw = localStorage.getItem(OV_KEY); poseOverrides = raw ? JSON.parse(raw) : {}; }
  catch(e){ poseOverrides = {}; }
  if(!poseOverrides || typeof poseOverrides !== 'object') poseOverrides = {};
  for(const act in poseOverrides){                    // drop anything not in the keyframe format
    const ov = poseOverrides[act];
    if(!ov || typeof ov !== 'object'){ delete poseOverrides[act]; continue; }
    for(const b in ov){ if(!Array.isArray(ov[b]) || !ov[b].every(k=>k && typeof k.t==='number' && Array.isArray(k.d))) delete ov[b]; }
  }
}
function persistOverrides(){
  try{ localStorage.setItem(OV_KEY, JSON.stringify(poseOverrides)); }
  catch(e){ toast('Save nahi ho paya is browser me.', 4500); }
}
const OV_DUR = { Idle:3.93, Walk:1.05, Run:0.69, Tired:12, Jump:1.6 };   // one loop of each built-in, seconds
const OV_FPS = 30, OV_RAMP = 0.6;                    // frame grid, and how long a lone key takes to fade back to 0
function actionDuration(a){ return (a && (OV_DUR[a.name] || a.duration)) || 2; }
function wrapT(x){ const d = actionDuration(current); return ((x % d) + d) % d; }
function boneCurve(list, u){                         // list = [{t, d:[x,y,z]}] sorted by t  ->  rotation delta at time u
  if(!list || !list.length) return [0,0,0];
  const f = list[0], l = list[list.length-1];
  if(u <= f.t){ const w = Math.max(0, 1-(f.t-u)/OV_RAMP); return f.d.map(v=>v*w); }
  if(u >= l.t){ const w = Math.max(0, 1-(u-l.t)/OV_RAMP); return l.d.map(v=>v*w); }
  for(let i=0;i<list.length-1;i++){
    const a = list[i], b = list[i+1];
    if(u <= b.t){ const k = (u-a.t)/(b.t-a.t || 1); return a.d.map((v,j)=>v+(b.d[j]-v)*k); }
  }
  return l.d.slice();
}
function applyOverridesToPose(time){
  const ov = poseOverrides[current && current.name];
  if(!ov) return;
  const u = wrapT(time || 0);
  for(const bone in ov){
    const d = boneCurve(ov[bone], u);
    const base = ctrl._d[bone] || [0,0,0];
    ctrl.set(bone, base[0]+d[0], base[1]+d[1], base[2]+d[2]);
  }
}

