/* user (pasted) actions, kept in this browser */
const LS_KEY = 'motion_viewer_actions_v1';
let custom = [];                                   // [{code, names:[...]}]
function loadCustom(){
  try{ const raw = localStorage.getItem(LS_KEY); custom = raw ? JSON.parse(raw) : []; }catch(e){ custom = []; }
  custom = custom.filter(e => e && typeof e.code === 'string' && Array.isArray(e.names));
  for(const e of custom){
    const skip = Array.isArray(e.skip) ? e.skip : [];   // actions of this code that were deleted
    try{
      if(e.type === 'dsl'){
        const action = window.actionCompiler.compile(e.code);
        if(!skip.includes(action.name)) registerAction(action, false);
      } else {
        new Function('registerAction', e.code)(def => { if(def && skip.includes(def.name)) return; registerAction(def, false); });
      }
    }
    catch(err){ console.warn('Saved action failed to load', err); }
  }
}
function persistCustom(){
  try{ localStorage.setItem(LS_KEY, JSON.stringify(custom)); }
  catch(e){ toast('Could not save in this browser, the action will be gone after reload.', 4500); }
}

