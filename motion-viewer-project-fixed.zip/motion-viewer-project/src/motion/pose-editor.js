/* ------------------------------------------------------------------ Pose Edit panel UI
   Frame by frame: scrub to a frame, pick a joint, nudge it with -/+. That makes a "key" for that joint
   at that frame; between keys the joint eases smoothly, and a lone key fades out over ~0.6s each side.
   Character stays visible above the panel the whole time. */
const EDITABLE_BONES = [
  { key:'Head', label:'Sar (Head)', group:'head' }, { key:'Neck', label:'Gardan (Neck)', group:'head' },
  { key:'Spine2', label:'Upar ki kamar', group:'spine' }, { key:'Spine1', label:'Beech ki kamar', group:'spine' }, { key:'Spine', label:'Neeche ki kamar', group:'spine' },
  { key:'Hips', label:'Hips', group:'hips' },
  { key:'LeftShoulder', label:'L Shoulder', group:'arm' }, { key:'LeftArm', label:'L Upper Arm', group:'arm' }, { key:'LeftForeArm', label:'L Forearm', group:'arm' }, { key:'LeftHand', label:'L Hand', group:'arm' },
  { key:'RightShoulder', label:'R Shoulder', group:'arm' }, { key:'RightArm', label:'R Upper Arm', group:'arm' }, { key:'RightForeArm', label:'R Forearm', group:'arm' }, { key:'RightHand', label:'R Hand', group:'arm' },
  { key:'LeftUpLeg', label:'L Thigh', group:'leg' }, { key:'LeftLeg', label:'L Shin', group:'leg' }, { key:'LeftFoot', label:'L Foot', group:'leg' },
  { key:'RightUpLeg', label:'R Thigh', group:'leg' }, { key:'RightLeg', label:'R Shin', group:'leg' }, { key:'RightFoot', label:'R Foot', group:'leg' }
];
const EDIT_GROUP_LABEL = { arm:'Haath', leg:'Taang', spine:'Kamar', hips:'Hips', head:'Sar' };
const EDIT_GROUP_ORDER = ['arm','leg','spine','hips','head'];
const AXIS_LABELS = {
  arm:  ['Aage ⇄ Peeche', 'Ghumao (twist)', 'Upar ⇄ Neeche'],
  leg:  ['Aage ⇄ Peeche', 'Ghumao (twist)', 'Andar ⇄ Bahar'],
  spine:['Aage ⇄ Peeche jhuko', 'Ghumao (twist)', 'Side jhukao'],
  hips: ['Aage ⇄ Peeche', 'Ghumao (twist)', 'Side'],
  head: ['Upar ⇄ Neeche dekho', 'Left ⇄ Right dekho', 'Tilt']
};
const DEG = Math.PI/180, EDIT_LIMIT = Math.PI;
let editStepDeg = 5, editGroup = 'arm', editBone = null, editSavedSnapshot = null;

const editableBonesForRig = () => EDITABLE_BONES.filter(b => rig && rig.rest[b.key]);
const boneInfo = key => EDITABLE_BONES.find(x=>x.key===key) || { key, label:key, group:'arm' };
const frameT = x => Math.round(wrapT(x)*OV_FPS)/OV_FPS;
const hasEdit = key => { const l = poseOverrides[current.name] && poseOverrides[current.name][key]; return !!(l && l.length); };

function renderEditGroups(){
  el.editGroupChips.textContent = '';
  const have = new Set(editableBonesForRig().map(b=>b.group));
  for(const g of EDIT_GROUP_ORDER){
    if(!have.has(g)) continue;
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'chip';
    btn.textContent = EDIT_GROUP_LABEL[g]; btn.setAttribute('aria-pressed', String(editGroup === g));
    btn.addEventListener('click', ()=>{ editGroup = g; editBone = null; el.editControls.hidden = true; renderEditGroups(); renderEditBones(); });
    el.editGroupChips.appendChild(btn);
  }
}
function renderEditBones(){
  el.editBoneChips.textContent = '';
  for(const b of editableBonesForRig().filter(b=>b.group === editGroup)){
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'chip';
    btn.textContent = b.label; btn.setAttribute('aria-pressed', String(editBone === b.key));
    if(hasEdit(b.key)) btn.classList.add('edited');
    btn.addEventListener('click', ()=>selectEditBone(b.key));
    el.editBoneChips.appendChild(btn);
  }
}
function renderSteps(){
  el.stepChips.textContent = '';
  const cap = document.createElement('span'); cap.className = 'axisLabel'; cap.style.fontSize = '12px'; cap.textContent = 'Ek tap =';
  el.stepChips.appendChild(cap);
  for(const d of [1,5,15]){
    const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = d + '°';
    b.setAttribute('aria-pressed', String(editStepDeg === d));
    b.addEventListener('click', ()=>{ editStepDeg = d; renderSteps(); });
    el.stepChips.appendChild(b);
  }
}
function selectEditBone(key){
  editBone = key; editGroup = boneInfo(key).group;
  renderEditGroups(); renderEditBones();
  el.editControls.hidden = false; el.editBoneName.textContent = boneInfo(key).label;
  renderSteps(); renderEditAxes(); renderEditKeys();
}
function boneDeltaNow(key){ const ov = poseOverrides[current.name]; return boneCurve(ov && ov[key], frameT(t)); }
function setKey(bone, u, d){
  const ov = poseOverrides[current.name] || (poseOverrides[current.name] = {});
  const list = ov[bone] || (ov[bone] = []);
  const i = list.findIndex(k=>Math.abs(k.t-u) < 0.5/OV_FPS);
  if(i >= 0) list[i].d = d.slice(); else { list.push({ t:u, d:d.slice() }); list.sort((a,b)=>a.t-b.t); }
}
function renderEditAxes(){
  el.editAxes.textContent = '';
  const labels = AXIS_LABELS[boneInfo(editBone).group];
  const d = boneDeltaNow(editBone);
  labels.forEach((label, i)=>{
    const row = document.createElement('div'); row.className = 'axisRow';
    const lab = document.createElement('div'); lab.className = 'axisLabel'; lab.textContent = label;
    const minus = document.createElement('button'); minus.type = 'button'; minus.className = 'axisBtn'; minus.textContent = '−';
    const val = document.createElement('div'); val.className = 'axisVal';
    const plus = document.createElement('button'); plus.type = 'button'; plus.className = 'axisBtn'; plus.textContent = '+';
    const show = ()=>{ val.textContent = Math.round(d[i]/DEG) + '°'; };
    const nudge = sign=>{ d[i] = clampN(d[i] + sign*editStepDeg*DEG, -EDIT_LIMIT, EDIT_LIMIT); setKey(editBone, frameT(t), d); refreshEditPreview(); show(); renderEditKeys(); renderEditBones(); };
    show();
    minus.addEventListener('click', ()=>nudge(-1)); plus.addEventListener('click', ()=>nudge(1));
    row.append(lab, minus, val, plus); el.editAxes.appendChild(row);
  });
}
function renderEditKeys(){
  el.editKeys.textContent = '';
  const list = (poseOverrides[current.name] && poseOverrides[current.name][editBone]) || [];
  const cap = document.createElement('span'); cap.className = 'axisLabel'; cap.style.fontSize = '12px';
  cap.textContent = list.length ? 'Is joint ke keys (tap = wahan jao):' : 'Is joint par abhi koi edit nahi.';
  el.editKeys.appendChild(cap);
  for(const k of list){
    const b = document.createElement('button'); b.type = 'button'; b.className = 'chip';
    b.textContent = Math.round(k.t*OV_FPS) + 'f'; b.setAttribute('aria-pressed', String(Math.abs(k.t-frameT(t)) < 0.5/OV_FPS));
    b.addEventListener('click', ()=>setEditTime(k.t));
    el.editKeys.appendChild(b);
  }
}
function syncEditClock(){
  const dur = actionDuration(current), u = wrapT(t);
  el.frameSlider.max = String(dur); el.frameSlider.value = String(u);
  el.frameLabel.textContent = 'Frame ' + Math.round(u*OV_FPS) + ' / ' + Math.round(dur*OV_FPS) + '  ·  ' + u.toFixed(2) + 's';
}
function refreshEditPreview(){ if(rig && current && !current.imported) evalPose(t, 0); }
function setEditTime(x){
  playing = false; el.previewBtn.textContent = '▶ Chalao';
  t = frameT(x); refreshEditPreview(); syncEditClock();
  if(editBone){ renderEditAxes(); renderEditKeys(); }
}
function openEdit(){
  if(!current || current.name === 'T-pose'){ toast('Pehle ek movement chuno (Run, Walk, Tired...), fir Edit karo.'); return; }
  if(current.imported){ toast('Imported animation ko is tarah edit nahi kar sakte — sirf code-wale movements edit hote hain.'); return; }
  if(!rig){ toast('Character abhi load nahi hua.'); return; }
  playing = false; syncUI();
  editSavedSnapshot = poseOverrides[current.name] ? JSON.parse(JSON.stringify(poseOverrides[current.name])) : null;
  editBone = null; editGroup = 'arm'; el.editControls.hidden = true;
  el.editActionName.textContent = current.name; el.previewBtn.textContent = '▶ Chalao';
  renderEditGroups(); renderEditBones();
  el.editWrap.hidden = false; el.editBtn.setAttribute('aria-pressed','true');
  setEditTime(t);
}
function closeEdit(discard){
  playing = false;
  if(discard){
    if(editSavedSnapshot) poseOverrides[current.name] = editSavedSnapshot; else delete poseOverrides[current.name];
    refreshEditPreview();
  }
  el.editWrap.hidden = true; el.editBtn.setAttribute('aria-pressed','false');
  editBone = null; editSavedSnapshot = null; syncUI();
}
el.editBtn.addEventListener('click', openEdit);
el.closeEdit.addEventListener('click', ()=>closeEdit(true));                 // unsaved changes are dropped
window.addEventListener('keydown', e=>{ if(e.key === 'Escape' && !el.editWrap.hidden) closeEdit(true); });
el.frameSlider.addEventListener('input', ()=>setEditTime(parseFloat(el.frameSlider.value)));
el.fBack.addEventListener('click',  ()=>setEditTime(t - 1/OV_FPS));
el.fFwd.addEventListener('click',   ()=>setEditTime(t + 1/OV_FPS));
el.fBack2.addEventListener('click', ()=>setEditTime(t - 0.5));
el.fFwd2.addEventListener('click',  ()=>setEditTime(t + 0.5));
el.previewBtn.addEventListener('click', ()=>{
  if(playing){ setEditTime(t); return; }
  playing = true; el.previewBtn.textContent = '⏸ Roko';
});
el.deleteKey.addEventListener('click', ()=>{
  const ov = poseOverrides[current.name], list = ov && ov[editBone]; if(!list) return;
  const u = frameT(t), i = list.findIndex(k=>Math.abs(k.t-u) < 0.5/OV_FPS);
  if(i < 0){ toast('Is frame par is joint ki koi key nahi hai.'); return; }
  list.splice(i,1); if(!list.length) delete ov[editBone];
  refreshEditPreview(); renderEditAxes(); renderEditKeys(); renderEditBones();
});
el.resetBone.addEventListener('click', ()=>{
  const ov = poseOverrides[current.name]; if(ov && editBone) delete ov[editBone];
  refreshEditPreview(); renderEditAxes(); renderEditKeys(); renderEditBones();
});
el.clearEditsForAction.addEventListener('click', ()=>{
  delete poseOverrides[current.name];
  refreshEditPreview(); renderEditBones(); if(editBone){ renderEditAxes(); renderEditKeys(); }
  toast('Is movement ke saare edit hata diye (Save dabane tak permanent nahi).');
});
el.saveEdit.addEventListener('click', ()=>{
  const ov = poseOverrides[current.name] || {};
  for(const k in ov){ if(!ov[k].length || ov[k].every(x=>x.d.every(v=>Math.abs(v) < 1e-4))) delete ov[k]; }
  if(Object.keys(ov).length) poseOverrides[current.name] = ov; else delete poseOverrides[current.name];
  persistOverrides();
  editSavedSnapshot = poseOverrides[current.name] ? JSON.parse(JSON.stringify(poseOverrides[current.name])) : null;
  toast('Saved — "' + current.name + '" ki edits yaad rahengi.');
});

