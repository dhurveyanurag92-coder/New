reg({ name:'Wave', category:'Hands', aliases:['wave','hilao'], update(c,t){
  const b = Math.sin(t*1.6);
  c.arm('Left', 0.03*b, 1.36, 0.15);
  c.arm('Right', 0, -1.25, 0);
  c.set('RightForeArm', 0, 0.45, 0.55*Math.sin(t*9));
  c.torso(0.02+0.012*b, 0.04*Math.sin(t*1.1));
  c.head(-0.02, 0.10*Math.sin(t*1.1));
}});