reg({ name:'Run', category:'Locomotion', aliases:['run','daudo'], update(c,t){
  const w = 6.283*1.45*t, sw = Math.sin(w);
  for(const s of ['Left','Right']){
    const ph = w + (s==='Right' ? Math.PI : 0), sn = Math.sin(ph);
    const swing = Math.max(0, Math.cos(ph+0.3));
    c.leg(s, 0.05+0.72*sn, 0.25+1.22*Math.pow(swing,1.3), 0.4*Math.pow(Math.max(0,-Math.sin(ph+0.3)),2));
  }
  const aL = -0.85*sw, aR = 0.85*sw;
  c.arm('Left',  aL, 1.10, 1.30 + 0.35*(aL/0.85));
  c.arm('Right', aR, 1.10, 1.30 + 0.35*(aR/0.85));
  c.torso(0.26, 0.30*sw);
  c.head(-0.20, -0.15*sw);
  c.set('Hips', 0, -0.16*sw, 0);
  c.lift = 0.05*sw*sw;
}});