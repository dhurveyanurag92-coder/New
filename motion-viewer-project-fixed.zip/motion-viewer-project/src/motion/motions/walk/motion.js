reg({ name:'Walk', category:'Locomotion', aliases:['walk','chalo'], update(c,t){
  const w = 6.283*0.95*t, sw = Math.sin(w);
  for(const s of ['Left','Right']){
    const ph = w + (s==='Right' ? Math.PI : 0), sn = Math.sin(ph);
    const swing = Math.max(0, Math.cos(ph+0.25));
    const thigh = 0.09 + 0.35*sn;
    const knee  = 0.07 + 0.95*Math.pow(swing,1.6);
    const foot  = 0.5*Math.pow(Math.max(0,-Math.sin(ph+0.4)),2) - 0.10*Math.pow(Math.max(0,sn),4);
    c.leg(s, thigh, knee, foot);
  }
  const aL = -0.45*sw, aR = 0.45*sw;
  c.arm('Left',  aL, 1.28, 0.25 + 0.5*Math.max(0,aL));
  c.arm('Right', aR, 1.28, 0.25 + 0.5*Math.max(0,aR));
  c.torso(0.06, 0.18*sw);
  c.head(-0.03, -0.10*sw);
  c.set('Hips', 0, -0.10*sw, 0);
}});