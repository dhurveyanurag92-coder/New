/* Part D: Run -> Tired -> Panting. One looped cycle: runs, gets winded, bends over with both
   hands on the knees (via Part C's c.handsOnKnees() — no manual arm angle-guessing), pants there
   for a while, then straightens back up and resumes running. Legs/torso/breathing are plain
   c.leg()/c.torso() key-pose work same as every other action here; only the "hands find the knees"
   part is IK (Part B), which is the whole point of Part B/C existing. */
(function(){
  const T = 12.0;
  const RUN_END = 5.0;
  const BEND_END = 6.1;
  const PANT_END = 10.0;
  const RECOVER_END = 11.4;
  const BEND_THIGH = 0.16, BEND_KNEE = 0.38, BEND_LEAN = 1.30, BEND_HEAD = 0.10;

  reg({ name:'Tired', category:'Locomotion', aliases:['tired','panting','thaka','thak gaya','hanfna','saans'], update(c,t){
    const u = t % T;

    if(u < RUN_END){
      const deceleration = ss((u - (RUN_END-1.8)) / 1.8);
      const phaseProgress = Math.max(0, Math.min(1, (u - (RUN_END-1.8)) / 1.8));
      const phaseCorrection = 1.45 * 1.8 * (phaseProgress ** 3 - 0.5 * phaseProgress ** 4);
      const w = 6.283 * (1.45 * u - phaseCorrection), sw = Math.sin(w);
      for(const s of ['Left','Right']){
        const ph = w + (s==='Right' ? Math.PI : 0), sn = Math.sin(ph);
        const strideScale = 1 - deceleration;
        const swing = Math.max(0, Math.cos(ph+0.3));
        c.leg(s, 0.05+0.72*strideScale*sn, 0.25+1.22*strideScale*Math.pow(swing,1.3), 0.4*strideScale*Math.pow(Math.max(0,-Math.sin(ph+0.3)),2));
      }
      const amp = 0.85 * (1 - deceleration);
      const aL = lerp(-amp*sw, -0.3, deceleration), aR = lerp(amp*sw, 0.3, deceleration);
      c.arm('Left',  aL, lerp(1.10,1.15,deceleration), lerp(1.30 + 0.35*(aL/0.85), 1.0, deceleration));
      c.arm('Right', aR, lerp(1.10,1.15,deceleration), lerp(1.30 + 0.35*(aR/0.85), 1.0, deceleration));
      c.torso(lerp(0.26, 0.55, deceleration), 0.30*sw*(1-0.5*deceleration));
      c.head(lerp(-0.20, -0.05, deceleration), -0.15*sw);
      c.set('Hips', 0, -0.16*sw*(1-deceleration), 0);
      c.lift = 0.05*sw*sw*(1-deceleration);

    } else if(u < BEND_END){
      const k = ss((u-RUN_END)/(BEND_END-RUN_END));
      c.feet.spread(0.14*k); c.feet.grounded(true);
      c.pelvis({ hipDrop:0.12*k, hipBack:0.05*k });
      for(const s of ['Left','Right']) c.leg(s, lerp(0.05,BEND_THIGH,k), lerp(0.25,BEND_KNEE,k), 0);
      c.arm('Left',  lerp(-0.3,0,k), lerp(1.15,0.35,k), lerp(1.0,0.3,k));
      c.arm('Right', lerp( 0.3,0,k), lerp(1.15,0.35,k), lerp(1.0,0.3,k));
      c.torso(lerp(0.55,BEND_LEAN,k), 0);
      c.head(lerp(-0.05,BEND_HEAD,k), 0);
      c.handsOnKnees({ surface:true, heightOffset:0.03, forwardOffset:0.02, outwardOffset:0.02, clearance:0.015, pressure:0.8, weight:k });

    } else if(u < PANT_END){
      c.feet.spread(0.14); c.feet.grounded(true);
      const p = u - BEND_END, breath = Math.sin(p*8.0), slow = Math.sin(p*0.9);
      c.tiredPose({
        hipDrop:0.12,
        hipBack:0.05,
        kneeBend:(BEND_KNEE + 0.06*breath) * 180 / Math.PI,
        torsoLean:(BEND_LEAN + 0.10*breath) * 180 / Math.PI,
        headDown:-(BEND_HEAD + 0.10*breath) * 180 / Math.PI,
        feetSpread:0.14,
        breathingIntensity:0.8,
        time:p + slow,
        handContact:{ surface:true, heightOffset:0.03, forwardOffset:0.02, outwardOffset:0.02, clearance:0.015, pressure:0.8 },
      });

    } else {
      const k = ss((u-PANT_END)/(RECOVER_END-PANT_END));
      c.feet.spread(0.14*(1-k)); c.feet.grounded(true);
      c.pelvis({ hipDrop:0.12*(1-k), hipBack:0.05*(1-k) });
      for(const s of ['Left','Right']) c.leg(s, lerp(BEND_THIGH,0.05,k), lerp(BEND_KNEE,0.25,k), 0);
      c.arm('Left',  0, lerp(0.35,1.10,k), lerp(0.3,1.30,k));
      c.arm('Right', 0, lerp(0.35,1.10,k), lerp(0.3,1.30,k));
      c.torso(lerp(BEND_LEAN,0.26,k), 0);
      c.head(lerp(BEND_HEAD,-0.20,k), 0);
      c.handsOnKnees({ surface:true, heightOffset:0.03, forwardOffset:0.02, outwardOffset:0.02, clearance:0.015, pressure:0.8, weight:1-k });
    }
  }});
})();