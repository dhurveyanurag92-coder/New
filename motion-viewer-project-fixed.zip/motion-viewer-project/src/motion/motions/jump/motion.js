(function(){
  const T = 1.6, G = 9.8, AIR = 0.55, V0 = G*AIR/2;
  reg({ name:'Jump', category:'Air', aliases:['jump','kudo'], update(c,t){
    const u = t % T;
    let crouch = 0, tuck = 0, arm = 0, foot = 0, lift = 0;
    if(u < 0.45){ const k = ss(u/0.45); crouch = k; arm = -0.7*k; }
    else if(u < 0.57){ const k = ss((u-0.45)/0.12); crouch = 1-k; arm = -0.7+2.2*k; foot = 0.5*k; }
    else if(u < 0.57+AIR){
      const tau = u-0.57, p = tau/AIR;
      lift = V0*tau - 0.5*G*tau*tau;
      tuck = Math.sin(Math.PI*p); arm = 1.5-0.5*p; foot = 0.5*(1-p);
    }
    else if(u < 1.37){ const p = (u-1.12)/0.25; crouch = 0.75*Math.sin(Math.PI*p); arm = 1.0-0.9*ss(p); }
    else { arm = 0.1*(1-ss((u-1.37)/0.23)); }
    const thigh = 0.85*crouch + 0.6*tuck, knee = 1.6*crouch + 1.1*tuck;
    c.leg('Left', thigh, knee, foot); c.leg('Right', thigh, knee, foot);
    c.arm('Left', arm, 1.25, 0.3+0.3*Math.abs(arm)); c.arm('Right', arm, 1.25, 0.3+0.3*Math.abs(arm));
    c.torso(0.05+0.42*crouch, 0);
    c.head(-0.35*crouch, 0);
    c.lift = Math.max(0, lift);
  }});
})();