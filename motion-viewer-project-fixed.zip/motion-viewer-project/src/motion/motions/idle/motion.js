reg({ name:'Idle', category:'Basic', aliases:['idle','stand','ruko'], update(c,t){
  const b = Math.sin(t*1.6);
  c.arm('Left', 0.03*b, 1.36, 0.15);
  c.arm('Right',-0.03*b, 1.36, 0.15);
  c.torso(0.02+0.012*b, 0.03*Math.sin(t*0.5));
  c.head(-0.02, 0.15*Math.sin(t*0.4));
}});