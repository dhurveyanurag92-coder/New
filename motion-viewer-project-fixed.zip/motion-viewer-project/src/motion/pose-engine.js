/* ---- pose: every bone = rest rotation + a rotation given in the character's own axes */
function applyPose(){
  for(const k in rig.rest){
    const r = rig.rest[k], d = ctrl._d[k];
    const pelvisRotation = k === 'Hips' ? ctrl._pelvis.rotation : null;
    if(d || pelvisRotation){
      const delta = d ? d.slice() : [0, 0, 0];
      if(pelvisRotation){ delta[0] += pelvisRotation.x; delta[1] += pelvisRotation.y; delta[2] += pelvisRotation.z; }
      const limited = window.jointLimitRuntime.clamp(k, delta);
      _e.set(limited[0], limited[1], limited[2], 'XYZ'); _d.setFromEuler(_e);
      _q.copy(r.PrInv).multiply(_d).multiply(r.Pr).multiply(r.Lr);
      r.bone.quaternion.copy(_q);
    } else r.bone.quaternion.copy(r.Lr);
  }
}
/* ---- Part B: generic 2-bone Arm IK (built once, reused by any "put hand at X" action).
   armToTarget(side, x,y,z, poleHint) points Left/RightArm + Left/RightForeArm at a world-space
   point. Works for ANY target (knee, hip, head, ...) via the same math, and for any imported
   character's own proportions (rig.armLengths from Part A). No hardcoded bone-axis assumptions —
   every direction it needs is measured live off the current rig (same technique as Part A's bone
   lengths), so it is not tied to this one character's bind pose.
   Ordering requirement: call this AFTER c.torso()/c.leg()/etc. in the same update(), so the target
   math sees THIS frame's torso lean, not last frame's (see ctrl.getBoneWorldOrLocal above). */
const POLE_HINTS = {
  'down-out':     (s)=> new THREE.Vector3(s*0.55, -1,    0.35),
  'up-out':       (s)=> new THREE.Vector3(s*0.55,  1,    0.35),
  'straight-out': (s)=> new THREE.Vector3(s*1,    -0.05, 0.15)
};
const clampN = (v,a,b)=>Math.min(b, Math.max(a, v));

// World position + world quaternion of a bone, plus its live parent's world quaternion, using
// whatever ctrl._d holds so far this frame (mid-update-safe, same trick as ctrl.getBoneWorldOrLocal).
function _boneFrame(key){
  const r = rig.rest[key]; if(!r) return null;
  applyPose(); holder.updateMatrixWorld(true);
  const pos = new THREE.Vector3(), quat = new THREE.Quaternion(), parentQuat = new THREE.Quaternion();
  r.bone.getWorldPosition(pos); r.bone.getWorldQuaternion(quat); r.bone.parent.getWorldQuaternion(parentQuat);
  return { pos, quat, parentQuat, r };
}
// B1+B3+B4 math: rotate one bone (whose parent chain is already posed) so it points from its own
// current position toward worldDir. Measures its own "current rest direction" off its live child
// bone (childKey) instead of assuming a fixed local bone axis, so it works on any rig.
function _aimBone(key, childKey, worldDir){
  const f = _boneFrame(key); if(!f || !rig.rest[childKey]) return false;
  applyPose(); holder.updateMatrixWorld(true);                      // re-read after _boneFrame's own applyPose, same frame state
  const childPos = new THREE.Vector3(); rig.rest[childKey].bone.getWorldPosition(childPos);
  const restDir = childPos.sub(f.pos);
  if(restDir.lengthSq() < 1e-10) return false;
  restDir.normalize();
  const swing = new THREE.Quaternion().setFromUnitVectors(restDir, worldDir.clone().normalize());
  const target = swing.multiply(f.quat);                            // world orientation this bone should end up at
  const A = f.parentQuat.clone().multiply(f.r.PrInv);
  const B = f.r.Pr.clone().multiply(f.r.Lr);
  const d = A.invert().multiply(target).multiply(B.invert());       // solve the local delta ctrl.set() expects
  const e = new THREE.Euler().setFromQuaternion(d, 'XYZ');
  ctrl.set(key, e.x, e.y, e.z);
  return true;
}
Object.assign(ctrl, {
  // B4 — the one call every "hand on X" action needs.
  // side: 'Left'/'Right'. x,y,z: world-space target point.
  // poleHint (optional): 'down-out' (default) / 'up-out' / 'straight-out', or a custom {x,y,z}
  // direction (character-local — rotates with the shoulder/torso, not a fixed world direction).
  armToTarget(side, x, y, z, poleHint){
    solveTwoBoneIK({ rootKey:sideName(side)+'Arm', middleKey:sideName(side)+'ForeArm', endKey:sideName(side)+'Hand', lengthsKey:'armLengths', side:sideName(side) }, { x, y, z }, poleHint);
  },
  legToTarget(side, x, y, z, poleHint){
    const normalizedSide = sideName(side);
    solveTwoBoneIK({ rootKey:normalizedSide+'UpLeg', middleKey:normalizedSide+'Leg', endKey:normalizedSide+'Foot', lengthsKey:'legLengths', side:normalizedSide }, { x, y, z }, poleHint);
  },
  target(chain, side, position, options = {}){
    const targetSide = side === 'Left' || side === 'Right' ? side : 'Center';
    queueFullBodyIKTarget({ chain, side:targetSide, position, ...options });
  }
});

/* ---- Part C: convenience wrappers around armToTarget — each one just works out a target point
   and calls c.armToTarget(); no new IK math, so any future "hand on X" pose is just one more small
   function like these. Pick the first bone that actually exists on the rig for reference points
   that aren't in REQUIRED (Spine1/Spine2/Neck/Head), so this still works on leaner Mixamo rigs. */
function _firstBone(keys){ for(const k of keys) if(rig.rest[k]) return k; return null; }
Object.assign(ctrl, {
  // Both hands to the knees. Call after c.leg(...) in the same update() so the knee position
  // reflects this frame's leg pose, not last frame's.
  // Both hands resting on the hips — a point just to the side and slightly forward of Hips,
  // rotating with the hips' own current orientation (torso twist-aware).
  handsOnHips(hint){
    const f = _boneFrame('Hips'); if(!f) return;
    for(const side of ['Left','Right']){
      const s = side==='Left' ? 1 : -1;
      const off = new THREE.Vector3(s*0.13, -0.02, 0.11).applyQuaternion(f.quat);
      const p = f.pos.clone().add(off);
      this.armToTarget(side, p.x, p.y, p.z, hint || 'down-out');
    }
  },
  // One hand to the head/temple area. Defaults to an 'up-out' pole hint since a raised hand
  // naturally leads with the elbow up, unlike a lowered arm.
  handOnHead(side, hint){
    const key = _firstBone(['Head','Neck','Spine2','Spine']); if(!key) return;
    const f = _boneFrame(key); if(!f) return;
    const off = new THREE.Vector3(0, 0.10, 0.03).applyQuaternion(f.quat);
    const p = f.pos.clone().add(off);
    this.armToTarget(sideName(side), p.x, p.y, p.z, hint || 'up-out');
  },
  // Both hands to a common point in front of the chest, with a small left/right offset so the
  // hands don't collide with each other.
  handsTogether(hint){
    const key = _firstBone(['Spine2','Spine1','Spine']); if(!key) return;
    const f = _boneFrame(key); if(!f) return;
    const center = f.pos.clone().add(new THREE.Vector3(0, -0.05, 0.22).applyQuaternion(f.quat));
    for(const side of ['Left','Right']){
      const s = side==='Left' ? 1 : -1;
      const p = center.clone().add(new THREE.Vector3(s*0.05, 0, 0).applyQuaternion(f.quat));
      this.armToTarget(side, p.x, p.y, p.z, hint || 'down-out');
    }
  }
});

function evalPose(time, dt){
  if(!rig || (current && current.imported)) return;
  ctrl._d = {}; ctrl.lift = 0; ctrl._rootMotion=null; beginFullBodyIKFrame(); resetFootGroundingFrame(); resetPelvisFrame(); resetHandContactFrame();
  if(current){
    try{ current.update(ctrl, time, dt); }
    catch(e){
      console.error(e); toast('Action "' + current.name + '" crashed: ' + (e.message||e), 6000);
      current = actions.get('T-pose'); playing = false; ctrl._d = {}; ctrl.lift = 0; syncUI();
    }
  }
  const learnedRoot=ctrl._rootMotion;
  if(learnedRoot){
    const origin=current.motionRootOrigin||new THREE.Vector3();
    const originRotation=current.motionRootRotation||new THREE.Quaternion();
    holder.position.x=origin.x+learnedRoot.position.x;
    holder.position.y=origin.y+learnedRoot.position.y;
    holder.position.z=origin.z+learnedRoot.position.z;
    holder.quaternion.copy(originRotation).multiply(new THREE.Quaternion(...learnedRoot.rotation)).normalize();
  }
  applyPelvisSolver();
  if(ctrl._groundFeet){
    holder.position.y = 0; holder.updateMatrixWorld(true);
    applyPose();
    queueGroundedFootTargets();
    applyBalanceSolver();
    applyPelvisSolver();
    applyPose();
  } else {
    queueGroundedFootTargets();
  }
  solveFullBodyIKTargets();
  applyOverridesToPose(time);
  applyPose();
  holder.position.y = 0; holder.updateMatrixWorld(true);
  const lift = Number.isFinite(ctrl.lift) ? ctrl.lift : 0;
  holder.position.y = rig.restMin - lowestPoint() + lift + (learnedRoot?learnedRoot.position.y:0);     // feet stay on the floor, or leave it by `lift` metres
  if(window.poseValidationRuntime) window.poseValidationRuntime.capture();
}

