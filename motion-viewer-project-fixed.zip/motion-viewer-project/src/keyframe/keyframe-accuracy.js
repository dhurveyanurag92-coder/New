(function(){
  function toFiniteNumber(value, label, frameNumber){
    const num = Number(value);
    if (!Number.isFinite(num)) {
      if (frameNumber === undefined) {
        throw new Error(label + ' must be a finite number.');
      }
      throw new Error('Frame ' + frameNumber + ': Invalid ' + label + '.');
    }
    return num;
  }

  function ensureVector(value, label, frameNumber, count = 3){
    if (!Array.isArray(value) || value.length !== count) {
      if (frameNumber === undefined) {
        throw new Error(label + ' must contain exactly ' + count + ' numeric values.');
      }
      throw new Error('Frame ' + frameNumber + ': Invalid ' + label + '.');
    }
    for (let i = 0; i < value.length; i++) {
      toFiniteNumber(value[i], label + '[' + i + ']', frameNumber);
    }
    return value.map(Number);
  }

  function getRequiredBoneSet(basePose){
    const bones = (basePose && basePose.bones) ? Object.keys(basePose.bones) : [];
    return new Set(bones.filter(Boolean));
  }

  function validateFrameData(frame, requiredBones, options = {}){
    const strict = options.strict !== false;
    const frameNumber = Number(frame && (frame.number !== undefined ? frame.number : frame.frame));
    if (!Number.isInteger(frameNumber) || frameNumber <= 0) {
      throw new Error('Invalid frame number: ' + String(frameNumber || 'unknown'));
    }

    // Frames can be flat ({root, bones}) or stored as {pose:{root, bones}} (importer / timeline format).
    const source = (frame && frame.pose && (frame.pose.bones || frame.pose.root)) ? frame.pose : frame;
    const rootPose = (source && source.root) ? source.root : null;
    if (rootPose) {
      if (rootPose.position) ensureVector(rootPose.position, 'root.position', frameNumber, 3);
      if (rootPose.rotation) ensureVector(rootPose.rotation, 'root.rotation', frameNumber, 3);
    }

    const boneMap = (source && source.bones) ? source.bones : {};
    const missingBones = [];
    requiredBones.forEach(function(name){
      if (!Object.prototype.hasOwnProperty.call(boneMap, name)) {
        missingBones.push(name);
      }
    });

    if (missingBones.length && strict) {
      throw new Error('Frame ' + frameNumber + ': Missing bone: ' + missingBones[0]);
    }

    for (const boneName of Object.keys(boneMap)) {
      const bonePose = boneMap[boneName];
      if (!bonePose || typeof bonePose !== 'object') {
        throw new Error('Frame ' + frameNumber + ': Invalid bone data for ' + boneName + '.');
      }
      if (bonePose.position) ensureVector(bonePose.position, 'bone.position', frameNumber, 3);
      if (bonePose.rotation) ensureVector(bonePose.rotation, 'bone.rotation', frameNumber, 3);
    }

    return {
      frame: frameNumber,
      valid: missingBones.length === 0,
      missingBones,
    };
  }

  function validateFrameSequence(frames, basePose, options = {}){
    const strict = options.strict !== false;
    const requiredBones = getRequiredBoneSet(basePose);
    const normalized = (frames || []).map(function(frame){
      const frameNumber = Number(frame && (frame.number !== undefined ? frame.number : frame.frame));
      const prepared = { ...frame };
      if (prepared && prepared.number === undefined && prepared.frame !== undefined) {
        prepared.number = prepared.frame;
      }
      if (prepared && prepared.frame === undefined && prepared.number !== undefined) {
        prepared.frame = prepared.number;
      }
      if (prepared && !prepared.pose) {
        if (!prepared.bones) prepared.bones = {};
        if (!prepared.root) prepared.root = {};
      }
      validateFrameData(prepared, requiredBones, { strict });
      return prepared;
    }).sort(function(a, b){ return Number(a.number || a.frame) - Number(b.number || b.frame); });

    const seen = new Set();
    const missingFrames = [];
    for (let i = 0; i < normalized.length; i++) {
      const frame = normalized[i];
      const number = Number(frame.number !== undefined ? frame.number : frame.frame);
      if (seen.has(number)) {
        throw new Error('Duplicate frame number: ' + number);
      }
      seen.add(number);
      const expected = i + 1;
      if (number !== expected && strict) {
        missingFrames.push(expected);
      }
    }

    if (missingFrames.length) {
      throw new Error('Frame ' + missingFrames[0] + ' missing or out of sequence.');
    }

    if (Number.isFinite(options.fps) && options.fps <= 0) {
      throw new Error('Invalid FPS: ' + options.fps + '.');
    }

    return {
      valid: true,
      frameCount: normalized.length,
      requiredBones: Array.from(requiredBones),
      strict,
    };
  }

  window.keyframeAccuracy = {
    validateFrameData,
    validateFrameSequence,
    getRequiredBoneSet,
  };
})();
