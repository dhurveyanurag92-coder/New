(function(){
  const STORAGE_KEY = 'motion-viewer-keyframe-project-v1';
  const MOTION_LIBRARY_KEY = 'motion-viewer-keyframe-motions-v1';
  const state = window.keyframePageState;

  function getSelectedFrame(){
    return state.frames.find(frame => frame.number === state.selected) || state.frames[0] || null;
  }

  function getFrameByNumber(number){
    return state.frames.find(frame => frame.number === number) || null;
  }

  function makeEmptyFrame(number, type = 'EMPTY'){
    return {
      number,
      type,
      source: type === 'AUTO' ? 'AUTO' : 'MANUAL',
      pose: null,
      code: '',
      timestamp: Date.now(),
    };
  }

  function snapshotPoseFromModel(number, type = 'KEYFRAME', source = 'MANUAL'){
    const rig = window.motionRuntime && window.motionRuntime.getRig && window.motionRuntime.getRig();
    const holder = window.motionRuntime && window.motionRuntime.getHolder && window.motionRuntime.getHolder();
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry && window.characterRuntime.getSkeletonRegistry();
    const frame = {
      number,
      type,
      source,
      pose: {
        root: {
          position: holder ? [holder.position.x, holder.position.y, holder.position.z] : [0,0,0],
          rotation: holder ? [holder.rotation ? holder.rotation.x : holder.quaternion.x, holder.rotation ? holder.rotation.y : holder.quaternion.y, holder.rotation ? holder.rotation.z : holder.quaternion.z] : [0,0,0],
        },
        bones: {},
      },
      code: '',
      timestamp: Date.now(),
    };
    if (!rig || !rig.rest) return frame;
    const entries = registry && registry.bones ? registry.bones : Object.keys(rig.rest).map(key => ({ originalName: key }));
    for (const record of entries) {
      const name = record.originalName || record.bone && record.bone.name || record.name || '';
      const boneKey = Object.keys(rig.rest).find(key => rig.rest[key] && rig.rest[key].bone && (rig.rest[key].bone.name === name || key === name));
      const boneEntry = boneKey ? rig.rest[boneKey] : null;
      const bone = boneEntry && boneEntry.bone;
      if (!bone) continue;
      const e = new THREE.Euler().setFromQuaternion(bone.quaternion.clone(), 'XYZ');
      frame.pose.bones[name] = {
        position: [bone.position.x, bone.position.y, bone.position.z],
        rotation: [e.x, e.y, e.z],
      };
    }
    return frame;
  }

  function clonePose(pose){
    return JSON.parse(JSON.stringify(pose || { root: { position: [0, 0, 0], rotation: [0, 0, 0] }, bones: {} }));
  }

  function deepMergePose(basePose, patchPose){
    const merged = clonePose(basePose || { root: { position: [0,0,0], rotation: [0,0,0] }, bones: {} });
    if (!patchPose) return merged;
    if (patchPose.root) {
      if (Array.isArray(patchPose.root.position) && patchPose.root.position.length >= 3) merged.root.position = patchPose.root.position.slice(0, 3);
      if (Array.isArray(patchPose.root.rotation) && patchPose.root.rotation.length >= 3) merged.root.rotation = patchPose.root.rotation.slice(0, 3);
    }
    const bones = patchPose.bones || {};
    for (const boneName of Object.keys(bones)) {
      if (!merged.bones[boneName]) merged.bones[boneName] = { position: [0,0,0], rotation: [0,0,0] };
      const incoming = bones[boneName] || {};
      if (Array.isArray(incoming.position) && incoming.position.length >= 3) merged.bones[boneName].position = incoming.position.slice(0, 3);
      if (Array.isArray(incoming.rotation) && incoming.rotation.length >= 3) merged.bones[boneName].rotation = incoming.rotation.slice(0, 3);
    }
    return merged;
  }

  function setHolderFromPose(pose){
    const holder = window.motionRuntime && window.motionRuntime.getHolder && window.motionRuntime.getHolder();
    if (!holder || !pose || !pose.root) return;
    const rootPosition = pose.root.position || [0,0,0];
    const rootRotation = pose.root.rotation || [0,0,0];
    holder.position.set(rootPosition[0], rootPosition[1], rootPosition[2]);
    const euler = new THREE.Euler(rootRotation[0], rootRotation[1], rootRotation[2], 'XYZ');
    holder.quaternion.setFromEuler(euler);
  }

  function applyPoseToRig(pose){
    const rig = window.motionRuntime && window.motionRuntime.getRig && window.motionRuntime.getRig();
    if (!rig || !rig.rest || !pose) return;
    setHolderFromPose(pose);
    for (const key of Object.keys(rig.rest)) {
      const entry = rig.rest[key];
      const bone = entry && entry.bone;
      if (!bone) continue;
      const boneName = bone.name;
      const bonePose = pose.bones && (pose.bones[boneName] || pose.bones[key]);
      if (!bonePose) continue;
      const pos = bonePose.position || [0,0,0];
      const rot = bonePose.rotation || [0,0,0];
      bone.position.set(pos[0], pos[1], pos[2]);
      bone.quaternion.setFromEuler(new THREE.Euler(rot[0], rot[1], rot[2], 'XYZ'));
    }
  }

  function isReferenceFrame(frame){
    return !!frame && frame.type && !['EMPTY'].includes(frame.type);
  }

  function getNeighborFrames(index){
    let previous = null;
    for (let i = index - 1; i >= 0; i--) {
      if (isReferenceFrame(state.frames[i])) { previous = state.frames[i]; break; }
    }
    let next = null;
    for (let i = index + 1; i < state.frames.length; i++) {
      if (isReferenceFrame(state.frames[i])) { next = state.frames[i]; break; }
    }
    return { previous, next };
  }

  function quaternionFromEulerArray(rotation){
    const source = Array.isArray(rotation) ? rotation : [0, 0, 0];
    return new THREE.Quaternion().setFromEuler(new THREE.Euler(source[0], source[1], source[2], 'XYZ'));
  }

  function quaternionShortestBlend(fromRotation, toRotation, t){
    const from = quaternionFromEulerArray(fromRotation);
    const to = quaternionFromEulerArray(toRotation);
    let normalizedTo = to;
    if (from.dot(to) < 0) {
      normalizedTo = to.clone().multiplyScalar(-1);
    }
    return from.clone().slerp(normalizedTo, Math.max(0, Math.min(1, t))); 
  }

  function detectRotationJump(fromRotation, toRotation, threshold = 1.6){
    const from = quaternionFromEulerArray(fromRotation);
    const to = quaternionFromEulerArray(toRotation);
    const delta = 2 * Math.acos(Math.max(-1, Math.min(1, Math.abs(from.dot(to)))));
    return delta > threshold;
  }

  function interpolateAFrame(a, b, t){
    const result = {
      root: {
        position: [0,0,0],
        rotation: [0,0,0],
      },
      bones: {},
    };
    const posA = a && a.root && a.root.position ? a.root.position : [0,0,0];
    const posB = b && b.root && b.root.position ? b.root.position : [0,0,0];
    result.root.position = [
      posA[0] + (posB[0] - posA[0]) * t,
      posA[1] + (posB[1] - posA[1]) * t,
      posA[2] + (posB[2] - posA[2]) * t,
    ];

    const rotA = a && a.root && a.root.rotation ? a.root.rotation : [0,0,0];
    const rotB = b && b.root && b.root.rotation ? b.root.rotation : [0,0,0];
    const q = quaternionShortestBlend(rotA, rotB, t);
    const e = new THREE.Euler().setFromQuaternion(q, 'XYZ');
    result.root.rotation = [e.x, e.y, e.z];

    const boneNames = new Set();
    for (const name of Object.keys((a && a.bones) || {})) boneNames.add(name);
    for (const name of Object.keys((b && b.bones) || {})) boneNames.add(name);
    for (const name of boneNames) {
      const pa = (a && a.bones && a.bones[name]) || { position: [0,0,0], rotation: [0,0,0] };
      const pb = (b && b.bones && b.bones[name]) || { position: [0,0,0], rotation: [0,0,0] };
      const rPosition = [
        pa.position[0] + (pb.position[0] - pa.position[0]) * t,
        pa.position[1] + (pb.position[1] - pa.position[1]) * t,
        pa.position[2] + (pb.position[2] - pa.position[2]) * t,
      ];
      const qFinal = quaternionShortestBlend(pa.rotation, pb.rotation, t);
      const eFinal = new THREE.Euler().setFromQuaternion(qFinal, 'XYZ');
      result.bones[name] = {
        position: rPosition,
        rotation: [eFinal.x, eFinal.y, eFinal.z],
      };
    }
    return result;
  }

  function rebuildAutoFrames(){
    for (let index = 1; index < state.frames.length; index++) {
      const frame = state.frames[index];
      if (!frame || frame.type !== 'AUTO') continue;
      const { previous, next } = getNeighborFrames(index);
      if (!previous || !next) {
        frame.pose = previous ? previous.pose : next ? next.pose : null;
        frame.source = 'AUTO';
        continue;
      }
      const startIndex = state.frames.findIndex(item => item.number === previous.number);
      const endIndex = state.frames.findIndex(item => item.number === next.number);
      const segment = endIndex - startIndex;
      const localT = segment > 1 ? (index - startIndex) / (endIndex - startIndex) : 0;
      const generated = interpolateAFrame(previous.pose || previous, next.pose || next, localT);
      if (previous.pose && next.pose && detectRotationJump(previous.pose.root.rotation || [0,0,0], next.pose.root.rotation || [0,0,0])) {
        console.warn('AUTO frame rotation jump detected between frames ' + previous.number + ' and ' + next.number + '.');
      }
      frame.pose = generated;
      frame.source = 'AUTO';
      frame.code = serializeFrameCode(frame);
    }
  }

  function serializeFrameCode(frame){
    const pose = frame.pose || { root: { position: [0,0,0], rotation: [0,0,0] }, bones: {} };
    const lines = ['FRAME_CODE_VERSION: 1', `frame: ${frame.number}`,'root:'];
    lines.push(`  position: [${pose.root.position.map(v => Number(v).toFixed(4)).join(', ')}]`);
    lines.push(`  rotation: [${pose.root.rotation.map(v => Number(v).toFixed(4)).join(', ')}]`);
    lines.push('bones:');
    const boneNames = Object.keys(pose.bones || {}).sort();
    for (const boneName of boneNames) {
      const bonePose = pose.bones[boneName] || { position: [0,0,0], rotation: [0,0,0] };
      lines.push(`  ${JSON.stringify(String(boneName))}:`);
      lines.push(`    position: [${bonePose.position.map(v => Number(v).toFixed(4)).join(', ')}]`);
      lines.push(`    rotation: [${bonePose.rotation.map(v => Number(v).toFixed(4)).join(', ')}]`);
    }
    return lines.join('\n');
  }

  function parseFrameCode(text){
    const lines = String(text || '').split(/\r?\n/);
    const frame = { frame: null, root: {}, bones: {} };
    let section = null;
    let currentBone = null;
    let hasRoot = false;
    let hasBones = false;
    let version = null;
    let transformCount = 0;
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry && window.characterRuntime.getSkeletonRegistry();
    const actualNames = registry && registry.bones
      ? [...new Set(registry.bones.map(record => String(record.originalName || record.bone && record.bone.name || record.name || '')).filter(Boolean))]
      : Object.keys(window.motionRuntime && window.motionRuntime.getRig && window.motionRuntime.getRig() && window.motionRuntime.getRig().rest || {});
    const normalizedNames = new Map();
    for (const name of actualNames) {
      const normalized = name.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!normalizedNames.has(normalized)) normalizedNames.set(normalized, []);
      normalizedNames.get(normalized).push(name);
    }
    const readVector = value => {
      const match = String(value).match(/^\[\s*([^\]]+)\s*\]$/);
      if (!match) throw new Error('Expected a 3-value vector like [0.0, 0.0, 0.0].');
      const values = match[1].split(',').map(part => part.trim());
      const numericLiteral = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i;
      if (values.length !== 3 || values.some(part => !numericLiteral.test(part) || !Number.isFinite(Number(part)))) {
        throw new Error('Expected exactly 3 finite numbers like [0.0, 0.0, 0.0].');
      }
      return values.map(Number);
    };
    const resolveBoneName = name => {
      if (actualNames.includes(name)) return name;
      const matches = normalizedNames.get(name.toLowerCase().replace(/[^a-z0-9]/g, '')) || [];
      if (matches.length === 1) return matches[0];
      if (matches.length > 1) throw new Error('Ambiguous bone name "' + name + '". Use the exact name from the AI Frame Profile.');
      const expected = actualNames.length ? actualNames.slice(0, 8).join(', ') : 'the loaded character skeleton';
      throw new Error('Invalid bone: ' + name + '. Expected exact model bone names such as: ' + expected);
    };
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const versionMatch = line.match(/^FRAME_CODE_VERSION\s*:\s*(\d+)$/i);
      if (versionMatch) {
        if (version !== null) throw new Error('Frame code contains more than one version declaration.');
        version = Number(versionMatch[1]);
        if (version !== 1) throw new Error('Unsupported FRAME_CODE_VERSION: ' + versionMatch[1] + '. This app supports version 1.');
        continue;
      }
      const numMatch = line.match(/^frame\s*:\s*(\d+)$/i);
      if (numMatch) {
        if (frame.frame !== null) throw new Error('Frame code contains more than one frame number.');
        frame.frame = Number(numMatch[1]);
        continue;
      }
      if (/^root\s*:\s*$/i.test(line)) {
        if (hasRoot) throw new Error('Frame code contains more than one root section.');
        hasRoot = true;
        section = 'root';
        currentBone = null;
        continue;
      }
      if (/^bones\s*:\s*$/i.test(line)) {
        if (hasBones) throw new Error('Frame code contains more than one bones section.');
        hasBones = true;
        section = 'bones';
        currentBone = null;
        continue;
      }
      if (section === 'root') {
        const valueMatch = line.match(/^(position|rotation)\s*:\s*(.+)$/i);
        if (valueMatch) {
          const key = valueMatch[1].toLowerCase();
          if (frame.root[key]) throw new Error('Root ' + key + ' is declared more than once.');
          frame.root[key] = readVector(valueMatch[2]);
          transformCount++;
          continue;
        }
      }
      if (section === 'bones') {
        const boneMatch = line.match(/^(.+?)\s*:\s*$/);
        if (boneMatch) {
          let requestedName = boneMatch[1].trim();
          if (requestedName.startsWith('"')) {
            try {
              requestedName = JSON.parse(requestedName);
            } catch (error) {
              throw new Error('Invalid quoted bone name: ' + boneMatch[1]);
            }
            if (typeof requestedName !== 'string' || !requestedName) throw new Error('Bone names must be non-empty strings.');
          } else if (!/^[A-Za-z0-9_]+$/.test(requestedName)) {
            throw new Error('Bone names with punctuation or spaces must be enclosed in double quotes.');
          }
          currentBone = resolveBoneName(requestedName);
          if (Object.prototype.hasOwnProperty.call(frame.bones, currentBone)) {
            throw new Error('Bone "' + currentBone + '" is listed more than once.');
          }
          frame.bones[currentBone] = {};
          continue;
        }
        if (currentBone) {
          const valueMatch = line.match(/^(position|rotation)\s*:\s*(.+)$/i);
          if (valueMatch) {
            const key = valueMatch[1].toLowerCase();
            if (frame.bones[currentBone][key]) throw new Error('Bone "' + currentBone + '" declares ' + key + ' more than once.');
            frame.bones[currentBone][key] = readVector(valueMatch[2]);
            transformCount++;
            continue;
          }
        }
      }
      throw new Error('Unrecognized frame-code line: "' + line + '". Use the FRAME_CODE_VERSION 1 template.');
    }
    if (version === null) throw new Error('Missing FRAME_CODE_VERSION: 1 header.');
    if (!Number.isInteger(frame.frame) || frame.frame < 1) throw new Error('Add a positive integer frame number.');
    if (!hasRoot || !hasBones) throw new Error('Frame code must include both root: and bones: sections.');
    if (!transformCount) throw new Error('Frame code must include at least one position or rotation vector.');
    return frame;
  }

  function makeAiPrompt(){
    const frame = getSelectedFrame();
    if (!frame) throw new Error('Select a Keyframe before creating an AI prompt.');
    const profile = window.frameProfileRuntime && window.frameProfileRuntime.generate
      ? window.frameProfileRuntime.generate()
      : 'AI Frame Profile unavailable. Use only bone names shown in the current frame code.';
    const code = serializeFrameCode(frame);
    const pose = frame.pose || { root: { position: [0, 0, 0], rotation: [0, 0, 0] }, bones: {} };
    const exampleBone = Object.keys(pose.bones || {}).sort()[0];
    const examplePose = exampleBone && pose.bones[exampleBone];
    const exampleRotation = examplePose && examplePose.rotation || [0, 0, 0];
    const exampleCode = exampleBone
      ? [
        'FRAME_CODE_VERSION: 1',
        'frame: ' + frame.number,
        'root:',
        '  position: [' + pose.root.position.map(value => Number(value).toFixed(4)).join(', ') + ']',
        '  rotation: [' + pose.root.rotation.map(value => Number(value).toFixed(4)).join(', ') + ']',
        'bones:',
        '  ' + JSON.stringify(exampleBone) + ':',
        '    rotation: [' + (Number(exampleRotation[0]) + 0.1).toFixed(4) + ', ' + Number(exampleRotation[1]).toFixed(4) + ', ' + Number(exampleRotation[2]).toFixed(4) + ']',
      ].join('\n')
      : code;
    return [
      'MOTION VIEWER - AI KEYFRAME GUIDE',
      'This guide is for editing the selected character pose in Motion Viewer. It is not JavaScript and must not be converted into JavaScript.',
      '',
      'HOW TO USE THIS GUIDE',
      '1. Read the model profile and use only the exact bone names listed there.',
      '2. Treat CURRENT FRAME CODE as the pose before the requested edit.',
      '3. Replace the USER REQUEST placeholder with the desired change, then send this whole guide to the AI.',
      '4. Copy the AI response into the Keyframe editor code box.',
      '5. Click Validate Code. If valid, click Apply Code to preview the pose.',
      '6. Add/select other timeline frames and repeat to build an animation; save the motion from Keyframe when finished.',
      '7. To build a whole animation in one go, ask the AI for a multi-frame import file (see MULTI-FRAME IMPORT FILE below), then use the Import Frames File button on the Keyframe page.',
      'The Frame Code menu page is a report/export feature; its report text is not pose code for Apply Code.',
      '',
      'FRAME CODE V1 RULES',
      '- Return only complete FRAME_CODE_VERSION: 1 frame text. Do not use Markdown fences, prose, JSON, or JavaScript.',
      '- Keep the frame number exactly as shown in CURRENT FRAME CODE.',
      '- Include the required frame:, root:, and bones: sections.',
      '- Each vector is exactly three finite decimal numbers: [x, y, z].',
      '- Rotations are radians in Euler XYZ order (not degrees). Convert degrees to radians if the user asks in degrees.',
      '- Bone position and rotation are parent-relative local transforms. Do not use the profile world positions as local pose values.',
      '- Root position/rotation refer to the character holder in Three.js scene units; do not assume meters.',
      '- Preserve every value not needed for the requested change. Do not invent bones, hierarchy, or anatomical directions.',
      '- Bone names containing punctuation or spaces must be enclosed in double quotes, exactly as shown in the profile.',
      '- If the requested body part cannot be mapped confidently to an actual bone, do not guess a bone name.',
      '',
      'CODE SHAPE EXAMPLE (syntax only; the sample rotation change is illustrative, not a recommended pose):',
      exampleCode,
      '',
      'The example uses one real bone name from this loaded model and changes its local X rotation by 0.1 radians. In your answer, use the actual requested change and preserve all other values from the full reference frame below.',
      '',
      "MULTI-FRAME IMPORT FILE (use this when the user asks for a whole animation / many frames)",
      "The Keyframe page has an \"Import Frames File\" button. It reads ONE .txt file that contains every frame of the animation, creates all the timeline frames automatically and puts each block into its own frame. When the user asks for a full animation (for example \"make a run cycle, 30 frames, 24 FPS\"), produce that file as follows.",
      "OUTPUT FORMAT",
      "1. Deliver one plain-text .txt file (if you can create a downloadable file, do that). If you cannot make a file, reply with the raw text only. NEVER wrap it in Markdown code fences (```), because the importer rejects any line that is not valid frame code or a # comment.",
      "2. First line of the file is a comment with the animation name, frame count and FPS, exactly like: # MOTION VIEWER - RUN - 30 frames @ 24 FPS, loops",
      "   Write a number followed by \"FPS\" only in this first line, never anywhere else.",
      "3. Then one block per frame, in order, frame: 1, frame: 2 ... frame: N. Numbers must start at 1, be continuous (no gaps, no repeats) and the count must equal the requested frame count.",
      "4. Directly above every block put one comment line. For important poses write the word KEYFRAME and a pose name, for example: # ===== FRAME 5 / 30 KEYFRAME - CROUCH =====",
      "   For in-between frames write: # ===== FRAME 6 / 30 in-between =====   (do NOT use the word KEYFRAME on in-between lines.)",
      "5. Every block is a complete FRAME_CODE_VERSION: 1 frame with the same shape as the single-frame example above: FRAME_CODE_VERSION: 1, frame: N, root: (position and rotation), bones:",
      "6. EVERY block must list EVERY bone shown in the MODEL PROFILE (all of them, same bone names, double quotes), each with position and rotation. Never skip a bone, never write \"...\" or \"same as before\", never shorten the file. The complete file must be delivered in one response.",
      "7. Bone position: copy the position of each bone exactly from CURRENT FRAME CODE in every frame (do not change it). Animate with bone rotation (radians, Euler XYZ, parent-relative) and with root position/rotation (for example root height for jumps, root forward/back for travel).",
      "8. Use only bone names from the profile. Do not add text, notes, titles or explanations outside the # comment lines.",
      "9. Make the motion smooth: pick the key poses first, then fill the in-between frames with gradual changes so the first and last frame connect well when the animation loops.",
      "Format of the file (only two bones are shown here for space; your real file must include all bones in every block):",
      "# MOTION VIEWER - EXAMPLE - 2 frames @ 24 FPS, loops",
      "# ===== FRAME 1 / 2 KEYFRAME - STAND =====",
      "FRAME_CODE_VERSION: 1",
      "frame: 1",
      "root:",
      "  position: [0.0000, 0.0000, 0.0000]",
      "  rotation: [0.0000, 0.0000, 0.0000]",
      "bones:",
      "  " + JSON.stringify(exampleBone || "BONE_NAME") + ":",
      "    position: [0.0000, 0.0000, 0.0000]",
      "    rotation: [0.0000, 0.0000, 0.0000]",
      "# ===== FRAME 2 / 2 in-between =====",
      "FRAME_CODE_VERSION: 1",
      "frame: 2",
      "root:",
      "  position: [0.0000, 0.0500, 0.0000]",
      "  rotation: [0.0000, 0.0000, 0.0000]",
      "bones:",
      "  " + JSON.stringify(exampleBone || "BONE_NAME") + ":",
      "    position: [0.0000, 0.0000, 0.0000]",
      "    rotation: [0.1000, 0.0000, 0.0000]",
      "After the file is created the user clicks Import Frames File in the Keyframe page and selects it; each block goes into the timeline frame with the same frame number. For a whole animation, the USER REQUEST should state the motion, the number of frames and the FPS; if frames or FPS are missing, use 30 frames at 24 FPS.",
      "",
      '',
      'MODEL PROFILE',
      profile,
      '',
      'CURRENT FRAME CODE (complete reference pose for this selected frame):',
      code,
      '',
      'USER REQUEST: [Describe the pose or motion change here. For a whole animation also write the number of frames and FPS, e.g. "run cycle, 30 frames, 24 FPS, multi-frame import file"]',
    ].join('\n');
  }

  async function copyAiPrompt(){
    try {
      const prompt = makeAiPrompt();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(prompt);
      } else {
        const temp = document.createElement('textarea');
        temp.value = prompt;
        temp.setAttribute('readonly', '');
        temp.style.position = 'fixed';
        temp.style.opacity = '0';
        document.body.appendChild(temp);
        temp.select();
        const copied = document.execCommand('copy');
        temp.remove();
        if (!copied) throw new Error('Clipboard access is unavailable. Open the app on localhost or HTTPS and try again.');
      }
      setStatus('AI prompt copied. Add your request in the prompt, then paste the returned code here.', 'ok');
    } catch (error) {
      console.error('AI prompt copy failed', error);
      setStatus(error.message || 'Could not copy the AI prompt.', 'error');
    }
  }

  function downloadAiGuide(){
    try {
      const guide = makeAiPrompt();
      const blob = new Blob([guide], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'motion-viewer-ai-frame-guide.txt';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      setStatus('AI Frame Guide downloaded. Upload or paste the TXT file into your AI.', 'ok');
    } catch (error) {
      console.error('AI Frame Guide download failed', error);
      setStatus(error.message || 'Could not download the AI Frame Guide.', 'error');
    }
  }

  function validateCodeFromEditor(){
    const textarea = document.getElementById('keyframeCode');
    if (!textarea) return;
    try {
      const parsed = parseFrameCode(textarea.value);
      const boneCount = Object.keys(parsed.bones).length;
      setStatus('Valid Frame Code v1: frame ' + parsed.frame + ', ' + boneCount + ' model bone(s). Ready to apply.', 'ok');
    } catch (error) {
      setStatus(error.message || String(error), 'error');
    }
  }

  function setStatus(message, kind = ''){
    const node = document.getElementById('keyframeStatus');
    if (!node) return;
    node.textContent = message;
    node.classList.remove('error', 'ok');
    if (kind) node.classList.add(kind);
  }

  function loadSavedProject(){
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (saved && Array.isArray(saved.frames) && saved.frames.length) {
        state.frames = saved.frames.map(frame => ({ ...frame, pose: frame.pose || { root: { position:[0,0,0], rotation:[0,0,0] }, bones:{} } }));
        state.selected = Number(saved.selected) || 1;
        state.fps = saved.fps || 30;
        state.speed = saved.speed || 1;
        state.loop = saved.loop !== false;
        state.onionSkin = !!saved.onionSkin;
        state.onionOpacity = saved.onionOpacity || 0.35;
        return true;
      }
    } catch (error) {
      console.warn('Keyframe load failed', error);
    }
    return false;
  }

  function saveCurrentProject(){
    const payload = {
      frames: state.frames,
      selected: state.selected,
      fps: state.fps,
      speed: state.speed,
      loop: state.loop,
      onionSkin: state.onionSkin,
      onionOpacity: state.onionOpacity,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
      return true;
    } catch (error) {
      console.error('Keyframe project save failed', error);
      setStatus('Could not save the full motion in this browser.', 'error');
      return false;
    }
  }

  function getSavedMotions(){
    let saved;
    try {
      saved = JSON.parse(localStorage.getItem(MOTION_LIBRARY_KEY) || 'null');
    } catch (error) {
      console.error('Saved Keyframe motions could not be read', error);
      throw new Error('Saved motions could not be read from this browser.');
    }
    if (Array.isArray(saved)) return saved.filter(motion =>
      motion && typeof motion.id === 'string' && typeof motion.name === 'string' &&
      Array.isArray(motion.frames) && motion.frames.length > 0
    );

    let legacyProject;
    try {
      legacyProject = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    } catch (error) {
      console.error('Legacy Keyframe project could not be migrated', error);
      return [];
    }
    if (!legacyProject || !Array.isArray(legacyProject.frames) || !legacyProject.frames.length) return [];
    const migrated = [{
      id: 'legacy-keyframe-project',
      name: 'Keyframe Motion',
      frames: legacyProject.frames,
      fps: legacyProject.fps || 30,
      speed: legacyProject.speed || 1,
      loop: legacyProject.loop !== false,
      updatedAt: Date.now(),
    }];
    try {
      localStorage.setItem(MOTION_LIBRARY_KEY, JSON.stringify(migrated));
    } catch (error) {
      console.error('Legacy Keyframe project migration failed', error);
    }
    return migrated;
  }

  function saveMotionToLibrary(name){
    if (!state.frames.length) throw new Error('Add at least one frame before saving a motion.');
    const normalizedName = String(name || '').trim().slice(0, 60);
    const motions = getSavedMotions();
    const motionName = normalizedName || 'Keyframe Motion ' + (motions.length + 1);
    const existing = motions.find(motion => motion.name.toLocaleLowerCase() === motionName.toLocaleLowerCase());
    const motion = {
      id: existing ? existing.id : 'keyframe-motion-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8),
      name: motionName,
      frames: state.frames.map(frame => ({ ...frame, pose: clonePose(frame.pose) })),
      fps: state.fps,
      speed: state.speed,
      loop: state.loop,
      updatedAt: Date.now(),
    };
    const next = existing
      ? motions.map(item => item.id === existing.id ? motion : item)
      : [...motions, motion];
    try {
      localStorage.setItem(MOTION_LIBRARY_KEY, JSON.stringify(next));
    } catch (error) {
      console.error('Keyframe motion library save failed', error);
      throw new Error('Could not save this motion in the browser storage.');
    }
    return motion;
  }

  function saveMotionFromButton(){
    const name = document.getElementById('keyframeMotionName');
    try {
      if (!saveCurrentProject()) return;
      const motion = saveMotionToLibrary(name && name.value);
      setStatus('Saved "' + motion.name + '" (' + motion.frames.length + ' frames) to Frame Gallery.', 'ok');
    } catch (error) {
      setStatus(error.message || String(error), 'error');
    }
  }

  function ensureDefaultFrames(){
    if (state.frames.length) return;
    const first = snapshotPoseFromModel(1, 'KEYFRAME', 'MANUAL');
    const last = snapshotPoseFromModel(5, 'KEYFRAME', 'MANUAL');
    state.frames = [
      { ...first, type: 'KEYFRAME', source: 'MANUAL', pose: first.pose },
      { number: 2, type: 'EMPTY', source: 'EMPTY', pose: null, code: '', timestamp: Date.now() },
      { number: 3, type: 'EMPTY', source: 'EMPTY', pose: null, code: '', timestamp: Date.now() },
      { number: 4, type: 'EMPTY', source: 'EMPTY', pose: null, code: '', timestamp: Date.now() },
      { ...last, number: 5, type: 'KEYFRAME', source: 'MANUAL', pose: last.pose },
    ];
    state.selected = 1;
  }

  function commitHistory(){
    const snapshot = state.frames.map(frame => ({ ...frame, pose: clonePose(frame.pose) }));
    if (state.history.length && JSON.stringify(state.history[state.history.length - 1]) === JSON.stringify(snapshot)) return;
    state.history.push(snapshot);
    if (state.history.length > 30) state.history.shift();
    state.historyIndex = state.history.length - 1;
  }

  function pushHistory(){
    commitHistory();
    saveCurrentProject();
  }

  function applyFrameObject(frame, targetNumber = state.selected, typeOverride = null){
    const current = getFrameByNumber(targetNumber) || state.frames[0];
    if (!current) return;
    const patch = frame && frame.pose ? frame.pose : current.pose;
    const mergedPose = deepMergePose(current.pose || patch, patch);
    current.number = targetNumber;
    current.type = typeOverride || frame.type || current.type || 'EDITED';
    current.source = frame.source || current.source || 'MANUAL';
    current.pose = mergedPose;
    current.code = frame.code || serializeFrameCode(current);
    current.timestamp = Date.now();
    applyPoseToRig(current.pose);
    state.selected = targetNumber;
    saveCurrentProject();
  }

  function selectFrame(number){
    if (!state.frames.length) return;
    const frame = getFrameByNumber(number) || state.frames[0];
    state.selected = frame.number;
    if (frame.pose) applyPoseToRig(frame.pose);
    const text = frame.code || serializeFrameCode(frame);
    const textarea = document.getElementById('keyframeCode');
    if (textarea) textarea.value = text;
    renderKeyframePage();
  }

  function addFrameAt(index){
    const newNumber = state.frames.length + 1;
    const base = getSelectedFrame() || state.frames[0];
    const frame = { number: newNumber, type: 'EMPTY', source: 'MANUAL', pose: base ? clonePose(base.pose) : null, code: '', timestamp: Date.now() };
    state.frames.push(frame);
    state.frames.sort((a, b) => a.number - b.number);
    state.frames.forEach((item, idx) => { item.number = idx + 1; });
    state.selected = newNumber;
    saveCurrentProject();
    renderKeyframePage();
  }

  function duplicateFrame(){
    const frame = getSelectedFrame();
    if (!frame) return;
    const duplicated = {
      number: state.frames.length + 1,
      type: 'KEYFRAME',
      source: 'DUPLICATED',
      pose: clonePose(frame.pose || { root: { position:[0,0,0], rotation:[0,0,0] }, bones: {} }),
      code: serializeFrameCode(frame),
      timestamp: Date.now(),
    };
    state.frames.push(duplicated);
    state.frames.sort((a, b) => a.number - b.number);
    state.frames.forEach((item, idx) => { item.number = idx + 1; });
    state.selected = duplicated.number;
    saveCurrentProject();
    renderKeyframePage();
  }

  function removeSelectedFrame(){
    if (state.frames.length <= 1) return;
    const currentIndex = state.frames.findIndex(frame => frame.number === state.selected);
    if (currentIndex === -1) return;
    state.frames.splice(currentIndex, 1);
    state.frames.forEach((frame, idx) => { frame.number = idx + 1; });
    state.selected = Math.min(state.selected, state.frames.length);
    saveCurrentProject();
    renderKeyframePage();
  }

  function setType(type){
    const frame = getSelectedFrame();
    if (!frame) return;
    if (type === 'DELETE') {
      removeSelectedFrame();
      return;
    }
    if (type === 'AUTO') {
      const { previous, next } = getNeighborFrames(state.frames.findIndex(item => item.number === frame.number));
      if (previous && next) {
        const index = state.frames.findIndex(item => item.number === frame.number);
        const localT = (index - state.frames.findIndex(item => item.number === previous.number)) / (state.frames.findIndex(item => item.number === next.number) - state.frames.findIndex(item => item.number === previous.number));
        frame.pose = interpolateAFrame(previous.pose || previous, next.pose || next, localT);
        frame.type = 'AUTO';
        frame.source = 'AUTO';
      } else {
        frame.type = 'AUTO';
        frame.source = 'AUTO';
      }
      frame.code = serializeFrameCode(frame);
      frame.timestamp = Date.now();
      applyPoseToRig(frame.pose);
    } else {
      frame.type = type;
      frame.source = type === 'HOLD' ? 'HOLD' : 'MANUAL';
      if (!frame.pose) frame.pose = clonePose(getNeighborFrames(state.frames.findIndex(item => item.number === frame.number)).previous?.pose || { root:{position:[0,0,0],rotation:[0,0,0]}, bones:{} });
      frame.code = serializeFrameCode(frame);
      applyPoseToRig(frame.pose);
    }
    saveCurrentProject();
    renderKeyframePage();
  }

  function renderTimeline(){
    const container = document.getElementById('keyframeTimeline');
    if (!container) return;
    container.innerHTML = '';
    const frames = state.frames || [];
    for (const frame of frames) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'keyframeFrame ' + String(frame.type || 'EMPTY').toLowerCase();
      if (frame.number === state.selected) button.classList.add('active');
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = String(frame.type || 'EMPTY');
      const num = document.createElement('span');
      num.className = 'num';
      num.textContent = 'F' + frame.number;
      button.appendChild(tag);
      button.appendChild(num);
      button.addEventListener('click', () => selectFrame(frame.number));
      container.appendChild(button);
    }
  }

  function renderSelector(){
    const wrap = document.getElementById('keyframeSelector');
    if (!wrap) return;
    wrap.innerHTML = '';
    const buttons = [
      { label: 'AUTO', value: 'AUTO' },
      { label: 'EDITED', value: 'EDITED' },
      { label: 'HOLD', value: 'HOLD' },
      { label: 'LOCKED', value: 'LOCKED' },
    ];
    const frame = getSelectedFrame();
    for (const item of buttons) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'chip';
      if (frame && frame.type === item.value) button.classList.add('active');
      button.textContent = item.label;
      button.addEventListener('click', () => setType(item.value));
      wrap.appendChild(button);
    }
  }

  function renderTypeRow(){
    const wrap = document.getElementById('keyframeTypeRow');
    if (!wrap) return;
    wrap.innerHTML = '';
    const frame = getSelectedFrame();
    const actions = [...KEYFRAME_ACTIONS];
    for (const action of actions) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = action;
      if (frame && frame.type === action) button.classList.add('active');
      button.addEventListener('click', () => setType(action));
      wrap.appendChild(button);
    }
  }

  function renderMeta(){
    const meta = document.getElementById('keyframeMeta');
    if (!meta) return;
    const frame = getSelectedFrame();
    const source = frame && frame.source ? frame.source : 'MANUAL';
    const type = frame && frame.type ? frame.type : 'EMPTY';
    const root = frame && frame.pose && frame.pose.root ? frame.pose.root : { position:[0,0,0], rotation:[0,0,0] };
    const info = [
      ['Frame', frame ? `#${frame.number}` : 'n/a'],
      ['Type', type],
      ['Source', source],
      ['Fps', String(state.fps)],
      ['Speed', String(state.speed) + 'x'],
      ['Position', root.position.map(v => Number(v).toFixed(2)).join(', ')],
      ['Rotation', root.rotation.map(v => Number(v).toFixed(2)).join(', ')],
    ];
    meta.innerHTML = '';
    for (const [label, value] of info) {
      const box = document.createElement('div');
      box.className = 'meta-box';
      const strong = document.createElement('strong');
      strong.textContent = label;
      const text = document.createElement('span');
      text.textContent = value;
      box.appendChild(strong); box.appendChild(text); meta.appendChild(box);
    }
  }

  function renderButtonState(){
    const playButton = document.getElementById('keyframePlay');
    const pauseButton = document.getElementById('keyframePause');
    const loopButton = document.getElementById('keyframeLoop');
    const speedInput = document.getElementById('keyframeSpeed');
    const fpsInput = document.getElementById('keyframeFps');
    const onionButton = document.getElementById('keyframeOnion');
    const onionOpacity = document.getElementById('keyframeOpacity');
    if (speedInput) {
      speedInput.value = String(state.speed);
      const speedValue = document.getElementById('keyframeSpeedValue');
      if (speedValue) speedValue.textContent = Number(state.speed).toFixed(2).replace(/\.00$/, '') + 'x';
    }
    if (fpsInput) fpsInput.value = String(state.fps);
    const fpsValue = document.getElementById('keyframeFpsValue');
    if (fpsValue) fpsValue.textContent = String(state.fps);
    if (playButton) playButton.textContent = state.playing ? 'Playing' : 'Play';
    if (pauseButton) pauseButton.disabled = !state.playing;
    if (loopButton) { loopButton.setAttribute('aria-pressed', String(state.loop)); loopButton.textContent = state.loop ? 'Loop On' : 'Loop Off'; }
    if (onionButton) {
      onionButton.setAttribute('aria-pressed', String(state.onionSkin));
      onionButton.textContent = state.onionSkin ? 'Onion Skin On' : 'Onion Skin';
    }
    if (onionOpacity) onionOpacity.value = String(state.onionOpacity);
  }

  function analyzeCurrentMotionQuality(){
    if (!window.motionQuality || typeof window.motionQuality.analyzeFrames !== 'function') return null;
    const report = window.motionQuality.analyzeFrames(state.frames || []);
    state.motionQuality = report;
    if (report && report.warnings.length) {
      const statusNode = document.getElementById('keyframeStatus');
      if (statusNode) {
        statusNode.textContent = report.warnings[0];
        statusNode.classList.remove('ok');
        statusNode.classList.add('error');
      }
    }
    return report;
  }

  function renderKeyframePage(){
    const frame = getSelectedFrame();
    const editorTitle = document.getElementById('keyframeEditorTitle');
    if (editorTitle && frame) editorTitle.textContent = 'Frame ' + frame.number;
    const textarea = document.getElementById('keyframeCode');
    if (textarea && frame) textarea.value = frame.code || serializeFrameCode(frame);
    renderTimeline();
    renderSelector();
    renderTypeRow();
    renderMeta();
    renderButtonState();
    if (frame && frame.pose) applyPoseToRig(frame.pose);
    if (frame && frame.type === 'KEYFRAME' && !frame.code) frame.code = serializeFrameCode(frame);
    analyzeCurrentMotionQuality();
  }

  function applyCodeFromEditor(){
    const textarea = document.getElementById('keyframeCode');
    if (!textarea) return;
    try {
      const parsed = parseFrameCode(textarea.value);
      const selected = getSelectedFrame();
      if (!selected) return;
      const basePose = selected.pose ? clonePose(selected.pose) : { root:{position:[0,0,0], rotation:[0,0,0]}, bones:{} };
      const patch = {
        frame: parsed.frame,
        type: 'EDITED',
        source: 'AI',
        pose: deepMergePose(basePose, parsed),
        code: textarea.value.trim(),
      };
      const target = getSelectedFrame();
      if (!target) return;
      target.type = 'EDITED';
      target.source = 'AI';
      target.pose = deepMergePose(basePose, parsed);
      target.code = textarea.value.trim();
      applyPoseToRig(target.pose);
      saveCurrentProject();
      setStatus('Code applied to frame ' + target.number, 'ok');
      renderKeyframePage();
    } catch (error) {
      console.error(error);
      setStatus(error.message || String(error), 'error');
    }
  }

  function copyCode(){
    const textarea = document.getElementById('keyframeCode');
    if (!textarea) return;
    navigator.clipboard.writeText(textarea.value).then(() => setStatus('Frame code copied.', 'ok')).catch(() => setStatus('Clipboard unavailable.', 'error'));
  }

  function resetCode(){
    const frame = getSelectedFrame();
    if (!frame) return;
    const source = frame.pose || { root:{position:[0,0,0], rotation:[0,0,0]}, bones:{} };
    const code = serializeFrameCode(frame);
    const textarea = document.getElementById('keyframeCode');
    if (textarea) textarea.value = code;
    frame.code = code;
    if (source) applyPoseToRig(source);
    renderKeyframePage();
  }

  function tickPlayback(now){
    if (!state.playing || !state.frames.length) return;
    const elapsed = (now - (state.lastTime || now)) / 1000;
    state.lastTime = now;
    state.playbackAccumulator = (state.playbackAccumulator || 0) + elapsed * state.fps * state.speed;
    const step = Math.floor(state.playbackAccumulator);
    if (step < 1) {
      window.requestAnimationFrame(tickPlayback);
      return;
    }
    state.playbackAccumulator -= step;
    const frameCount = state.frames.length;
    const currentIndex = state.currentFrameIndex || 0;
    let nextIndex = currentIndex + step;
    if (nextIndex >= frameCount) {
      if (state.loop) nextIndex %= frameCount;
      else {
        state.playing = false;
        nextIndex = frameCount - 1;
      }
    }
    state.currentFrameIndex = nextIndex;
    const frame = state.frames[nextIndex] || state.frames[0];
    state.selected = frame.number;
    if (frame.pose) applyPoseToRig(frame.pose);
    if (frame.code) {
      const textarea = document.getElementById('keyframeCode');
      if (textarea) textarea.value = frame.code;
    }
    renderKeyframePage();
    if (state.playing) window.requestAnimationFrame(tickPlayback);
  }

  function startPlayback(){
    if (!state.frames.length) return;
    if (!state.playing) {
      state.playing = true;
      state.lastTime = performance.now();
      state.playbackAccumulator = 0;
      renderKeyframePage();
      window.requestAnimationFrame(tickPlayback);
    }
  }

  function pausePlayback(){
    state.playing = false;
    renderKeyframePage();
  }

  function stopPlayback(){
    state.playing = false;
    state.currentFrameIndex = 0;
    const frame = state.frames[0];
    state.selected = frame ? frame.number : 1;
    if (frame && frame.pose) applyPoseToRig(frame.pose);
    renderKeyframePage();
  }

  function initKeyframePage(){
    ensureDefaultFrames();
    const frame = getSelectedFrame();
    if (frame) {
      if (!frame.pose) frame.pose = snapshotPoseFromModel(frame.number, frame.type || 'KEYFRAME', frame.source || 'MANUAL').pose;
      frame.code = frame.code || serializeFrameCode(frame);
      if (frame.pose) applyPoseToRig(frame.pose);
    }
    renderKeyframePage();
  }

  function bindKeyframeEvents(){
    const closeModal = document.getElementById('keyframeCloseModal');
    if (closeModal) {
      closeModal.addEventListener('click', () => nav.go('home'));
    }
    const backdrop = document.querySelector('.keyframeModalBackdrop');
    if (backdrop) {
      backdrop.addEventListener('click', () => nav.go('home'));
    }
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && nav.active === 'keyframe') {
        const modalShell = document.getElementById('keyframeModalShell');
        if (modalShell && !modalShell.closest('.page').hidden) {
          nav.go('home');
        }
      }
    });
    const menuButton = document.getElementById('keyframeMenuButton');
    if (menuButton) menuButton.addEventListener('click', () => nav.toggleMenu());
    const root = document.getElementById('keyframePlay');
    if (root) root.addEventListener('click', startPlayback);
    const pause = document.getElementById('keyframePause');
    if (pause) pause.addEventListener('click', pausePlayback);
    const stop = document.getElementById('keyframeStop');
    if (stop) stop.addEventListener('click', stopPlayback);
    const add = document.getElementById('keyframeAdd');
    if (add) add.addEventListener('click', addFrameAt);
    const saveMotion = document.getElementById('keyframeSaveMotion');
    if (saveMotion) saveMotion.addEventListener('click', saveMotionFromButton);
    const dup = document.getElementById('keyframeDuplicate');
    if (dup) dup.addEventListener('click', duplicateFrame);
    const compare = document.getElementById('keyframeCompare');
    if (compare) compare.addEventListener('click', () => {
      const frame = getSelectedFrame();
      if (!frame) return;
      state.compareTo = state.compareTo === frame.number ? null : frame.number;
      setStatus(state.compareTo ? 'Comparing frame ' + state.compareTo : 'Comparison cleared.', 'ok');
    });
    const onion = document.getElementById('keyframeOnion');
    if (onion) onion.addEventListener('click', () => { state.onionSkin = !state.onionSkin; renderKeyframePage(); });
    const opacity = document.getElementById('keyframeOpacity');
    if (opacity) opacity.addEventListener('input', () => { state.onionOpacity = Number(opacity.value) || 0.35; renderKeyframePage(); });
    const speed = document.getElementById('keyframeSpeed');
    if (speed) speed.addEventListener('input', () => { state.speed = Number(speed.value) || 1; renderKeyframePage(); });
    const fps = document.getElementById('keyframeFps');
    if (fps) fps.addEventListener('input', () => { state.fps = Number(fps.value) || 30; renderKeyframePage(); });
    const loop = document.getElementById('keyframeLoop');
    if (loop) loop.addEventListener('click', () => { state.loop = !state.loop; renderKeyframePage(); });
    const apply = document.getElementById('keyframeApply');
    if (apply) apply.addEventListener('click', applyCodeFromEditor);
    const validate = document.getElementById('keyframeValidate');
    if (validate) validate.addEventListener('click', validateCodeFromEditor);
    const aiPrompt = document.getElementById('keyframeCopyAiPrompt');
    if (aiPrompt) aiPrompt.addEventListener('click', copyAiPrompt);
    const downloadAi = document.getElementById('keyframeDownloadAiGuide');
    if (downloadAi) downloadAi.addEventListener('click', downloadAiGuide);
    const copy = document.getElementById('keyframeCopy');
    if (copy) copy.addEventListener('click', copyCode);
    const reset = document.getElementById('keyframeReset');
    if (reset) reset.addEventListener('click', resetCode);
    const prev = document.getElementById('keyframePrev');
    if (prev) prev.addEventListener('click', () => {
      const currentIndex = state.frames.findIndex(frame => frame.number === state.selected);
      if (currentIndex <= 0) return;
      selectFrame(state.frames[currentIndex - 1].number);
    });
    const next = document.getElementById('keyframeNext');
    if (next) next.addEventListener('click', () => {
      const currentIndex = state.frames.findIndex(frame => frame.number === state.selected);
      if (currentIndex >= state.frames.length - 1) return;
      selectFrame(state.frames[currentIndex + 1].number);
    });
  }

  function mountKeyframePage(el){
    if (!el) return;
    el.innerHTML = '';
    const template = document.getElementById('keyframePageTpl');
    if (template) {
      el.appendChild(template.content.cloneNode(true));
    }
    if (!loadSavedProject()) {
      ensureDefaultFrames();
    }
    bindKeyframeEvents();
    initKeyframePage();
  }

  function showKeyframePage(){
    const viewer = document.querySelector('.keyframeViewer');
    if (viewer && window.viewerRuntime && typeof window.viewerRuntime.setCanvasHost === 'function') {
      window.viewerRuntime.setCanvasHost(viewer);
    }
    if (!state.frames.length) ensureDefaultFrames();
    if (!state.selected) state.selected = 1;
    const frame = getSelectedFrame();
    if (frame && frame.pose) applyPoseToRig(frame.pose);
    renderKeyframePage();
  }

  function hideKeyframePage(){
    pausePlayback();
    if (window.viewerRuntime && typeof window.viewerRuntime.setCanvasHost === 'function') {
      window.viewerRuntime.setCanvasHost(document.getElementById('app'));
    }
  }

  window.keyframeRuntime = {
    init: initKeyframePage,
    render: renderKeyframePage,
    save: saveCurrentProject,
    applyCode: applyCodeFromEditor,
    setType,
    addFrameAt,
    duplicateFrame,
    selectFrame,
    getState: () => state,
    getFrames: () => state.frames,
    getSavedMotions,
    saveMotionToLibrary,
    parseFrameCode,
    applyPoseToRig,
    snapshotPoseFromModel,
    serializeFrameCode,
    analyzeMotionQuality: analyzeCurrentMotionQuality,
  };

  nav.registerPage({
    id: 'keyframe',
    label: 'Keyframe',
    order: 12,
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h7V5h2v7h7v2h-7v7h-2v-7H4z"/></svg>',
    canOpen(){
      if (window.characterRuntime && window.characterRuntime.getModel && window.characterRuntime.getModel()) return true;
      window.appUI.toast('Load a character before opening the keyframe editor.', 2800);
      return false;
    },
    mount: mountKeyframePage,
    onShow: showKeyframePage,
    onHide: hideKeyframePage,
  });
})();
