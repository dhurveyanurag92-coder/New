window.keyframePageState = {
  frames: [],
  selected: 1,
  playing: false,
  loop: true,
  speed: 1,
  fps: 30,
  onionSkin: false,
  onionOpacity: 0.35,
  compareTo: null,
  currentFrame: 1,
  currentFrameIndex: 0,
  lastTime: 0,
  animationFrameId: null,
  history: [],
  historyIndex: -1,
};

const KEYFRAME_TYPES = [
  { id: 'KEYFRAME', label: 'KEYFRAME' },
  { id: 'AUTO', label: 'AUTO' },
  { id: 'EDITED', label: 'EDITED' },
  { id: 'HOLD', label: 'HOLD' },
  { id: 'EMPTY', label: 'EMPTY' },
  { id: 'LOCKED', label: 'LOCKED' },
];

const KEYFRAME_ACTIONS = [
  'AUTO',
  'EDITED',
  'HOLD',
  'LOCKED',
  'DELETE',
];

const KEYFRAME_SOURCES = ['MANUAL', 'AI', 'AUTO', 'EDITED', 'HOLD', 'DUPLICATED'];

const keyframeUtils = {
  clone(obj){ return JSON.parse(JSON.stringify(obj || {})); },
  safeNumber(value){ return Number.isFinite(Number(value)) ? Number(value) : 0; },
  normalizeBoneName(value){
    const raw = String(value || '');
    return raw.replace(/^mixamorig[:_ ]?/i, '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
  },
  boneKeyFromName(name){
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry && window.characterRuntime.getSkeletonRegistry();
    const normalized = this.normalizeBoneName(name);
    if(!registry || !registry.bones) return null;
    const match = registry.bones.find(record => this.normalizeBoneName(record.originalName || record.normalizedName || record.semanticRole || '') === normalized || (record.normalizedName && this.normalizeBoneName(record.normalizedName) === normalized));
    return match ? (match.bone && match.bone.name) || match.originalName || null : null;
  },
  getBoneEntries(){
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry && window.characterRuntime.getSkeletonRegistry();
    const rig = window.motionRuntime && window.motionRuntime.getRig && window.motionRuntime.getRig();
    const keys = registry && registry.bones ? registry.bones.map(record => record.originalName || record.bone && record.bone.name).filter(Boolean) : [];
    return keys.length ? keys : Object.keys((rig && rig.rest) || {});
  },
};

window.keyframeUtils = keyframeUtils;
