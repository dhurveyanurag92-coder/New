(function(){
  // Import Frames File: txt file (FRAME_CODE_VERSION: 1 blocks) -> poori timeline automatically.
  const state = window.keyframePageState;

  function setStatus(msg, kind){
    const n = document.getElementById('keyframeStatus');
    if (!n) return;
    n.textContent = msg;
    n.classList.remove('error', 'ok');
    if (kind) n.classList.add(kind);
  }

  function mergePose(base, parsed){
    const pose = JSON.parse(JSON.stringify(base));
    if (parsed.root) {
      if (parsed.root.position) pose.root.position = parsed.root.position.slice(0, 3);
      if (parsed.root.rotation) pose.root.rotation = parsed.root.rotation.slice(0, 3);
    }
    for (const name of Object.keys(parsed.bones || {})) {
      if (!pose.bones[name]) pose.bones[name] = { position: [0,0,0], rotation: [0,0,0] };
      const b = parsed.bones[name];
      if (b.position) pose.bones[name].position = b.position.slice(0, 3);
      if (b.rotation) pose.bones[name].rotation = b.rotation.slice(0, 3);
    }
    return pose;
  }

  // File ko blocks mein todta hai; har block ke upar wali '#' header line type batati hai.
  function splitBlocks(text){
    const lines = text.split(/\r?\n/);
    const blocks = [];
    let cur = null;
    let pendingComments = [];
    for (const line of lines) {
      if (/^\s*FRAME_CODE_VERSION\s*:/i.test(line)) {
        cur = { header: pendingComments.join(' '), lines: [line] };
        blocks.push(cur);
        pendingComments = [];
      } else if (/^\s*#/.test(line)) {
        pendingComments = [line];
        if (cur) cur.closed = true;
      } else if (cur) {
        cur.lines.push(line);
      }
    }
    return blocks;
  }

  function importText(text, fileName){
    const rt = window.keyframeRuntime;
    if (!rt || !rt.parseFrameCode) throw new Error('Keyframe editor ready nahi hai.');
    const blocks = splitBlocks(text);
    if (!blocks.length) throw new Error('File mein koi FRAME_CODE_VERSION: 1 block nahi mila.');

    const base = rt.snapshotPoseFromModel(1, 'EDITED', 'AI').pose;
    const frames = [];
    const seen = new Set();
    let partial = 0;
    blocks.forEach((block, i) => {
      const code = block.lines.join('\n').trim();
      let parsed;
      try { parsed = rt.parseFrameCode(code); }
      catch (e) { throw new Error('Block ' + (i + 1) + ' mein error: ' + (e.message || e)); }
      if (seen.has(parsed.frame)) throw new Error('Frame ' + parsed.frame + ' file mein do baar hai.');
      seen.add(parsed.frame);
      if (Object.keys(parsed.bones).length < Object.keys(base.bones).length) partial++;
      const isKey = /KEYFRAME/i.test(block.header);
      frames.push({
        number: parsed.frame,
        type: isKey ? 'KEYFRAME' : 'EDITED',
        source: 'AI',
        pose: mergePose(base, parsed),
        code,
        timestamp: Date.now(),
      });
    });
    frames.sort((a, b) => a.number - b.number);
    if (window.keyframeAccuracy && typeof window.keyframeAccuracy.validateFrameSequence === 'function') {
      try {
        window.keyframeAccuracy.validateFrameSequence(frames, base, { strict: true });
      } catch (error) {
        throw error;
      }
    } else {
      frames.forEach((f, i) => {
        if (f.number !== i + 1) throw new Error('Frame number ' + (i + 1) + ' missing hai (frames 1 se continuous hone chahiye).');
      });
    }

    if (state.frames.length && !window.confirm('Abhi ke ' + state.frames.length + ' frames replace honge, aur file ke ' + frames.length + ' frames lagenge. Continue?')) {
      return null;
    }

    state.playing = false;
    state.playbackAccumulator = 0;
    state.currentFrameIndex = 0;
    state.frames = frames;
    state.selected = 1;
    const fpsMatch = text.match(/(\d+)\s*FPS/i);
    if (fpsMatch) state.fps = Math.min(60, Math.max(12, Number(fpsMatch[1])));
    const nameInput = document.getElementById('keyframeMotionName');
    if (nameInput && !nameInput.value.trim() && fileName) nameInput.value = fileName.replace(/\.[^.]+$/, '').slice(0, 60);
    rt.save();
    rt.selectFrame(1);
    return { count: frames.length, partial, fps: state.fps };
  }

  document.addEventListener('click', (event) => {
    const btn = event.target.closest && event.target.closest('#keyframeImportBtn');
    if (!btn) return;
    const input = document.getElementById('keyframeImportFile');
    if (input) input.click();
  });

  document.addEventListener('change', async (event) => {
    const input = event.target;
    if (!input || input.id !== 'keyframeImportFile') return;
    const file = input.files && input.files[0];
    input.value = '';
    if (!file) return;
    try {
      const result = importText(await file.text(), file.name);
      if (!result) { setStatus('Import cancel kiya.', ''); return; }
      let msg = result.count + ' frames import ho gaye (FPS ' + result.fps + '). Play dabao, phir Save Motion.';
      if (result.partial) msg += ' ' + result.partial + ' frames mein kuch bones nahi the.';
      setStatus(msg, 'ok');
    } catch (error) {
      console.error(error);
      setStatus(error.message || String(error), 'error');
    }
  });

  window.keyframeImporter = { importText };
})();
