# Import

Owns character file validation, parsing, and import orchestration.

- `import-validation.js`: accepted formats and input checks.
- `file-reader.js`: FBX and GLB/GLTF parsing via the loaded Three.js loaders.
- `import-manager.js`: file-input lifecycle, loading feedback, and handoff through `window.characterRuntime`.
- Imported motion parsing and retargeting live in `../imported-motions/`; this keeps animation-only FBX imports separate from character loading.

The app runtime registers these scripts in dependency order through the `import` feature entry in `build.py`; Viewer readiness comes from `window.viewerRuntime`.