async function readCharacterFile(file, format){
  const buffer = await file.arrayBuffer();
  if(format === 'fbx'){
    if(!THREE.FBXLoader) throw new Error('FBX loader is not available.');
    return { object: new THREE.FBXLoader().parse(buffer, ''), animations: null };
  }
  if(!THREE.GLTFLoader) throw new Error('GLB loader is not available.');
  return new Promise((resolve, reject)=>{
    new THREE.GLTFLoader().parse(buffer, '', result=>{
      resolve({ object: result.scene, animations: result.animations });
    }, reject);
  });
}