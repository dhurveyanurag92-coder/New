const characterFileInput = document.getElementById('file');
characterFileInput.addEventListener('change', async event=>{
  const file = event.target.files && event.target.files[0];
  event.target.value = '';
  if(!file) return;
  if(!window.viewerRuntime.isReady()){ window.appUI.toast('The 3D library is not ready yet.'); return; }
  window.appUI.toast('Loading ' + file.name + '…', 0);
  try{
    const format = validateCharacterFile(file);
    const result = await readCharacterFile(file, format);
    if(result.animations) result.object.animations = result.animations;
    const baseName = file.name.replace(/\.[^.]+$/, '');
    const found = window.characterRuntime.loadModel(result.object, file.name, baseName);
    document.getElementById('loading').hidden = true;
    window.appUI.toast('Loaded ' + file.name + (found.length ? ' · Detected animation: ' + found.join(', ') : ''), found.length ? 5000 : undefined);
  }catch(error){
    console.error(error);
    window.appUI.toast('Could not open ' + file.name + ': ' + (error.message || error), 6000);
  }
});