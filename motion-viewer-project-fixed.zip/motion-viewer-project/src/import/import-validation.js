function validateCharacterFile(file){
  if(!file) throw new Error('Choose a character file first.');
  const format = (file.name.split('.').pop() || '').toLowerCase();
  if(!['fbx', 'glb', 'gltf'].includes(format)) throw new Error('Please choose an .fbx or .glb file.');
  return format;
}