(function(){
  const state = {
    motions: [],
    selectedId: null,
    frameIndex: 0,
    playing: false,
    lastTime: 0,
    accumulator: 0,
    speed: 1,
    fps: 12,
    loop: true,
  };

  const selectedMotion = () => state.motions.find(motion => motion.id === state.selectedId) || null;
  const setStatus = message => {
    const node = document.getElementById('galleryStatus');
    if (node) node.textContent = message;
  };

  function applySelectedFrame(){
    const motion = selectedMotion();
    const frame = motion && motion.frames[state.frameIndex];
    if (frame && frame.pose) window.keyframeRuntime.applyPoseToRig(frame.pose);
  }

  function renderList(){
    const list = document.getElementById('galleryMotionList');
    const count = document.getElementById('galleryCount');
    if (!list || !count) return;
    list.textContent = '';
    count.textContent = state.motions.length + (state.motions.length === 1 ? ' motion' : ' motions');
    if (!state.motions.length) {
      const empty = document.createElement('p');
      empty.className = 'frameGalleryEmpty';
      empty.textContent = 'No saved motions yet. Create a motion in Keyframe and save it to see it here.';
      list.appendChild(empty);
      return;
    }
    for (const motion of state.motions) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'frameGalleryMotion';
      button.setAttribute('aria-pressed', String(motion.id === state.selectedId));
      const title = document.createElement('strong');
      title.textContent = motion.name;
      const detail = document.createElement('span');
      detail.textContent = motion.frames.length + ' frames · ' + (Number(motion.fps) || 30) + ' FPS';
      button.append(title, detail);
      button.addEventListener('click', () => selectMotion(motion.id));
      list.appendChild(button);
    }
  }

  function renderControls(){
    const play = document.getElementById('galleryPlay');
    const pause = document.getElementById('galleryPause');
    const speed = document.getElementById('gallerySpeed');
    const fps = document.getElementById('galleryFps');
    const speedValue = document.getElementById('gallerySpeedValue');
    const fpsValue = document.getElementById('galleryFpsValue');
    if (play) play.textContent = state.playing ? 'Playing' : 'Play';
    if (pause) pause.disabled = !state.playing;
    if (speed) speed.value = String(state.speed);
    if (speedValue) speedValue.textContent = Number(state.speed).toFixed(2).replace(/\.00$/, '') + '×';
    if (fps) fps.value = String(state.fps);
    if (fpsValue) fpsValue.textContent = String(state.fps);
  }

  function selectMotion(id){
    pausePlayback();
    const motion = state.motions.find(item => item.id === id);
    if (!motion) return;
    state.selectedId = motion.id;
    state.frameIndex = 0;
    state.fps = Math.min(60, Math.max(12, Number(motion.fps) || 30));
    state.speed = Math.min(2, Math.max(0.25, Number(motion.speed) || 1));
    state.loop = motion.loop !== false;
    applySelectedFrame();
    renderList();
    renderControls();
    setStatus('Selected "' + motion.name + '".');
  }

  function tick(now){
    if (!state.playing) return;
    const motion = selectedMotion();
    if (!motion || !motion.frames.length) {
      pausePlayback();
      return;
    }
    state.accumulator += (now - (state.lastTime || now)) / 1000 * state.fps * state.speed;
    state.lastTime = now;
    const steps = Math.floor(state.accumulator);
    if (steps > 0) {
      state.accumulator -= steps;
      const next = state.frameIndex + steps;
      if (next >= motion.frames.length) {
        if (state.loop) state.frameIndex = next % motion.frames.length;
        else {
          state.frameIndex = motion.frames.length - 1;
          state.playing = false;
          renderControls();
        }
      } else {
        state.frameIndex = next;
      }
      applySelectedFrame();
    }
    if (state.playing) requestAnimationFrame(tick);
  }

  function startPlayback(){
    if (!selectedMotion()) {
      setStatus('Select a saved motion before playing.');
      return;
    }
    if (state.playing) return;
    state.playing = true;
    state.lastTime = performance.now();
    state.accumulator = 0;
    renderControls();
    requestAnimationFrame(tick);
  }

  function pausePlayback(){
    state.playing = false;
    renderControls();
  }

  function stopPlayback(){
    pausePlayback();
    state.frameIndex = 0;
    applySelectedFrame();
  }

  function loadMotions(){
    try {
      state.motions = window.keyframeRuntime.getSavedMotions();
    } catch (error) {
      console.error(error);
      state.motions = [];
      setStatus(error.message || 'Saved motions could not be loaded.');
    }
    if (!state.motions.some(motion => motion.id === state.selectedId)) {
      state.selectedId = state.motions[0] ? state.motions[0].id : null;
    }
    if (state.selectedId) selectMotion(state.selectedId);
    else {
      renderList();
      renderControls();
    }
  }

  function mountFrameGallery(el){
    const template = document.getElementById('frameGalleryPageTpl');
    if (template) el.appendChild(template.content.cloneNode(true));
    const close = () => nav.go('home');
    document.getElementById('frameGalleryClose').addEventListener('click', close);
    document.querySelector('.frameGalleryShell .keyframeModalBackdrop').addEventListener('click', close);
    document.getElementById('frameGalleryMenuButton').addEventListener('click', () => nav.toggleMenu());
    document.getElementById('galleryPlay').addEventListener('click', startPlayback);
    document.getElementById('galleryPause').addEventListener('click', pausePlayback);
    document.getElementById('galleryStop').addEventListener('click', stopPlayback);
    document.getElementById('gallerySpeed').addEventListener('input', event => {
      state.speed = Number(event.currentTarget.value);
      renderControls();
    });
    document.getElementById('galleryFps').addEventListener('input', event => {
      state.fps = Number(event.currentTarget.value);
      renderControls();
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && nav.active === 'frame-gallery') close();
    });
  }

  function showFrameGallery(){
    const viewer = document.querySelector('.frameGalleryViewer');
    if (viewer && window.viewerRuntime) window.viewerRuntime.setCanvasHost(viewer);
    loadMotions();
  }

  function hideFrameGallery(){
    pausePlayback();
    if (window.viewerRuntime) window.viewerRuntime.setCanvasHost(document.getElementById('app'));
  }

  window.frameGalleryRuntime = {
    refresh: loadMotions,
    getState: () => state,
  };

  nav.registerPage({
    id: 'frame-gallery',
    label: 'Frame Gallery',
    order: 13,
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 15l3-3 2 2 3-4 3 5"/></svg>',
    canOpen(){
      if (window.characterRuntime && window.characterRuntime.getModel && window.characterRuntime.getModel()) return true;
      window.appUI.toast('Load a character before opening Frame Gallery.', 2800);
      return false;
    },
    mount: mountFrameGallery,
    onShow: showFrameGallery,
    onHide: hideFrameGallery,
  });
})();
