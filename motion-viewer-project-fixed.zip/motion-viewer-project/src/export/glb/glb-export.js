  function toGLB(clips){
    return new Promise((ok, no)=>{
      const model = window.motionRuntime.getModel();
      if(!THREE.GLTFExporter) return no(new Error('GLB exporter load nahi hua. Internet check karke page reload karo.'));
      window.motionRuntime.restoreBind(); model.updateMatrixWorld(true);
      let undo = ()=>{};
      try{
        undo = stripTwins(); model.updateMatrixWorld(true);
        new THREE.GLTFExporter().parse(model, r=>{ try{ undo(); }catch(_){} ok(r); }, { binary:true, animations:clips, onlyVisible:false });
      }catch(e){ try{ undo(); }catch(_){} no(e); }
    });
  }
  function save(buf, name){
    const url = URL.createObjectURL(new Blob([buf], { type:'model/gltf-binary' }));
    const a = document.createElement('a'); a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url), 5000);
  }
  async function run(list, fileName, say){
    const runtime = window.motionRuntime;
    if(st.busy) return; if(!runtime.getModel()){ say('Pehle character load karo.'); return; }
    st.busy = true; const saveT = runtime.getTime();
    try{
      const clips = [];
      for(const a of list){ say('Bake ho raha hai: ' + a.name + '…'); await pause(); clips.push(clipFor(a, st.fps)); }
      say('File ban rahi hai…'); await pause();
      const buf = await toGLB(clips);
      save(buf, fileName);
      say('Download ho gaya: ' + fileName + (clips.length ? ' (' + clips.length + ' motion, ' + st.fps + ' fps)' : ''));
    }catch(e){ console.error(e); say('Export fail: ' + (e.message || e)); }
    finally{ runtime.setTime(saveT); try{ resync(); }catch(_){} st.busy = false; }
  }
  const exportable = () => window.motionRuntime.getActions().filter(a=>a.name !== 'T-pose' && (a.imported || window.motionRuntime.getRig()));

  function mount(root){
    root.innerHTML = '<div class="fcPage"><div class="fcBar"><select class="expSel" id="expFps" aria-label="FPS"><option>24</option><option selected>30</option><option>60</option></select>'
      + '<button class="fcBtn primary" id="expAll" type="button">[ Download All ]</button><button class="fcBtn" id="expChar" type="button">[ Character only ]</button></div>'
      + '<p class="fcStatus" id="expStatus" role="status" aria-live="polite">Har motion frame-by-frame bake hokar .glb me jaata hai. Blender: File > Import > glTF 2.0.</p>'
      + '<div class="expList" id="expList"></div></div>';
    const say = m => { root.querySelector('#expStatus').textContent = m; };
    root.querySelector('#expFps').addEventListener('change', e=>{ st.fps = parseInt(e.target.value, 10) || 30; refresh(); });
    root.querySelector('#expAll').addEventListener('click', ()=>{ const l = exportable(); if(!l.length){ say('Export ke liye koi motion nahi mila.'); return; } run(l, charName() + '_all-motions.glb', say); });
    root.querySelector('#expChar').addEventListener('click', ()=>run([], charName() + '_character.glb', say));
    function refresh(){
      const box = root.querySelector('#expList'); box.textContent = '';
      const l = exportable();
      if(!l.length){ box.textContent = 'Koi motion nahi mila (Mixamo bones wala character chahiye).'; return; }
      for(const a of l){
        const d = a.imported ? (a.clip.duration || 0) : actionDuration(a);
        const row = document.createElement('div'); row.className = 'expRow';
        const w = document.createElement('div'); w.style.cssText = 'flex:1;min-width:0';
        const n = document.createElement('div'); n.className = 'n'; n.textContent = a.name;
        const m = document.createElement('div'); m.className = 'm'; m.textContent = a.category + ' · ' + d.toFixed(2) + 's' + (a.imported ? '' : ' · ' + (Math.round(d*st.fps)+1) + ' frames');
        w.append(n, m);
        const b = document.createElement('button'); b.type = 'button'; b.className = 'fcBtn'; b.textContent = 'Download';
        b.addEventListener('click', ()=>run([a], charName() + '_' + safe(a.name) + '.glb', say));
        row.append(w, b); box.appendChild(row);
      }
    }
    root._refresh = refresh; refresh();
  }
  nav.registerPage({
    id:'export-glb', label:'Export (GLB)', order:12,
    icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12M7 10l5 5 5-5M4 20h16"/></svg>',
    canOpen(){ if(window.motionRuntime.getModel()) return true; window.appUI.toast('Pehle character load hone do.', 3000); return false; },
    mount,
    onShow(){ const p = document.querySelector('#expList'); if(p && p.parentNode.parentNode._refresh) p.parentNode.parentNode._refresh(); }
  });
})();
