# GLB Export

Owns the GLB export page, animation baking, and export-only skeleton cleanup.

- `glb-export.js`: page controls, export selection, and download workflow.
- `glb-baker.js`: animation clip sampling and baking.
- `glb-skeleton.js`: export-only duplicate-bone handling.

The feature registers its page through `nav.registerPage` and reads motion/character state through the current app runtime contract.