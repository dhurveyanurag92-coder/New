/* Export page - bakes every motion (built-in, custom, imported) frame by frame into a .glb with the character.
   Opens in Blender (File > Import > glTF 2.0) and Prisma3D. Inlined into index.html by build.py. */
(function(){
  const st = { fps: 30, busy: false };
  const safe = s => String(s||'').trim().replace(/\s+/g,'-').replace(/[^a-zA-Z0-9._-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'') || 'Motion';
  const charName = () => safe((window.characterRuntime.getLabel() || 'Character').replace(/\(built in\)/i,'').replace(/\.[^.]+$/,''));
  const pause = () => new Promise(r=>setTimeout(r, 0));

  function bakeProcedural(a, fps){
    const runtime = window.motionRuntime;
    const rig = runtime.getRig(), holder = runtime.getHolder();
    const dur = runtime.getActionDuration(a), n = Math.max(2, Math.round(dur*fps) + 1);
    const keys = Object.keys(rig.rest), times = [], qv = {}, hp = [];
    keys.forEach(k=>qv[k] = []);
    const v = new THREE.Vector3(), inv = new THREE.Matrix4();
    const hips = rig.rest.Hips.bone;
    runtime.withAction(a, ()=>{
      for(let i=0; i<n; i++){
        const time = i/fps; times.push(time);
        runtime.evaluatePose(time, 1/fps); holder.updateMatrixWorld(true);
        for(const k of keys){ const q = rig.rest[k].bone.quaternion; qv[k].push(q.x, q.y, q.z, q.w); }
        hips.getWorldPosition(v); holder.worldToLocal(v); v.y += holder.position.y;
        inv.copy(holder.matrixWorld).invert().multiply(hips.parent.matrixWorld).invert();
        v.applyMatrix4(inv); hp.push(v.x, v.y, v.z);
      }
    });
    for(const k of keys){                                   // keep q and -q from flipping between frames (Blender interpolates per component)
      const a4 = qv[k];
      for(let i=4; i<a4.length; i+=4){
        if(a4[i]*a4[i-4] + a4[i+1]*a4[i-3] + a4[i+2]*a4[i-2] + a4[i+3]*a4[i-1] < 0){ a4[i]=-a4[i]; a4[i+1]=-a4[i+1]; a4[i+2]=-a4[i+2]; a4[i+3]=-a4[i+3]; }
      }
    }
    const tracks = keys.map(k=>new THREE.QuaternionKeyframeTrack(rig.rest[k].bone.name + '.quaternion', times, qv[k]));
    tracks.push(new THREE.VectorKeyframeTrack(hips.name + '.position', times, hp));
    return new THREE.AnimationClip(a.name, -1, tracks);
  }
  function resync(){                                        // put the viewer back exactly as the user had it
    const runtime = window.motionRuntime;
    const current = runtime.getCurrent();
    if(current && current.imported){ runtime.restoreBind(); const mixer = runtime.getMixer(); if(mixer) mixer.update(0); }
    else runtime.evaluatePose(runtime.getTime(), 0);
  }
  function clipFor(a, fps){
    if(a.imported) return a.clip;
    if(!window.motionRuntime.getRig()) throw new Error('Is character me Mixamo bones nahi hain, isliye "' + a.name + '" export nahi ho sakta.');
    return bakeProcedural(a, fps);
  }
