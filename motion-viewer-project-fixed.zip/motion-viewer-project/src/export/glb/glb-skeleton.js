  /* The character has two skinned meshes (Beta_Surface + Beta_Joints). Beta_Joints is skinned to "twin" bones:
     same-named leaf copies parented under each real bone. Prisma3D applies an animation track to EVERY bone with that
     name, so the twin rotated on top of its parent = double rotation = a second, over-bent character (only visible when
     the angles get big, e.g. the bend-over). Fix: for the export only, point Beta_Joints at the real bones, drop the
     twins, and put everything back afterwards. Bind pose is identical (twins have identity local transform). */
  function stripTwins(){
    const model = window.motionRuntime.getModel();
    const normalizeBoneName = window.characterRuntime.normalizeBoneName;
    const twins = new Map(), undo = [];
    model.traverse(o=>{ if(o.isBone && o.parent && o.parent.isBone && normalizeBoneName(o.name) === normalizeBoneName(o.parent.name)) twins.set(o, o.parent); });
    if(!twins.size) return ()=>{};
    const real = b=>{ let r = b, n = 0; while(twins.has(r) && n++ < 8) r = twins.get(r); return r; };
    model.traverse(o=>{
      if(!o.isSkinnedMesh || !o.skeleton) return;
      const sk = o.skeleton;
      if(!sk.bones.some(b=>twins.has(b))) return;
      o.skeleton = new THREE.Skeleton(sk.bones.map(real), sk.boneInverses.map(m=>m.clone()));
      undo.push(()=>{ o.skeleton = sk; });
    });
    for(const [t, p] of twins){
      const i = p.children.indexOf(t); p.remove(t);
      undo.push(()=>{ p.children.splice(Math.min(i, p.children.length), 0, t); t.parent = p; });
    }
    return ()=>{ for(let i = undo.length - 1; i >= 0; i--) undo[i](); model.updateMatrixWorld(true); };
  }
