const CAMERA_DIRECTIONS = {
  front: 0,
  back: Math.PI,
  left: Math.PI / 2,
  right: -Math.PI / 2,
  'front-left': Math.PI / 4,
  'front-right': -Math.PI / 4,
  'back-left': 3 * Math.PI / 4,
  'back-right': -3 * Math.PI / 4,
};

function setCameraDirection(direction){
  const target = CAMERA_DIRECTIONS[direction];
  if(!Number.isFinite(target)) return;
  let delta = (target - cam.thT) % (2 * Math.PI);
  if(delta > Math.PI) delta -= 2 * Math.PI;
  if(delta < -Math.PI) delta += 2 * Math.PI;
  cam.thT += delta;
  cam.phT = 1.45;
}
