const positionDirections = ['up', 'left', 'right', 'down'];
const positionButtons = positionDirections.map(direction => document.getElementById('move' + direction[0].toUpperCase() + direction.slice(1)));
const positionLock = document.getElementById('positionLock');
const cameraTools = document.getElementById('cameraTools');
const cameraToolsToggle = document.getElementById('cameraToolsToggle');

function setCameraToolsOpen(open){
  cameraTools.hidden = !open;
  cameraToolsToggle.setAttribute('aria-expanded', String(open));
}

cameraToolsToggle.addEventListener('click', ()=>setCameraToolsOpen(cameraTools.hidden));
document.addEventListener('pointerdown', event=>{
  if(!cameraTools.hidden && !cameraTools.contains(event.target) && !cameraToolsToggle.contains(event.target)) setCameraToolsOpen(false);
});
document.addEventListener('keydown', event=>{
  if(event.key === 'Escape' && !cameraTools.hidden){
    setCameraToolsOpen(false);
    cameraToolsToggle.focus({preventScroll:true});
  }
});

function updatePositionLock(){
  positionLock.setAttribute('aria-pressed', String(cameraPositionLocked));
  positionLock.setAttribute('aria-label', cameraPositionLocked ? 'Unlock model position' : 'Lock model position');
  positionLock.title = cameraPositionLocked ? 'Unlock model position' : 'Lock model position';
  positionLock.textContent = cameraPositionLocked ? 'Locked' : 'Lock';
  positionButtons.forEach(button=>{ button.disabled = cameraPositionLocked; });
}

function moveModelInView(direction){
  if(cameraPositionLocked) return;
  const step = Math.max(0.04, cam.r * 0.05);
  const rightX = Math.cos(cam.th), rightZ = -Math.sin(cam.th);
  if(direction === 'left'){ TARGET.x += rightX * step; TARGET.z += rightZ * step; }
  if(direction === 'right'){ TARGET.x -= rightX * step; TARGET.z -= rightZ * step; }
  if(direction === 'up') TARGET.y -= step;
  if(direction === 'down') TARGET.y += step;
}

positionDirections.forEach(direction=>{
  const button = document.getElementById('move' + direction[0].toUpperCase() + direction.slice(1));
  button.addEventListener('click', ()=>moveModelInView(direction));
});
positionLock.addEventListener('click', ()=>{
  cameraPositionLocked = !cameraPositionLocked;
  updatePositionLock();
});
document.getElementById('zoomIn').addEventListener('click', ()=>{ cam.rT = Math.max(1.3, cam.rT / 1.18); });
document.getElementById('zoomOut').addEventListener('click', ()=>{ cam.rT = Math.min(9, cam.rT * 1.18); });
updatePositionLock();