# Viewer

Owns the Three.js scene, camera input, rendering, and camera presets.

- `viewer-runtime.js`: renderer, scene startup, and camera input events.
- `viewer-state.js`: camera targets, pointers, and readiness state.
- `camera-position.js`: compact Position popover, pan buttons, position lock, and zoom controls.
- `render-loop.js`: per-frame camera and scene rendering.
- `directions/camera-directions.js`: cardinal and diagonal camera presets.
- `viewer.html` / `viewer.css`: viewer markup and presentation.

Character and motion data are accessed through the app runtime contracts; the compact camera-view selector uses keys from the preset map.