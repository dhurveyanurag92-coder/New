/* ------------------------------------------------------------------ 3D side */
let THREE, renderer, scene, camera, holder, ring;
let resizeObserver;
let homeCameraDistance;
let _e, _q, _d, _v;
window.viewerRuntime = {
  isReady: () => THREE_OK,
  getScene: () => scene,
  setCanvasHost(host){
    const target = host || el.app;
    const enteringModal = target !== el.app && el.canvas.parentElement === el.app;
    const leavingModal = target === el.app && el.canvas.parentElement !== el.app;
    if(enteringModal){
      homeCameraDistance = cam.r;
      const aspect = target.clientWidth / target.clientHeight;
      cam.r = cam.rT = Math.min(8, Math.max(3.6, 3.6 / aspect));
    } else if(leavingModal && homeCameraDistance){
      cam.r = cam.rT = homeCameraDistance;
      homeCameraDistance = undefined;
    }
    target.appendChild(el.canvas);
    if(resizeObserver) resizeObserver.observe(target);
    requestAnimationFrame(()=>resize());
  },
};

function loadScript(u){
  return new Promise((ok,no)=>{
    const s = document.createElement('script'); s.src = u;
    s.onload = ()=>ok(u); s.onerror = ()=>no(new Error('Could not load '+u));
    document.head.appendChild(s);
  });
}
const V = '0.128.0', BASE = 'https://cdn.jsdelivr.net/npm/three@'+V;

async function boot(){
  try{ await loadScript(BASE+'/build/three.min.js'); }
  catch(e){ return fatal('The 3D library could not be loaded. Check your internet connection and reload the page.'); }
  THREE = window.THREE;
  await Promise.allSettled([
    loadScript(BASE+'/examples/js/libs/fflate.min.js'),
    loadScript(BASE+'/examples/js/libs/inflate.min.js'),
    loadScript(BASE+'/examples/js/loaders/FBXLoader.js'),
    loadScript(BASE+'/examples/js/loaders/GLTFLoader.js'),
    loadScript(BASE+'/examples/js/exporters/GLTFExporter.js')
  ]);
  if(!window.fflate){ try{ await loadScript('https://cdn.jsdelivr.net/npm/fflate@0.7.4/umd/index.js'); }catch(e){} }
  try{ initScene(); }
  catch(e){ console.error(e); return fatal('Your browser could not start 3D graphics (WebGL). Try Chrome.'); }
  THREE_OK = true;

  if(THREE.FBXLoader){
    try{ setModel(new THREE.FBXLoader().parse(b64ToBuf(DEFAULT_FBX_B64), ''), DEFAULT_NAME + ' (built in)', DEFAULT_NAME.replace(/\.[^.]+$/, '')); el.loading.hidden = true; }
    catch(e){ console.error(e); fatal('The built-in character failed to load: ' + (e.message||e) + '. You can still Import a .glb file.'); }
  } else {
    fatal('The FBX loader could not be loaded. You can still Import a .glb file.');
  }
  toast('Tap a movement below. It plays in a loop until you press Pause.', 4200);
}
function b64ToBuf(b){ const s = atob(b), u = new Uint8Array(s.length); for(let i=0;i<s.length;i++) u[i] = s.charCodeAt(i); return u.buffer; }

/* ---- scene, lights, stage */
function initScene(){
  _e = new THREE.Euler(); _q = new THREE.Quaternion(); _d = new THREE.Quaternion(); _v = new THREE.Vector3();
  renderer = new THREE.WebGLRenderer({ canvas:el.canvas, antialias:true, alpha:true, powerPreference:'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(38, 1, 0.05, 100);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x5b6b78, 0.95));
  const key = new THREE.DirectionalLight(0xffffff, 1.05);
  key.position.set(2.5, 5, 3.5); key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  Object.assign(key.shadow.camera, { left:-3, right:3, top:3, bottom:-3, near:0.5, far:14 });
  key.shadow.camera.updateProjectionMatrix();
  key.shadow.bias = -0.0006;
  scene.add(key);
  const rim = new THREE.DirectionalLight(0xbcd4ff, 0.55); rim.position.set(-3, 3, -4); scene.add(rim);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), new THREE.ShadowMaterial({ opacity:0.28 }));
  ground.rotation.x = -Math.PI/2; ground.receiveShadow = true; scene.add(ground);
  ring = new THREE.Mesh(new THREE.RingGeometry(0.64, 0.675, 96), new THREE.MeshBasicMaterial({ color:0x0a7c76, transparent:true, opacity:0.6 }));
  ring.rotation.x = -Math.PI/2; ring.position.y = 0.003; scene.add(ring);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(0.64, 96), new THREE.MeshBasicMaterial({ color:0xffffff, transparent:true, opacity:0.10 }));
  disc.rotation.x = -Math.PI/2; disc.position.y = 0.002; scene.add(disc);

  holder = new THREE.Group(); scene.add(holder);
  syncTheme();
  new MutationObserver(syncTheme).observe(document.documentElement, { attributes:true, attributeFilter:['data-theme'] });
  if(window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', syncTheme);

  resizeObserver = new ResizeObserver(()=>resize());
  resizeObserver.observe(el.app);
  resizeObserver.observe(el.panel);
  resize(true);
  requestAnimationFrame(frame);
}
function syncTheme(){
  if(!ring) return;
  const c = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
  if(c) ring.material.color.set(c);
}

/* ---- camera: 360 degrees around a fixed point, the character never moves */
function resize(first){
  const canvasHost = el.canvas.parentElement;
  const inModal = canvasHost && canvasHost !== el.app;
  const viewport = inModal ? canvasHost : el.app;
  const w = viewport.clientWidth, h = viewport.clientHeight; if(!w || !h) return;
  const ph = inModal ? 0 : el.panel.offsetHeight;
  const hh = inModal ? 0 : $('#appHeader').offsetHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w/h;
  if(inModal){
    camera.clearViewOffset();
  } else {
    camera.setViewOffset(w, h, 0, (ph - hh)/2, w, h);          // centres the character in the free space above the panel
  }
  camera.updateProjectionMatrix();
  if(!cam.fitted || first === true){
    const fa = Math.max(0.35, (h-ph-hh)/h);
    const r = Math.min(9, Math.max(2.8, 3.05/fa, 2.85/camera.aspect));
    cam.r = cam.rT = r; cam.fitted = true;
  }
}
el.canvas.addEventListener('pointerdown', e=>{ el.canvas.setPointerCapture(e.pointerId); pointers.set(e.pointerId, {x:e.clientX, y:e.clientY}); pinchD = 0; });
el.canvas.addEventListener('pointermove', e=>{
  const p = pointers.get(e.pointerId); if(!p) return;
  const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
  if(pointers.size === 1){
    cam.thT -= dx*0.0075; cam.phT = Math.min(Math.PI-0.22, Math.max(0.22, cam.phT - dy*0.0060));
  } else if(pointers.size === 2){
    const [a,b] = [...pointers.values()]; const d = Math.hypot(a.x-b.x, a.y-b.y);
    if(pinchD) cam.rT = Math.min(9, Math.max(1.3, cam.rT * (pinchD/d)));
    pinchD = d;
  }
});
const endPtr = e=>{ pointers.delete(e.pointerId); pinchD = 0; };
el.canvas.addEventListener('pointerup', endPtr); el.canvas.addEventListener('pointercancel', endPtr);
el.canvas.addEventListener('wheel', e=>{ e.preventDefault(); cam.rT = Math.min(9, Math.max(1.3, cam.rT*Math.exp(e.deltaY*0.0012))); }, { passive:false });
document.getElementById('cameraView').addEventListener('change', event=>setCameraDirection(event.target.value));
