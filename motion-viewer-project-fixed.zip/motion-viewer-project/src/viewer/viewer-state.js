const cam = { th:0.35, ph:1.42, r:4.2, thT:0.35, phT:1.42, rT:4.2, fitted:false };
const TARGET = { x:0, y:0.95, z:0 };
const pointers = new Map();
let pinchD = 0;
let THREE_OK = false;
let cameraPositionLocked = false;