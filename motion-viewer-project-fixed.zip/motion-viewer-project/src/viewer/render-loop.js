/* ---- main loop */
let last = performance.now();
let playbackUiElapsed = 0;
function frame(now){
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now-last)/1000); last = now;
  playbackUiElapsed += dt;
  if(playing){
    if(current && current.imported){
      if(mixer) mixer.update(dt*speed);
      if(!loopPlayback && activeAct && activeAct.time >= current.clip.duration){
        activeAct.time = current.clip.duration;
        if(mixer) mixer.update(0);
        playing = false;
        syncUI();
      }
    }
    else if(rig){ t += dt*speed; evalPose(t, dt*speed); if(!el.editWrap.hidden) syncEditClock(); }
  }
  updatePoseTransition(dt);
  if(window.solverVisualization) window.solverVisualization.update();
  const k = 1 - Math.exp(-dt*14);
  cam.th += (cam.thT-cam.th)*k; cam.ph += (cam.phT-cam.ph)*k; cam.r += (cam.rT-cam.r)*k;
  camera.position.set(
    TARGET.x + cam.r*Math.sin(cam.ph)*Math.sin(cam.th),
    TARGET.y + cam.r*Math.cos(cam.ph),
    TARGET.z + cam.r*Math.sin(cam.ph)*Math.cos(cam.th));
  camera.lookAt(TARGET.x, TARGET.y, TARGET.z);
  if(!el.editWrap.hidden){                            // while editing, lift the character into the visible top part of the screen
    const W = el.canvas.clientWidth, H = el.canvas.clientHeight; camera.setViewOffset(W, H, 0, H*0.2, W, H);
  } else if(camera.view && camera.view.enabled) camera.clearViewOffset();
  renderer.render(scene, camera);
  if(playbackUiElapsed >= 0.08){ syncPlaybackUI(); playbackUiElapsed = 0; }
}

