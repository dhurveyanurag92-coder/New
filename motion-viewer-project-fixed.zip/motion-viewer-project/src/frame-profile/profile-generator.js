(function(){
  const PROFILE_STORAGE = 'motion-viewer-frame-profile-v1';

  function getBoneHierarchy(registry){
    const entries = registry && registry.bones ? registry.bones : [];
    const root = { name: 'Root', children: [] };
    const map = new Map();
    const processed = new Set();
    map.set('Root', root);
    for (const record of entries) {
      if (record.isAuxiliaryClone) continue;
      const key = record.originalName || record.bone && record.bone.name || String(record.name || '');
      if (!key || processed.has(key)) continue;
      processed.add(key);
      const node = map.get(key) || { name: key, children: [] };
      node.originalName = key;
      node.semanticRole = record.semanticRole || record.normalizedName || 'unknown';
      node.side = record.side || 'Center';
      node.parent = record.parent || 'Root';
      map.set(key, node);
      if (!map.has(node.parent)) map.set(node.parent, { name: node.parent, children: [] });
      const parentNode = map.get(node.parent);
      if (parentNode && parentNode !== node) {
        if (!parentNode.children.some(child => child.name === node.name)) parentNode.children.push(node);
      }
    }
    return root;
  }

  function formatHierarchy(root, indent = '', seen = new Set()){
    if (!root) return `${indent}Root`;
    if (seen.has(root.name)) return `${indent}${root.name}`;
    seen.add(root.name);
    const rows = [`${indent}${root.name}`];
    const children = Array.isArray(root.children) ? root.children : [];
    for (const child of children) rows.push(formatHierarchy(child, indent + '  ', seen));
    return rows.join('\n');
  }

  function formatRotation(value){
    if (Array.isArray(value)) return value;
    if (value && value.w != null && window.THREE) {
      const euler = new THREE.Euler().setFromQuaternion(value, 'XYZ');
      return [euler.x, euler.y, euler.z];
    }
    return [value && value.x || 0, value && value.y || 0, value && value.z || 0];
  }

  function buildProfileText(){
    const model = window.characterRuntime && window.characterRuntime.getModel && window.characterRuntime.getModel();
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry && window.characterRuntime.getSkeletonRegistry();
    const rig = window.motionRuntime && window.motionRuntime.getRig && window.motionRuntime.getRig();
    const bones = registry && registry.bones ? registry.bones : [];
    const hierarchy = getBoneHierarchy(registry);
    const lines = [];
    lines.push('AI FRAME PROFILE');
    lines.push('FRAME_CODE_VERSION: 1');
    lines.push('');
    lines.push('Character');
    lines.push('  Character ID: ' + (model ? (model.uuid || 'current-character') : 'unknown')); 
    lines.push('  Model information: ' + ((model && model.name) || 'Loaded scene model'));
    lines.push('  World coordinate system: Three.js right-handed, Y-up');
    lines.push('  Up axis: Y');
    lines.push('  Character forward axis: model-dependent; do not assume +Z');
    lines.push('  Position units: Three.js scene units; the imported asset may not encode meters');
    lines.push('  Model scale: ' + (model && model.scale ? JSON.stringify([model.scale.x, model.scale.y, model.scale.z]) : 'not available'));
    lines.push('  Rest pose: transforms captured when the character rig was registered');
    lines.push('');
    lines.push('Skeleton Information');
    const boneList = bones.length
      ? bones.filter((bone, index, list) => {
        if (bone.isAuxiliaryClone) return false;
        const name = bone.originalName || bone.bone && bone.bone.name || bone.normalizedName || bone.name || '';
        return name && list.findIndex(candidate => !candidate.isAuxiliaryClone && (candidate.originalName || candidate.bone && candidate.bone.name || candidate.normalizedName || candidate.name || '') === name) === index;
      })
      : (rig && rig.rest ? Object.keys(rig.rest).map(key => ({ originalName: key, normalizedName: key, semanticRole: key, mappingStatus: 'rig-direct', mappingConfidence: 1, parent: 'Root', children: [], side: 'Center', chain: 'Other', depth: 0, localPosition: { x: 0, y: 0, z: 0 }, worldPosition: { x: 0, y: 0, z: 0 }, localRotation: { x: 0, y: 0, z: 0 }, worldRotation: { x: 0, y: 0, z: 0 }, restPosition: { x: 0, y: 0, z: 0 }, restRotation: { x: 0, y: 0, z: 0 }, boneLength: 0 })) : []);
    for (const bone of boneList) {
      const name = bone.originalName || bone.bone && bone.bone.name || bone.normalizedName || bone.name || 'unknown';
      lines.push('  - ' + name);
      lines.push('      Normalized Name: ' + (bone.normalizedName || name));
      lines.push('      Semantic Role: ' + (bone.semanticRole || 'unknown'));
      lines.push('      Mapping Status: ' + (bone.mappingStatus || 'unmapped'));
      lines.push('      Mapping Confidence: ' + (bone.mappingConfidence != null ? bone.mappingConfidence : 0));
      lines.push('      Parent: ' + (bone.parent || 'Root'));
      lines.push('      Children: ' + (Array.isArray(bone.children) ? bone.children.join(', ') : 'none'));
      lines.push('      Depth: ' + (bone.depth != null ? bone.depth : 0));
      lines.push('      Side: ' + (bone.side || 'Center'));
      lines.push('      Chain: ' + (bone.chain || 'Other'));
      lines.push('      Local Position: ' + JSON.stringify(Array.isArray(bone.localPosition) ? bone.localPosition : [bone.localPosition && bone.localPosition.x || 0, bone.localPosition && bone.localPosition.y || 0, bone.localPosition && bone.localPosition.z || 0]));
      lines.push('      World Position: ' + JSON.stringify(Array.isArray(bone.worldPosition) ? bone.worldPosition : [bone.worldPosition && bone.worldPosition.x || 0, bone.worldPosition && bone.worldPosition.y || 0, bone.worldPosition && bone.worldPosition.z || 0]));
      lines.push('      Local Rotation (Euler XYZ radians): ' + JSON.stringify(formatRotation(bone.localRotation)));
      lines.push('      World Rotation (Euler XYZ radians): ' + JSON.stringify(formatRotation(bone.worldRotation)));
      lines.push('      Rest Position: ' + JSON.stringify(Array.isArray(bone.restPosition) ? bone.restPosition : [bone.restPosition && bone.restPosition.x || 0, bone.restPosition && bone.restPosition.y || 0, bone.restPosition && bone.restPosition.z || 0]));
      lines.push('      Rest Rotation (Euler XYZ radians): ' + JSON.stringify(formatRotation(bone.restRotation)));
      lines.push('      Bone Length: ' + (bone.boneLength != null ? bone.boneLength : 0));
    }
    lines.push('');
    lines.push('Bone Hierarchy');
    lines.push(formatHierarchy(hierarchy));
    lines.push('');
    lines.push('Coordinate and Rotation specification');
    lines.push('  World axes: X/Y/Z follow Three.js world coordinates; +Y is up.');
    lines.push('  Character left/right/forward must be inferred from this model and its current pose.');
    lines.push('  Rotation unit: radians in Euler XYZ order');
    lines.push('  Position unit: Three.js scene units; do not convert to meters without verified asset scale.');
    lines.push('  Local vs world transform: parent-relative local transforms are preferred for animation code; world transforms are for reference only');
    lines.push('');
    lines.push('Frame Code Specification');
    lines.push('FRAME_CODE_VERSION: 1');
    lines.push('  Required sections: frame, root, and bones.');
    lines.push('  root.position and root.rotation are three-number arrays; rotations are radians, Euler XYZ.');
    lines.push('  Each bone name must exactly match a name listed in Skeleton Information.');
    lines.push('  Bone names are JSON-style quoted strings so FBX names with punctuation remain valid.');
    lines.push('  Bone position and rotation are parent-relative local transforms.');
    lines.push('');
    lines.push('Valid syntax example using an actual bone from this model');
    const exampleName = boneList[0]
      ? (boneList[0].originalName || boneList[0].bone && boneList[0].bone.name || boneList[0].name || '')
      : '';
    lines.push('FRAME_CODE_VERSION: 1');
    lines.push('frame: 1');
    lines.push('root:');
    lines.push('  position: [0.0000, 0.0000, 0.0000]');
    lines.push('  rotation: [0.0000, 0.0000, 0.0000]');
    lines.push('bones:');
    if (exampleName) {
      lines.push('  ' + JSON.stringify(exampleName) + ':');
      lines.push('    position: [0.0000, 0.0000, 0.0000]');
      lines.push('    rotation: [0.0000, 0.0000, 0.0000]');
    } else {
      lines.push('  # Add a quoted exact bone name from this profile.');
      lines.push('  # "ExactBoneName":');
      lines.push('  #   position: [0.0000, 0.0000, 0.0000]');
      lines.push('  #   rotation: [0.0000, 0.0000, 0.0000]');
    }
    lines.push('');
    lines.push('AI FRAME GENERATION RULES');
    lines.push('1. Use only exact bone names from this profile; never invent or rename a bone.');
    lines.push('2. Treat the supplied current frame as the reference pose and preserve all unrequested values.');
    lines.push('3. Use scene units for positions and radians in Euler XYZ order for rotations.');
    lines.push('4. Keep parent-relative local transforms; do not substitute world positions for bone transforms.');
    lines.push('5. Return only valid FRAME_CODE_VERSION 1 text, without Markdown or explanatory prose.');
    lines.push('6. Every vector must be exactly [number, number, number].');
    lines.push('');
    const profile = lines.join('\n');
    try { localStorage.setItem(PROFILE_STORAGE, profile); } catch (error) {}
    return profile;
  }

  function mountFrameProfilePage(el){
    if (!el) return;
    const template = document.getElementById('frameProfilePageTpl');
    if (template) el.appendChild(template.content.cloneNode(true));
    const textarea = document.getElementById('frameProfileText');
    const status = document.getElementById('frameProfileStatus');
    const refresh = document.getElementById('frameProfileRefresh');
    const copy = document.getElementById('frameProfileCopy');
    const download = document.getElementById('frameProfileDownload');
    const update = () => {
      const text = buildProfileText();
      if (textarea) textarea.value = text;
      if (status) status.textContent = 'Profile refreshed.';
      status && status.classList.remove('error');
      status && status.classList.add('ok');
    };
    if (refresh) refresh.addEventListener('click', update);
    if (copy) copy.addEventListener('click', async () => {
      if (!textarea) return;
      try {
        await navigator.clipboard.writeText(textarea.value);
        if (status) { status.textContent = 'Profile copied to clipboard.'; status.classList.remove('error'); status.classList.add('ok'); }
      } catch (error) {
        if (status) { status.textContent = 'Clipboard access is unavailable in this browser.'; status.classList.remove('ok'); status.classList.add('error'); }
      }
    });
    if (download) download.addEventListener('click', () => {
      if (!textarea) return;
      const blob = new Blob([textarea.value], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url; link.download = 'ai-frame-profile.txt';
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      if (status) { status.textContent = 'TXT file downloaded.'; status.classList.remove('error'); status.classList.add('ok'); }
    });
    update();
  }

  function showFrameProfilePage(){
    const textArea = document.getElementById('frameProfileText');
    if (textArea) textArea.value = buildProfileText();
  }

  window.frameProfileRuntime = {
    generate: buildProfileText,
    copyText: async function(text){
      if (!navigator.clipboard) return false;
      await navigator.clipboard.writeText(text);
      return true;
    },
  };

  nav.registerPage({
    id: 'frame-profile',
    label: 'Frame Profile',
    order: 11,
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 4h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M8 8h8M8 12h8M8 16h6"/></svg>',
    canOpen(){
      if (window.characterRuntime && window.characterRuntime.getModel && window.characterRuntime.getModel()) return true;
      window.appUI.toast('Load a character before opening the frame profile.', 2800);
      return false;
    },
    mount: mountFrameProfilePage,
    onShow: showFrameProfilePage,
  });
})();
