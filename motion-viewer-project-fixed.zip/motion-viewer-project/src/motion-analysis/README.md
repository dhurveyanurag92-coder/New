# Motion Analysis

Owns its page state, numeric analysis, rendering, events, and JSON/clipboard export.

- `analysis-engine.js`: combines the feature calculations into the report model.
- `analysis-math.js` and `quaternion-analysis.js`: vector/Euler helpers and shortest-path rotation deltas.
- `frame-analysis.js`: frame-to-frame and selected-range analysis.
- `movement-analysis.js`: repeated movement-cycle detection.
- `analysis-renderer.js`, `analysis-events.js`, and `analysis-export.js`: page UI, interactions, and output.

Canonical frame snapshots come from the shared `window.motionDataApi` contract.