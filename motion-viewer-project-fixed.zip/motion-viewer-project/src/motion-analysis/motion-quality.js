(function(){
  function safeArray(value){ return Array.isArray(value) ? value : []; }
  function safeFinite(value){ return Number.isFinite(Number(value)) ? Number(value) : 0; }
  function safeVector4(value){
    const v = value || [0, 0, 0, 1];
    return [safeFinite(v[0]), safeFinite(v[1]), safeFinite(v[2]), safeFinite(v[3] || 1)];
  }
  function clamp(value, minimum, maximum){ return Math.min(maximum, Math.max(minimum, value)); }
  function quatFromEuler(euler){
    const q = new THREE.Quaternion();
    q.setFromEuler(new THREE.Euler(safeFinite(euler && euler[0]), safeFinite(euler && euler[1]), safeFinite(euler && euler[2]), 'XYZ'));
    return q;
  }
  function quatDelta(a, b){
    const qa = new THREE.Quaternion(safeVector4(a)[0], safeVector4(a)[1], safeVector4(a)[2], safeVector4(a)[3]);
    const qb = new THREE.Quaternion(safeVector4(b)[0], safeVector4(b)[1], safeVector4(b)[2], safeVector4(b)[3]);
    const delta = qa.clone().multiply(qb.clone().invert());
    return 2 * Math.acos(clamp(Math.abs(delta.w), -1, 1));
  }
  function motionQualityGetBoneNameMap(frame){
    if (!frame || !frame.bones) return {};
    const map = {};
    for (const [name, bone] of Object.entries(frame.bones)) {
      map[name] = bone;
    }
    return map;
  }
  function detectFootSliding(frames){
    const warnings = [];
    const footNames = ['LeftFoot', 'RightFoot', 'LeftAnkle', 'RightAnkle'];
    for (let index = 1; index < frames.length; index++) {
      const prev = frames[index - 1];
      const current = frames[index];
      const prevBones = motionQualityGetBoneNameMap(prev);
      const currentBones = motionQualityGetBoneNameMap(current);
      for (const foot of footNames) {
        const prevBone = prevBones[foot] || null;
        const currentBone = currentBones[foot] || null;
        if (!prevBone || !currentBone || !Array.isArray(prevBone.position) || !Array.isArray(currentBone.position)) continue;
        const delta = Math.hypot(
          currentBone.position[0] - prevBone.position[0],
          currentBone.position[1] - prevBone.position[1],
          currentBone.position[2] - prevBone.position[2]
        );
        if (delta > 0.08) {
          warnings.push('FOOT SLIDING WARNING at frame ' + current.number + ' for ' + foot + ' (' + delta.toFixed(3) + ' units)');
        }
      }
    }
    return warnings;
  }
  function detectMotionPhases(frames){
    if (!frames || frames.length < 2) return [];
    const labels = ['PREPARE', 'CONTACT', 'LOAD', 'PUSH', 'FLIGHT', 'AIRBORNE', 'LAND', 'RECOVER'];
    const phaseCount = Math.min(labels.length, Math.max(1, Math.ceil(frames.length / 4)));
    const phases = [];
    for (let i = 0; i < phaseCount; i++) {
      const start = Math.floor((frames.length - 1) * (i / phaseCount));
      const end = Math.floor((frames.length - 1) * ((i + 1) / phaseCount));
      const frame = frames[Math.min(start, frames.length - 1)] || frames[0];
      phases.push({
        label: labels[i % labels.length],
        startFrame: frame.number || 1,
        endFrame: (frames[Math.min(end, frames.length - 1)] || frames[frames.length - 1]).number || frames.length,
      });
    }
    return phases;
  }
  function validateJointLimits(frames){
    const warnings = [];
    const jointNames = ['Hips', 'Spine', 'Neck', 'Head', 'LeftShoulder', 'RightShoulder', 'LeftUpLeg', 'RightUpLeg', 'LeftLeg', 'RightLeg', 'LeftFoot', 'RightFoot'];
    for (let i = 0; i < frames.length; i++) {
      const frame = frames[i];
      const bones = frame && frame.bones ? frame.bones : {};
      for (const joint of jointNames) {
        const bone = bones[joint];
        if (!bone || !Array.isArray(bone.rotation)) continue;
        const euler = bone.rotation;
        const rads = [safeFinite(euler[0]), safeFinite(euler[1]), safeFinite(euler[2])];
        const amplitude = Math.max(Math.abs(rads[0]), Math.abs(rads[1]), Math.abs(rads[2]));
        if (amplitude > 2.2) {
          warnings.push('JOINT LIMIT WARNING at frame ' + (frame.number || i + 1) + ' on ' + joint + ' (' + amplitude.toFixed(3) + ' rad)');
        }
      }
    }
    return warnings;
  }
  function validateRootMotion(frames){
    const warnings = [];
    for (let i = 1; i < frames.length; i++) {
      const prev = frames[i - 1];
      const current = frames[i];
      if (!prev || !current || !prev.root || !current.root) continue;
      const prevPos = prev.root.position || [0, 0, 0];
      const currPos = current.root.position || [0, 0, 0];
      const delta = Math.hypot(
        currPos[0] - prevPos[0],
        currPos[1] - prevPos[1],
        currPos[2] - prevPos[2]
      );
      const previousQuat = quatFromEuler(prev.root.rotation || [0, 0, 0]);
      const currentQuat = quatFromEuler(current.root.rotation || [0, 0, 0]);
      const angle = quatDelta(previousQuat, currentQuat);
      if (delta > 1.5 || angle > 1.9) {
        warnings.push('ROOT MOTION WARNING at frame ' + current.number + ' (' + delta.toFixed(3) + ' | ' + angle.toFixed(3) + ')');
      }
    }
    return warnings;
  }
  function analyzeFrames(frames){
    const list = safeArray(frames).filter(Boolean);
    const warnings = [];
    const phaseSummary = detectMotionPhases(list);
    warnings.push(...detectFootSliding(list));
    warnings.push(...validateJointLimits(list));
    warnings.push(...validateRootMotion(list));
    for (let i = 1; i < list.length; i++) {
      const previous = list[i - 1];
      const current = list[i];
      const prevRoot = previous.root || { position: [0, 0, 0], rotation: [0, 0, 0] };
      const currRoot = current.root || { position: [0, 0, 0], rotation: [0, 0, 0] };
      const prevPos = prevRoot.position || [0, 0, 0];
      const currPos = currRoot.position || [0, 0, 0];
      const velocity = [
        currPos[0] - prevPos[0],
        currPos[1] - prevPos[1],
        currPos[2] - prevPos[2],
      ];
      const speed = Math.hypot(velocity[0], velocity[1], velocity[2]);
      if (speed > 2.5) {
        warnings.push('VELOCITY SPIKE WARNING at frame ' + current.number + ' (speed ' + speed.toFixed(3) + ')');
      }
    }
    const deduped = [];
    const seen = new Set();
    for (const warning of warnings) {
      if (!seen.has(warning)) {
        seen.add(warning);
        deduped.push(warning);
      }
    }
    return {
      status: deduped.length ? 'WARNING' : 'PASS',
      warnings: deduped,
      phases: phaseSummary,
      summary: {
        totalWarnings: deduped.length,
        phaseCount: phaseSummary.length,
        frameCount: list.length,
      }
    };
  }

  window.motionQuality = {
    analyzeFrames,
    detectMotionPhases,
    detectFootSliding,
    validateJointLimits,
    validateRootMotion,
  };
})();
