function maAnalyzeCycle(frames){
  let cycleAnalysis = { status: 'Not enough evidence to determine cycle', period: null, range: null };
  if(frames.length < 12) return cycleAnalysis;
  const movementMagnitudes = frames.map((frame, idx) => {
    if(idx === 0) return 0;
    const prev = frames[idx - 1].character || { position: { x: 0, y: 0, z: 0 } };
    const curr = frame.character || { position: { x: 0, y: 0, z: 0 } };
    return maVectorMagnitude(maVectorDelta(curr.position || { x: 0, y: 0, z: 0 }, prev.position || { x: 0, y: 0, z: 0 }));
  });
  let bestPeriod = null;
  let bestScore = Infinity;
  const maxPeriod = Math.max(2, Math.floor(frames.length / 2));
  for(let period = 2; period <= maxPeriod; period++){
    let total = 0, count = 0;
    for(let index = 0; index + period < movementMagnitudes.length; index++){
      total += Math.abs(movementMagnitudes[index] - movementMagnitudes[index + period]);
      count++;
    }
    if(!count) continue;
    const average = total / count;
    if(average < bestScore){ bestScore = average; bestPeriod = period; }
  }
  if(bestPeriod && bestScore < 0.12 && frames.length >= bestPeriod * 3){
    cycleAnalysis = {
      status: 'Candidate cycle detected from numeric motion repetition.',
      period: bestPeriod,
      range: { startFrame: 1, endFrame: bestPeriod },
      score: bestScore,
    };
  }
  return cycleAnalysis;
}