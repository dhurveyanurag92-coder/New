const motionAnalysisState = { motionName: null, frames: [], analysis: null, selectedRange: null, loading: false };
const ma = { motion: null, busy: false, panel: null, rangeStart: 1, rangeEnd: 1 };

