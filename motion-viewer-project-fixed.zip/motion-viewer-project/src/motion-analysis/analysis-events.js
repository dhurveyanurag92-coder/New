function maApplyRange(){
  if(!motionAnalysisState.analysis){ return; }
  const start = Number(document.getElementById('maStartFrame').value || 1);
  const end = Number(document.getElementById('maEndFrame').value || motionAnalysisState.analysis.frameCount || 1);
  motionAnalysisState.selectedRange = { start: Math.max(1, Math.min(start, motionAnalysisState.analysis.frameCount)), end: Math.max(1, Math.min(end, motionAnalysisState.analysis.frameCount)) };
  if(motionAnalysisState.selectedRange.start > motionAnalysisState.selectedRange.end){
    const tmp = motionAnalysisState.selectedRange.start; motionAnalysisState.selectedRange.start = motionAnalysisState.selectedRange.end; motionAnalysisState.selectedRange.end = tmp;
  }
  maSetStatus(`Range analysis ready for frames ${motionAnalysisState.selectedRange.start} → ${motionAnalysisState.selectedRange.end}.`);
  maRenderReport();
}
function mountMotionAnalysisPage(el){
  el.appendChild(document.getElementById('motionAnalysisPageTpl').content.cloneNode(true));
  const motionBtn = document.getElementById('maMotionBtn');
  const picker = document.getElementById('maPicker');
  motionBtn.addEventListener('click', () => {
    const open = motionBtn.getAttribute('aria-expanded') === 'true';
    motionBtn.setAttribute('aria-expanded', String(!open));
    picker.hidden = open;
    if(!picker.hidden) maBuildMotionPicker();
  });
  document.getElementById('maRefreshBtn').addEventListener('click', () => {
    if(ma.motion) maSelectMotion(ma.motion);
  });
  document.getElementById('maCopyBtn').addEventListener('click', maCopyAnalysis);
  document.getElementById('maDownloadBtn').addEventListener('click', maDownloadAnalysis);
  document.getElementById('maRangeBtn').addEventListener('click', maApplyRange);
  maBuildMotionPicker();
  maSetStatus('Select a motion to start the analysis.');
  maRenderReport();
}
function showMotionAnalysisPage(){
  motionAnalysisState.motionName = null;
  motionAnalysisState.frames = [];
  motionAnalysisState.analysis = null;
  motionAnalysisState.selectedRange = null;
  ma.motion = null;
  ma.busy = false;
  maSetStatus('Select a motion to start the analysis.');
  maRenderReport();
  const motionBtn = document.getElementById('maMotionBtn');
  const picker = document.getElementById('maPicker');
  if(motionBtn){ motionBtn.setAttribute('aria-expanded', 'false'); }
  if(picker){ picker.hidden = true; }
}
nav.registerPage({
  id: 'motion-analysis',
  label: 'Motion Analysis',
  order: 11,
  icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 18V6M10 18V10M15 18v-6M20 18V4"/><path d="M3 18h18"/></svg>',
  canOpen(){
    if(window.motionRuntime.getModel()) return true;
    window.appUI.toast('Import a character before analyzing motion.', 2800);
    return false;
  },
  mount: mountMotionAnalysisPage,
  onShow: showMotionAnalysisPage
});
window.__mv = window.__mv || {};
window.__mv.motionAnalysis = motionAnalysisState;
