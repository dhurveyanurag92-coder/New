function maEscapeHtml(value){
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}
function maSafeNumber(v, digits = 3){
  if(!Number.isFinite(v)) return 'Unavailable';
  return Number(v).toFixed(digits);
}
function maDeg(v){
  if(!Number.isFinite(v)) return 'Unavailable';
  return (v * 180 / Math.PI).toFixed(3) + '°';
}
function maVectorMagnitude(v){
  if(!v) return 0;
  return Math.hypot(Number(v.x) || 0, Number(v.y) || 0, Number(v.z) || 0);
}
function maEulerMagnitude(e){
  if(!e) return 0;
  return Math.hypot(Number(e.x) || 0, Number(e.y) || 0, Number(e.z) || 0);
}
function maVectorFrom(obj){
  if(!obj) return { x: 0, y: 0, z: 0 };
  return { x: Number(obj.x) || 0, y: Number(obj.y) || 0, z: Number(obj.z) || 0 };
}
function maEulerFrom(obj){
  if(!obj) return { x: 0, y: 0, z: 0 };
  if(obj.isEuler) return { x: obj.x, y: obj.y, z: obj.z };
  if(obj.isQuaternion){
    const e = new THREE.Euler();
    e.setFromQuaternion(obj, 'XYZ');
    return { x: e.x, y: e.y, z: e.z };
  }
  return { x: Number(obj.x) || 0, y: Number(obj.y) || 0, z: Number(obj.z) || 0 };
}
function maVectorDelta(a, b){
  const av = maVectorFrom(a), bv = maVectorFrom(b);
  return { x: av.x - bv.x, y: av.y - bv.y, z: av.z - bv.z };
}
function maRotationDelta(a, b){
  const av = maEulerFrom(a), bv = maEulerFrom(b);
  return { x: av.x - bv.x, y: av.y - bv.y, z: av.z - bv.z };
}
function maDirectionLabel(delta){
  const x = delta.x || 0, y = delta.y || 0, z = delta.z || 0;
  const signs = [];
  if(Math.abs(x) > 1e-6) signs.push(x >= 0 ? 'X+' : 'X-');
  if(Math.abs(y) > 1e-6) signs.push(y >= 0 ? 'Y+' : 'Y-');
  if(Math.abs(z) > 1e-6) signs.push(z >= 0 ? 'Z+' : 'Z-');
  return signs.length ? signs.join(' ') : 'Stationary';
}
function maFormatVector(v, asDegrees = false){
  const vec = maVectorFrom(v);
  if(asDegrees){ return `X: ${maDeg(vec.x)} Y: ${maDeg(vec.y)} Z: ${maDeg(vec.z)}`; }
  return `X: ${maSafeNumber(vec.x)} Y: ${maSafeNumber(vec.y)} Z: ${maSafeNumber(vec.z)}`;
}
function maFormatEuler(e){
  const ev = maEulerFrom(e);
  return `X: ${maDeg(ev.x)} Y: ${maDeg(ev.y)} Z: ${maDeg(ev.z)}`;
}
