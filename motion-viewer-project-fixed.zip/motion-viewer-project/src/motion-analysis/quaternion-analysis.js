function maQuatFrom(obj){
  if(!obj) return { x: 0, y: 0, z: 0, w: 1 };
  if(obj.isQuaternion) return { x: obj.x, y: obj.y, z: obj.z, w: obj.w };
  if(Number.isFinite(obj.w)) return { x: Number(obj.x) || 0, y: Number(obj.y) || 0, z: Number(obj.z) || 0, w: Number(obj.w) };
  const e = maEulerFrom(obj);
  const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(e.x, e.y, e.z, 'XYZ'));
  return { x: q.x, y: q.y, z: q.z, w: q.w };
}
function maQuatAngularDistance(a, b){
  const qa = maQuatFrom(a), qb = maQuatFrom(b);
  let dot = qa.x * qb.x + qa.y * qb.y + qa.z * qb.z + qa.w * qb.w;
  dot = Math.max(-1, Math.min(1, Math.abs(dot)));
  return 2 * Math.acos(dot);
}