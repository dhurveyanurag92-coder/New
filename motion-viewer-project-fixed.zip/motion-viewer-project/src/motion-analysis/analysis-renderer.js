function maSetStatus(text, tone = 'default'){
  const el = document.getElementById('maStatus');
  if(!el) return;
  el.textContent = text;
  el.style.color = tone === 'error' ? 'var(--bad)' : 'var(--muted)';
}
async function maSelectMotion(name){
  if(!name || !window.motionRuntime.hasAction(name)) return;
  ma.busy = true;
  ma.motion = name;
  maSetStatus('Analyzing ' + name + '…');
  try{
    window.motionRuntime.selectAction(name);
    const frames = await window.motionDataApi.collectCanonicalFrameData();
    motionAnalysisState.motionName = name;
    motionAnalysisState.frames = frames;
    motionAnalysisState.analysis = maBuildMotionAnalysis(name, frames);
    motionAnalysisState.selectedRange = motionAnalysisState.analysis ? { start: 1, end: frames.length } : null;
    ma.rangeStart = 1;
    ma.rangeEnd = Math.max(1, frames.length);
    document.getElementById('maStartFrame').value = String(ma.rangeStart);
    document.getElementById('maEndFrame').value = String(ma.rangeEnd);
    if(motionAnalysisState.analysis){
      maSetStatus('Analysis ready for ' + name + '.');
    } else {
      maSetStatus('No motion data available for this selection.', 'error');
    }
    maRenderReport();
  } catch (error) {
    console.error(error);
    maSetStatus('Could not generate motion analysis for this selection.', 'error');
  } finally {
    ma.busy = false;
    if(document.getElementById('maMotionBtn')) document.getElementById('maMotionBtn').disabled = false;
    maRenderReport();
  }
}
function maBuildMotionPicker(){
  const picker = document.getElementById('maPicker');
  if(!picker) return;
  picker.textContent = '';
  const row = document.createElement('div');
  row.className = 'fcChips';
  const motionNames = maReadMotionNames();
  for(const name of motionNames){
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'chip';
    btn.textContent = name;
    btn.setAttribute('aria-pressed', String(ma.motion === name));
    btn.addEventListener('click', () => {
      maSelectMotion(name);
      picker.hidden = true;
      document.getElementById('maMotionBtn').setAttribute('aria-expanded', 'false');
    });
    row.appendChild(btn);
  }
  picker.appendChild(row);
}
function maRenderReport(){
  const report = document.getElementById('maReport');
  if(!report) return;
  if(!motionAnalysisState.analysis){
    report.innerHTML = '<div class="maEmpty">Select a motion to generate numeric analysis.</div>';
    return;
  }

  const analysis = motionAnalysisState.analysis;
  const range = motionAnalysisState.selectedRange || { start: 1, end: analysis.frameCount };
  const rangeInfo = maComputeRangeAnalysis(motionAnalysisState.frames, range.start, range.end) || analysis.rangeAnalysis;
  const rangeStart = rangeInfo ? rangeInfo.startFrame : 1;
  const rangeEnd = rangeInfo ? rangeInfo.endFrame : analysis.frameCount;

  const boneRows = analysis.mostActiveBones.map((bone, idx) => {
    return `<li><strong>${idx + 1}. ${maEscapeHtml(bone.name)}</strong> — total pos ${maSafeNumber(bone.totalPositionChange)} | total rot ${maSafeNumber(bone.totalRotationChange)} | max pos Δ ${maSafeNumber(bone.maximumPositionDelta)} | max rot Δ ${maSafeNumber(bone.maximumRotationDelta)}</li>`;
  }).join('');

  const rangeList = (analysis.frameChanges || []).slice(0, 8).map(change => {
    return `<li>Frame ${change.fromFrame} → ${change.toFrame}: character Δ ${maFormatVector(change.characterDelta.position)} | ${maFormatEuler(change.characterDelta.rotation)} | top bone ${change.biggestBoneChanges.length ? maEscapeHtml(change.biggestBoneChanges[0].name) : '—'}</li>`;
  }).join('');

  const bonesSummary = analysis.bones.map((bone, idx) => {
    return `<li>${idx + 1}. ${maEscapeHtml(bone.name)} | parent ${maEscapeHtml(bone.parent || 'Root')} | pos ${maSafeNumber(bone.totalPositionChange)} | rot ${maSafeNumber(bone.totalRotationChange)} | max pos ${maSafeNumber(bone.maximumPositionDelta)} | max rot ${maSafeNumber(bone.maximumRotationDelta)}</li>`;
  }).join('');
  const solver = analysis.solverState;
  const validationEnabled = window.poseValidationRuntime.enabled;
  const solverBoneRows = solver ? solver.bones.map(bone=>{
    const role = bone.semanticRole ? `${bone.side} ${bone.semanticRole}` : 'Unmapped';
    return `<li>${maEscapeHtml(bone.originalName)} | ${maEscapeHtml(role)} | ${maEscapeHtml(bone.mappingStatus)} (${maSafeNumber(bone.mappingConfidence)}) | length ${maSafeNumber(bone.boneLength)}${bone.controlBone ? ` | controller ${maEscapeHtml(bone.controlBone)}` : ''}</li>`;
  }).join('') : '';
  const measurementRows = solver ? Object.entries(solver.measurements ? solver.measurements.dimensions : {}).map(([name, value])=>
    `<div class="maKvp"><span class="label">${maEscapeHtml(name)}</span><div class="value">${value == null ? 'Unavailable' : maSafeNumber(value)}</div></div>`
  ).join('') : '';
  const validation = solver && solver.validation;
  const solveReport = solver && solver.solverReport;
  const solverSummary = solver
    ? `Mappings ${solver.mapping.mapped} · Missing ${solver.mapping.missing.length} · Targets ${solver.ikTargets.length} · Conflicts ${solveReport ? solveReport.conflicts.length : 0} · Solve ${solveReport ? solveReport.iterations + ' iter' + (solveReport.converged ? ' converged' : ' residual') : 'idle'} · Collision corrections ${solver.collisionCorrections.length} · Balance ${solver.balance.enabled ? (solver.balance.stable ? 'stable' : 'adjusted') : 'inactive'} · Validation ${validation ? (validation.valid ? 'valid' : 'issues') : 'not captured'} · IK avg ${solver.performance.averageMilliseconds.toFixed(3)} ms`
    : 'Solver inspector unavailable.';

  report.innerHTML = `
    <section class="maSection">
      <div class="maSectionHeader"><h3>SOLVER / RIG INSPECTOR</h3></div>
      <div class="maSectionBody">
        <div class="maStatus">${maEscapeHtml(solverSummary)}</div>
        <div class="maBar solverControls">
          <button class="maBtn" id="inspectSolverNow" type="button">Inspect pose</button>
          <button class="maBtn" id="resetSolverMetrics" type="button">Reset metrics</button>
          <label class="maToggle"><input id="continuousSolverValidation" type="checkbox" ${validationEnabled ? 'checked' : ''}> Continuous validation</label>
          <label class="maToggle"><input id="solverMetricsEnabled" type="checkbox" ${window.motionEnginePerformance.enabled ? 'checked' : ''}> Profile IK</label>
        </div>
        <details class="solverDetails">
          <summary>Measurements and bone registry</summary>
          <div class="maGrid">${measurementRows}</div>
          <ol class="maList">${solverBoneRows}</ol>
          ${solver ? `<pre class="maCode">${maEscapeHtml(JSON.stringify({ mapping:solver.mapping, solverReport:solver.solverReport, ikTargets:solver.ikTargets, handContacts:solver.handContacts, collisionCorrections:solver.collisionCorrections, balance:solver.balance, validation:solver.validation, performance:solver.performance }, null, 2))}</pre>` : ''}
        </details>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>MOTION SUMMARY</h3></div>
      <div class="maSectionBody">
        <div class="maGrid">
          <div class="maKvp"><span class="label">Motion</span><div class="value">${maEscapeHtml(analysis.motionName || 'Unknown')}</div></div>
          <div class="maKvp"><span class="label">Frames</span><div class="value">${analysis.frameCount}</div></div>
          <div class="maKvp"><span class="label">Duration</span><div class="value">${maSafeNumber(analysis.duration)} sec</div></div>
          <div class="maKvp"><span class="label">FPS</span><div class="value">${maSafeNumber(analysis.timing.fps)}</div></div>
          <div class="maKvp"><span class="label">Bones</span><div class="value">${analysis.boneCount}</div></div>
          <div class="maKvp"><span class="label">Start Position</span><div class="value">${maFormatVector(analysis.characterMovement.startPosition)}</div></div>
          <div class="maKvp"><span class="label">End Position</span><div class="value">${maFormatVector(analysis.characterMovement.endPosition)}</div></div>
          <div class="maKvp"><span class="label">Total Movement</span><div class="value">${maFormatVector(analysis.characterMovement.totalDisplacement)}</div></div>
          <div class="maKvp"><span class="label">Start Rotation</span><div class="value">${maFormatEuler(analysis.characterRotation.startRotation)}</div></div>
          <div class="maKvp"><span class="label">End Rotation</span><div class="value">${maFormatEuler(analysis.characterRotation.endRotation)}</div></div>
        </div>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>CHARACTER MOVEMENT</h3></div>
      <div class="maSectionBody">
        <div class="maGrid">
          <div class="maKvp"><span class="label">X Displacement</span><div class="value">${maSafeNumber(analysis.characterMovement.x)}</div></div>
          <div class="maKvp"><span class="label">Y Displacement</span><div class="value">${maSafeNumber(analysis.characterMovement.y)}</div></div>
          <div class="maKvp"><span class="label">Z Displacement</span><div class="value">${maSafeNumber(analysis.characterMovement.z)}</div></div>
          <div class="maKvp"><span class="label">Movement Direction</span><div class="value">${maEscapeHtml(analysis.characterMovement.direction)}</div></div>
        </div>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>CHARACTER ROTATION</h3></div>
      <div class="maSectionBody">
        <div class="maGrid">
          <div class="maKvp"><span class="label">Start Rotation</span><div class="value">${maFormatEuler(analysis.characterRotation.startRotation)}</div></div>
          <div class="maKvp"><span class="label">End Rotation</span><div class="value">${maFormatEuler(analysis.characterRotation.endRotation)}</div></div>
          <div class="maKvp"><span class="label">Total Rotation Delta</span><div class="value">${maFormatEuler(analysis.characterRotation.totalRotationChange)}</div></div>
          <div class="maKvp"><span class="label">Rotation Magnitude</span><div class="value">${maSafeNumber(analysis.characterRotation.totalMagnitude)}</div></div>
        </div>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>BONE MOVEMENT</h3></div>
      <div class="maSectionBody">
        <ul class="maList">${bonesSummary}</ul>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>MOST ACTIVE BONES</h3></div>
      <div class="maSectionBody">
        <ol class="maList">${boneRows}</ol>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>FRAME CHANGES</h3></div>
      <div class="maSectionBody">
        <div class="maKvp" style="margin-bottom:10px;"><span class="label">Active Range</span><div class="value">Frame ${rangeStart} → ${rangeEnd}</div></div>
        <ul class="maList">${rangeList}</ul>
      </div>
    </section>

    <section class="maSection">
      <div class="maSectionHeader"><h3>CYCLE / PATTERN ANALYSIS</h3></div>
      <div class="maSectionBody">
        <div class="maKvp"><span class="label">Status</span><div class="value">${maEscapeHtml(analysis.cycleAnalysis.status)}</div></div>
        ${analysis.cycleAnalysis.period ? `<div class="maKvp" style="margin-top:10px;"><span class="label">Candidate Period</span><div class="value">${analysis.cycleAnalysis.period} frames</div></div>` : ''}
      </div>
    </section>
  `;
  document.getElementById('inspectSolverNow').addEventListener('click', ()=>{
    window.poseValidationRuntime.inspect();
    analysis.solverState = window.solverInspector.inspect();
    maSetStatus('Current solver pose inspected.');
    maRenderReport();
  });
  document.getElementById('resetSolverMetrics').addEventListener('click', ()=>{
    window.motionEnginePerformance.reset();
    analysis.solverState = window.solverInspector.inspect();
    maSetStatus('Solver performance metrics reset.');
    maRenderReport();
  });
  document.getElementById('continuousSolverValidation').addEventListener('change', event=>{
    window.poseValidationRuntime.enabled = event.target.checked;
    if(event.target.checked) window.poseValidationRuntime.inspect();
    analysis.solverState = window.solverInspector.inspect();
    maRenderReport();
  });
  document.getElementById('solverMetricsEnabled').addEventListener('change', event=>{
    window.motionEnginePerformance.enabled = event.target.checked;
    analysis.solverState = window.solverInspector.inspect();
    maRenderReport();
  });
}
