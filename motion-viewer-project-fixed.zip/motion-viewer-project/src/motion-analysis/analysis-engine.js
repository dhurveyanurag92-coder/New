function maReadMotionNames(){
  const names = window.motionRuntime.getActions().map(action => action.name).filter(name => !!name && name !== 'T-pose');
  return names.sort((a, b) => a.localeCompare(b));
}
function maBuildMotionAnalysis(motionName, frames){
  if(!Array.isArray(frames) || !frames.length){ return null; }
  const first = frames[0];
  const last = frames[frames.length - 1];
  const firstPos = maVectorFrom(first.character && first.character.position ? first.character.position : first.summary && first.summary.position ? first.summary.position : null);
  const lastPos = maVectorFrom(last.character && last.character.position ? last.character.position : last.summary && last.summary.position ? last.summary.position : null);
  const movement = maVectorDelta(lastPos, firstPos);
  const firstRot = maEulerFrom(first.character && first.character.rotation ? first.character.rotation : first.summary && first.summary.rotation ? first.summary.rotation : null);
  const lastRot = maEulerFrom(last.character && last.character.rotation ? last.character.rotation : last.summary && last.summary.rotation ? last.summary.rotation : null);
  const rotationChange = maRotationDelta(lastRot, firstRot);

  const boneNames = [...new Set((first.bones || []).map(b => b.originalName || b.semanticName || 'UnknownBone').concat((last.bones || []).map(b => b.originalName || b.semanticName || 'UnknownBone')))];
  const bones = boneNames.map(name => {
    const firstBone = (first.bones || []).find(b => (b.originalName || b.semanticName || 'UnknownBone') === name) || null;
    const lastBone = (last.bones || []).find(b => (b.originalName || b.semanticName || 'UnknownBone') === name) || null;
    const firstPosWorld = maVectorFrom(firstBone && firstBone.worldPosition ? firstBone.worldPosition : null);
    const lastPosWorld = maVectorFrom(lastBone && lastBone.worldPosition ? lastBone.worldPosition : null);
    const startRotWorld = maEulerFrom(firstBone && firstBone.worldEuler ? firstBone.worldEuler : firstBone && firstBone.localEuler ? firstBone.localEuler : null);
    const endRotWorld = maEulerFrom(lastBone && lastBone.worldEuler ? lastBone.worldEuler : lastBone && lastBone.localEuler ? lastBone.localEuler : null);
    const maxPosDelta = frames.reduce((max, frame) => {
      const bone = (frame.bones || []).find(b => (b.originalName || b.semanticName || 'UnknownBone') === name);
      const delta = bone && bone.deltaFromPrevious && bone.deltaFromPrevious.worldPosition ? maVectorMagnitude(bone.deltaFromPrevious.worldPosition) : 0;
      return Math.max(max, delta);
    }, 0);
    const maxRotDelta = frames.reduce((max, frame) => {
      const bone = (frame.bones || []).find(b => (b.originalName || b.semanticName || 'UnknownBone') === name);
      const delta = bone && bone.deltaFromPrevious && bone.deltaFromPrevious.worldRotation ? maEulerMagnitude(maEulerFrom(bone.deltaFromPrevious.worldRotation)) : 0;
      return Math.max(max, delta);
    }, 0);
    const activeFrames = frames.map((frame, idx) => {
      const bone = (frame.bones || []).find(b => (b.originalName || b.semanticName || 'UnknownBone') === name);
      const delta = bone && bone.deltaFromPrevious && bone.deltaFromPrevious.worldPosition ? maVectorMagnitude(bone.deltaFromPrevious.worldPosition) : 0;
      return delta > 1e-6 ? idx + 1 : null;
    }).filter(v => v !== null);
    return {
      name,
      parent: firstBone ? (firstBone.parent || 'Root') : (lastBone ? (lastBone.parent || 'Root') : 'Root'),
      totalPositionChange: maVectorMagnitude(maVectorDelta(lastPosWorld, firstPosWorld)),
      totalRotationChange: maEulerMagnitude(maRotationDelta(endRotWorld, startRotWorld)),
      maximumPositionDelta: maxPosDelta,
      maximumRotationDelta: maxRotDelta,
      frameRangeOfMovement: activeFrames.length ? [activeFrames[0], activeFrames[activeFrames.length - 1]] : [1, 1],
      startTransform: { worldPosition: firstPosWorld, worldRotation: startRotWorld, localPosition: firstBone ? maVectorFrom(firstBone.localPosition) : { x: 0, y: 0, z: 0 }, localRotation: firstBone ? maEulerFrom(firstBone.localEuler) : { x: 0, y: 0, z: 0 } },
      endTransform: { worldPosition: lastPosWorld, worldRotation: endRotWorld, localPosition: lastBone ? maVectorFrom(lastBone.localPosition) : { x: 0, y: 0, z: 0 }, localRotation: lastBone ? maEulerFrom(lastBone.localEuler) : { x: 0, y: 0, z: 0 } },
    };
  });

  const activeBones = bones.slice().sort((a, b) => (b.totalPositionChange + b.totalRotationChange) - (a.totalPositionChange + a.totalRotationChange)).slice(0, 10);

  const cycleAnalysis = maAnalyzeCycle(frames);

  return {
    motionName,
    frameCount: frames.length,
    duration: frames.length ? (frames[frames.length - 1].time || 0) : 0,
    totalFrames: frames.length,
    timing: {
      fps: frames[0] && frames[0].fps ? frames[0].fps : 30,
      duration: frames.length ? (frames[frames.length - 1].time || 0) : 0,
      startTime: frames[0] ? frames[0].time : 0,
      endTime: frames.length ? (frames[frames.length - 1].time || 0) : 0,
    },
    boneCount: bones.length,
    characterMovement: {
      startPosition: firstPos,
      endPosition: lastPos,
      totalDisplacement: movement,
      x: movement.x,
      y: movement.y,
      z: movement.z,
      direction: maDirectionLabel(movement),
    },
    characterRotation: {
      startRotation: firstRot,
      endRotation: lastRot,
      totalRotationChange: rotationChange,
      totalMagnitude: maEulerMagnitude(rotationChange),
    },
    bones,
    mostActiveBones: activeBones,
    solverState: window.solverInspector ? window.solverInspector.inspect() : null,
    // Every adjacent pair (frame[idx] -> frame[idx+1]) is recomputed here
    // directly from the canonical per-frame data (frame.character and
    // frame.bones), never from a cached/stale deltaFromPrevious value and
    // never from rounded/display strings. Position deltas are plain
    // numeric subtraction; rotation deltas use quaternion shortest-angle
    // distance (see maQuatAngularDistance) so an Euler wrap-around never
    // reads as a fake ~360 degree change. A genuine zero is only reported
    // when the actual source transforms are identical.
    frameChanges: maBuildFrameChanges(frames),
    cycleAnalysis,
    rangeAnalysis: maComputeRangeAnalysis(frames, 1, frames.length),
  };
}

window.motionAnalysisRuntime=Object.assign(window.motionAnalysisRuntime||{}, {
  analyzeFrames:maBuildMotionAnalysis,
});
