function maNormalizeRange(start, end, total){
  const min = Math.max(1, Number.isFinite(start) ? Math.floor(start) : 1);
  const max = Math.max(1, Number.isFinite(end) ? Math.floor(end) : 1);
  const s = Math.min(min, max, total);
  const e = Math.max(min, max, 1);
  return { start: Math.max(1, Math.min(s, total)), end: Math.max(Math.max(1, Math.min(e, total)), Math.max(1, Math.min(s, total))) };
}

function maComputeRangeAnalysis(frames, start, end){
  if(!Array.isArray(frames) || !frames.length) return null;
  const total = frames.length;
  const s = Math.max(1, Math.min(start, total));
  const e = Math.max(s, Math.min(end, total));
  const first = frames[s - 1] || frames[0];
  const last = frames[e - 1] || frames[frames.length - 1];
  const firstPos = maVectorFrom(first.character && first.character.position ? first.character.position : first.summary && first.summary.position ? first.summary.position : null);
  const lastPos = maVectorFrom(last.character && last.character.position ? last.character.position : last.summary && last.summary.position ? last.summary.position : null);
  const deltaPos = maVectorDelta(lastPos, firstPos);
  const firstRot = maEulerFrom(first.character && first.character.rotation ? first.character.rotation : first.summary && first.summary.rotation ? first.summary.rotation : null);
  const lastRot = maEulerFrom(last.character && last.character.rotation ? last.character.rotation : last.summary && last.summary.rotation ? last.summary.rotation : null);
  const deltaRot = maRotationDelta(lastRot, firstRot);
  const boneNames = [...new Set(frames.slice(s - 1, e).flatMap(frame => (frame.bones || []).map(b => b.originalName || b.semanticName || 'UnknownBone')))];
  const changedBones = boneNames.map(name => {
    const samples = frames.slice(s - 1, e).map(frame => (frame.bones || []).find(b => (b.originalName || b.semanticName || 'UnknownBone') === name)).filter(Boolean);
    const startBone = samples[0] || null;
    const endBone = samples[samples.length - 1] || null;
    const startPosWorld = maVectorFrom(startBone && startBone.worldPosition ? startBone.worldPosition : null);
    const endPosWorld = maVectorFrom(endBone && endBone.worldPosition ? endBone.worldPosition : null);
    const startRotWorld = maEulerFrom(startBone && startBone.worldEuler ? startBone.worldEuler : null);
    const endRotWorld = maEulerFrom(endBone && endBone.worldEuler ? endBone.worldEuler : null);
    const deltaWorldPos = maVectorDelta(endPosWorld, startPosWorld);
    const deltaWorldRot = maRotationDelta(endRotWorld, startRotWorld);
    const maxPos = samples.reduce((max, bone) => Math.max(max, bone.deltaFromPrevious && bone.deltaFromPrevious.worldPosition ? maVectorMagnitude(bone.deltaFromPrevious.worldPosition) : 0), 0);
    const maxRot = samples.reduce((max, bone) => Math.max(max, bone.deltaFromPrevious && bone.deltaFromPrevious.worldRotation ? maEulerMagnitude(maEulerFrom(bone.deltaFromPrevious.worldRotation)) : 0), 0);
    return {
      name,
      startTransform: { worldPosition: startPosWorld, worldRotation: startRotWorld },
      endTransform: { worldPosition: endPosWorld, worldRotation: endRotWorld },
      totalPositionChange: maVectorMagnitude(deltaWorldPos),
      totalRotationChange: maEulerMagnitude(deltaWorldRot),
      maximumPositionDelta: maxPos,
      maximumRotationDelta: maxRot,
      range: { startFrame: s, endFrame: e }
    };
  }).sort((a, b) => (b.totalPositionChange + b.totalRotationChange) - (a.totalPositionChange + a.totalRotationChange));
  return {
    startFrame: s,
    endFrame: e,
    characterDelta: { position: deltaPos, rotation: deltaRot },
    activeBones: changedBones.slice(0, 10),
  };
}

function maBuildFrameChanges(frames){
  return frames.slice(1).map((frame, idx) => {
    const prev = frames[idx];
    const fromTime = Number.isFinite(prev.time) ? prev.time : 0;
    const toTime = Number.isFinite(frame.time) ? frame.time : 0;
    const prevCharPos = maVectorFrom(prev.character && prev.character.position ? prev.character.position : prev.summary && prev.summary.position ? prev.summary.position : null);
    const currCharPos = maVectorFrom(frame.character && frame.character.position ? frame.character.position : frame.summary && frame.summary.position ? frame.summary.position : null);
    const prevCharRot = prev.character && prev.character.rotation ? prev.character.rotation : (prev.summary && prev.summary.rotation ? prev.summary.rotation : null);
    const currCharRot = frame.character && frame.character.rotation ? frame.character.rotation : (frame.summary && frame.summary.rotation ? frame.summary.rotation : null);
    const positionDelta = maVectorDelta(currCharPos, prevCharPos);
    const characterDelta = {
      position: positionDelta,
      positionMagnitude: maVectorMagnitude(positionDelta),
      rotation: maRotationDelta(maEulerFrom(currCharRot), maEulerFrom(prevCharRot)),
      rotationMagnitude: maQuatAngularDistance(currCharRot, prevCharRot),
    };
    const prevBoneByName = new Map((prev.bones || []).map(b => [b.originalName || b.semanticName || 'UnknownBone', b]));
    const boneChanges = (frame.bones || []).map(bone => {
      const name = bone.originalName || bone.semanticName || 'UnknownBone';
      const prevBone = prevBoneByName.get(name) || null;
      const localPositionDelta = maVectorDelta(bone.localPosition, prevBone ? prevBone.localPosition : bone.localPosition);
      const worldPositionDelta = maVectorDelta(bone.worldPosition, prevBone ? prevBone.worldPosition : bone.worldPosition);
      const localRotationDelta = prevBone ? maQuatAngularDistance(bone.localRotation, prevBone.localRotation) : 0;
      const worldRotationDelta = prevBone ? maQuatAngularDistance(bone.worldRotation, prevBone.worldRotation) : 0;
      return { name, localPositionDelta, worldPositionDelta, positionMagnitude: maVectorMagnitude(worldPositionDelta), localRotationDelta, worldRotationDelta, rotationMagnitude: worldRotationDelta };
    });
    const biggestBoneChanges = boneChanges.slice().sort((a, b) => (b.positionMagnitude + b.rotationMagnitude) - (a.positionMagnitude + a.rotationMagnitude)).slice(0, 5)
      .map(b => ({ name: b.name, positionDelta: b.positionMagnitude, rotationDelta: b.rotationMagnitude }));
    return {
      fromFrame: idx + 1,
      toFrame: idx + 2,
      fromTime,
      toTime,
      deltaTime: toTime - fromTime,
      characterDelta,
      biggestBoneChanges,
      boneChanges,
    };
  });
}