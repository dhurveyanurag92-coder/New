function maDownloadAnalysis(){
  if(!motionAnalysisState.analysis){
    maSetStatus('Select a motion before downloading analysis.', 'error');
    return;
  }
  const blob = new Blob([JSON.stringify(motionAnalysisState.analysis, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${sanitizeFrameExportName(motionAnalysisState.motionName || 'Motion')}-Analysis.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  maSetStatus('Analysis JSON downloaded.');
}
async function maCopyAnalysis(){
  if(!motionAnalysisState.analysis){
    maSetStatus('Select a motion before copying analysis.', 'error');
    return;
  }
  const text = JSON.stringify(motionAnalysisState.analysis, null, 2);
  try{
    await navigator.clipboard.writeText(text);
    maSetStatus('Analysis copied to clipboard.');
  } catch (error) {
    console.error(error);
    const tx = document.createElement('textarea');
    tx.value = text; document.body.appendChild(tx); tx.select(); document.execCommand('copy'); tx.remove();
    maSetStatus('Analysis copied to clipboard.');
  }
}
