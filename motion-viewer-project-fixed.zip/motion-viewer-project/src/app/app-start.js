const DEFAULT_FBX_B64 = "__FBX_B64__";
const DEFAULT_NAME = "X_Bot.fbx";

(function(){
'use strict';

/* ------------------------------------------------------------------ helpers */
const $ = s => document.querySelector(s);
const el = {
  app:$('#app'), canvas:$('#c'), panel:$('#panel'), status:$('#status'), loading:$('#loading'),
  fname:$('#fname'), chips:$('#chips'), play:$('#play'), speed:$('#speed'), spv:$('#spv'),
  file:$('#file'), sheetWrap:$('#sheetWrap'), code:$('#code'), err:$('#err'), mine:$('#mine'),
  editBtn:$('#editBtn'), editWrap:$('#editWrap'), editActionName:$('#editActionName'),
  editBoneChips:$('#editBoneChips'), editControls:$('#editControls'), editBoneName:$('#editBoneName'),
  editAxes:$('#editAxes'), resetBone:$('#resetBone'), editNote:$('#editNote'),
  saveEdit:$('#saveEdit'), clearEditsForAction:$('#clearEditsForAction'), closeEdit:$('#closeEdit'),
  editGroupChips:$('#editGroupChips'), frameSlider:$('#frameSlider'), frameLabel:$('#frameLabel'),
  fBack:$('#fBack'), fBack2:$('#fBack2'), fFwd:$('#fFwd'), fFwd2:$('#fFwd2'), previewBtn:$('#previewBtn'),
  stepChips:$('#stepChips'), editKeys:$('#editKeys'), deleteKey:$('#deleteKey'),
  motionsBtn:$('#motionsBtn'), motionPicker:$('#motionPicker'), motionList:$('#motionList'), closeMotionPicker:$('#closeMotionPicker'),
  motionTimeline:$('#motionTimeline'), motionTime:$('#motionTime'), motionLoop:$('#motionLoop'), motionReset:$('#motionReset')
};
let toastTimer;
function toast(msg, ms){
  el.status.textContent = msg; el.status.classList.add('show');
  clearTimeout(toastTimer);
  if(ms !== 0) toastTimer = setTimeout(()=>el.status.classList.remove('show'), ms || 3200);
}
window.appUI = { toast };
function fatal(msg){ el.loading.hidden = false; el.loading.classList.add('bad'); el.loading.textContent = msg; }
const ss = x => { x = Math.min(1, Math.max(0, x)); return x*x*(3-2*x); };
const lerp = (a,b,k) => a + (b-a)*k;

