

/* ------------------------------------------------------------------ start */
window.__mv = { actions, ctrl, deleteCustom, nav, frameExport: frameCodeState };                        // handle for testing in the console
loadCustom();
loadOverrides();
buildChips(); syncUI();
boot();
})();
