function extractImportedAnimationClips(animations, sourceFileName){
  const clips = (animations || []).filter(clip=>clip && Array.isArray(clip.tracks) && clip.tracks.length && clip.duration >= 0.1);
  if(!clips.length) throw new Error('No animation clips were found in this FBX.');
  const baseName = String(sourceFileName || 'Imported Motion').replace(/\.fbx$/i, '').trim() || 'Imported Motion';
  const names = new Set();
  return clips.map((sourceClip, index)=>{
    const clip = sourceClip;
    const rawName = String(sourceClip.name || '').trim();
    const genericName = /^(mixamo\.com|take\s*\d*|default|animation\s*\d*|anim\s*\d*|clip\s*\d*|untitled|unnamed)$/i.test(rawName);
    const base = rawName && !genericName ? rawName : (clips.length === 1 ? baseName : baseName + ' · Clip ' + (index + 1));
    let name = base, suffix = 2;
    while(names.has(name.toLowerCase())) name = base + ' (' + suffix++ + ')';
    names.add(name.toLowerCase());
    clip.name = name;
    return { clip, name, sourceClipName:rawName || 'Unnamed clip' };
  });
}