const importedMotionRegistry = new Map();

function createImportedMotionId(){
  return window.crypto && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : 'motion-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

function getImportedMotionRecords(){
  return [...importedMotionRegistry.values()]
    .map(({ clip, ...record })=>record)
    .sort((a, b)=>(a.createdAt || 0) - (b.createdAt || 0));
}
function notifyImportedMotionRegistryChanged(){
  window.dispatchEvent(new Event('imported-motions:changed'));
}

function registerImportedMotionRecord(record){
  const clip = THREE.AnimationClip.parse(record.clip);
  const action = window.characterRuntime.registerImportedAnimationClip(clip, record);
  const savedRecord = {
    sourceHash:record.sourceHash||null,
    id:record.id,
    name:action.name,
    sourceFile:record.sourceFile,
    clipName:record.clipName,
    duration:record.duration,
    mappingStatus:record.mappingStatus,
    mappedTrackCount:record.mappedTrackCount,
    skippedTracks:record.skippedTracks,
    diagnostics:record.diagnostics||null,
    mapping:record.mapping||null,
    rootMotion:record.rootMotion||null,
    learning:record.learning||null,
    heightRatio:record.heightRatio||1,
    createdAt:record.createdAt,
  };
  importedMotionRegistry.set(savedRecord.id, savedRecord);
  notifyImportedMotionRegistryChanged();
  return savedRecord;
}

async function hydrateImportedMotionRegistry(){
  if(!window.characterRuntime.getModel()) return [];
  const records = (await listImportedMotionRecords()).sort((a, b)=>(a.createdAt || 0) - (b.createdAt || 0) || String(a.id).localeCompare(String(b.id)));
  for(const record of getImportedMotionRecords()) window.characterRuntime.removeImportedAnimationClip(record.id);
  importedMotionRegistry.clear();
  const restored = [];
  for(const record of records){
    try{ restored.push(registerImportedMotionRecord(record)); }
    catch(error){ console.warn('Imported motion could not be restored:', record.name, error); }
  }
  notifyImportedMotionRegistryChanged();
  return getImportedMotionRecords();
}

async function persistImportedMotionRecord(record){
  await saveImportedMotionRecord(record);
  try{ return registerImportedMotionRecord(record); }
  catch(error){
    await deleteImportedMotionRecord(record.id);
    throw error;
  }
}

async function removeImportedMotionRecord(id){
  const record=importedMotionRegistry.get(id);
  if(record&&record.learning&&record.learning.id) await window.motionLearningRuntime.remove(record.learning.id);
  await deleteImportedMotionRecord(id);
  window.characterRuntime.removeImportedAnimationClip(id);
  importedMotionRegistry.delete(id);
  notifyImportedMotionRegistryChanged();
  return getImportedMotionRecords();
}

window.importedMotionRuntime = {
  getRecords:getImportedMotionRecords,
  hydrate:hydrateImportedMotionRegistry,
  register:persistImportedMotionRecord,
  remove:removeImportedMotionRecord,
};

window.addEventListener('character:loaded', ()=>{
  hydrateImportedMotionRegistry().catch(error=>{
    console.error(error);
    window.appUI.toast('Saved imported motions could not be loaded: ' + (error.message || error), 5000);
  });
});