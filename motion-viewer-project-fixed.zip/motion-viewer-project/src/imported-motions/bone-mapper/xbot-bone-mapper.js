function inspectXBotBoneMapping(sourceRegistry, targetRegistry){
  const sourceMapping = retargetSkeletonToControlRig(sourceRegistry, BONE_KEYS);
  const targetMapping = retargetSkeletonToControlRig(targetRegistry, BONE_KEYS);
  const missingSource = REQUIRED.filter(key=>!sourceMapping.bones[key]);
  const missingTarget = REQUIRED.filter(key=>!targetMapping.bones[key]);
  return { sourceMapping, targetMapping, missingSource, missingTarget };
}