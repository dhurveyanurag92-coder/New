const IMPORTED_MOTION_DB = 'motion-viewer-imported-motions';
const IMPORTED_MOTION_STORE = 'clips';
const MOTION_KNOWLEDGE_STORE = 'motion-knowledge';
const MOTION_KNOWLEDGE_INDEX = 'motion-knowledge-index';
let importedMotionDbPromise = null;

function openImportedMotionDb(){
  if(importedMotionDbPromise) return importedMotionDbPromise;
  importedMotionDbPromise = new Promise((resolve, reject)=>{
    if(!window.indexedDB){ reject(new Error('This browser does not support IndexedDB.')); return; }
    const request = indexedDB.open(IMPORTED_MOTION_DB, 3);
    request.onupgradeneeded = ()=>{
      const db = request.result;
      const clipStore=db.objectStoreNames.contains(IMPORTED_MOTION_STORE)
        ? request.transaction.objectStore(IMPORTED_MOTION_STORE)
        : db.createObjectStore(IMPORTED_MOTION_STORE, { keyPath:'id' });
      if(!clipStore.indexNames.contains('sourceHash')) clipStore.createIndex('sourceHash','sourceHash',{ unique:false });
      if(!db.objectStoreNames.contains(MOTION_KNOWLEDGE_STORE)) db.createObjectStore(MOTION_KNOWLEDGE_STORE, { keyPath:'id' });
      if(!db.objectStoreNames.contains(MOTION_KNOWLEDGE_INDEX)) db.createObjectStore(MOTION_KNOWLEDGE_INDEX, { keyPath:'id' });
    };
    request.onsuccess = ()=>resolve(request.result);
    request.onerror = ()=>reject(request.error || new Error('Could not open imported motion storage.'));
    request.onblocked = ()=>reject(new Error('Imported motion storage is blocked by another page.'));
  }).catch(error=>{ importedMotionDbPromise = null; throw error; });
  return importedMotionDbPromise;
}

async function importedMotionRequest(mode, operation, storeName = IMPORTED_MOTION_STORE){
  const db = await openImportedMotionDb();
  return new Promise((resolve, reject)=>{
    const transaction = db.transaction(storeName, mode);
    const request = operation(transaction.objectStore(storeName));
    let result;
    request.onsuccess = ()=>{ result = request.result; };
    request.onerror = ()=>reject(request.error || new Error('Imported motion storage request failed.'));
    transaction.oncomplete = ()=>resolve(result);
    transaction.onerror = ()=>reject(transaction.error || new Error('Imported motion storage transaction failed.'));
    transaction.onabort = ()=>reject(transaction.error || new Error('Imported motion storage transaction was aborted.'));
  });
}

function listImportedMotionRecords(){
  return importedMotionRequest('readonly', store=>store.getAll());
}

function saveImportedMotionRecord(record){
  return importedMotionRequest('readwrite', store=>store.put(record));
}

function deleteImportedMotionRecord(id){
  return importedMotionRequest('readwrite', store=>store.delete(id));
}

function hasImportedMotionSourceHash(sourceHash){
  return importedMotionRequest('readonly',store=>store.index('sourceHash').getKey(sourceHash)).then(id=>id!==undefined);
}

function createMotionKnowledgeIndexRecord(record){
  const ir=record.motionIR;
  return {
    id:record.id,
    name:record.name,
    source:record.source,
    sourceMotionId:record.sourceMotionId,
    duration:ir.duration,
    motionFeatures:ir.motionFeatures,
    contacts:ir.contacts,
    phases:ir.phases,
    relationships:(ir.relationships||[]).map(({from,to,distance})=>({from,to,distance})),
    jointRanges:ir.motionFeatures.jointRanges,
    controlCurves:ir.controlCurves,
    rootMotion:ir.rootMotion?{ detected:ir.rootMotion.detected,sourceNode:ir.rootMotion.sourceNode,displacement:ir.rootMotion.displacement,trajectory:ir.rootMotion.trajectory }:null,
    createdAt:record.createdAt,
  };
}

function saveMotionKnowledgeRecord(record){
  return openImportedMotionDb().then(db=>new Promise((resolve,reject)=>{
    const transaction=db.transaction([MOTION_KNOWLEDGE_STORE,MOTION_KNOWLEDGE_INDEX],'readwrite');
    transaction.objectStore(MOTION_KNOWLEDGE_STORE).put(record);
    transaction.objectStore(MOTION_KNOWLEDGE_INDEX).put(createMotionKnowledgeIndexRecord(record));
    transaction.oncomplete=()=>resolve(record);
    transaction.onerror=()=>reject(transaction.error||new Error('Motion knowledge transaction failed.'));
    transaction.onabort=()=>reject(transaction.error||new Error('Motion knowledge transaction was aborted.'));
  }));
}

function listMotionKnowledgeIndex(){
  return importedMotionRequest('readonly',store=>store.getAll(),MOTION_KNOWLEDGE_INDEX);
}

function getMotionKnowledgeRecord(id){
  return importedMotionRequest('readonly',store=>store.get(id),MOTION_KNOWLEDGE_STORE);
}

function deleteMotionKnowledgeRecord(id){
  return openImportedMotionDb().then(db=>new Promise((resolve,reject)=>{
    const transaction=db.transaction([MOTION_KNOWLEDGE_STORE,MOTION_KNOWLEDGE_INDEX],'readwrite');
    transaction.objectStore(MOTION_KNOWLEDGE_STORE).delete(id);
    transaction.objectStore(MOTION_KNOWLEDGE_INDEX).delete(id);
    transaction.oncomplete=()=>resolve(id);
    transaction.onerror=()=>reject(transaction.error||new Error('Motion knowledge delete failed.'));
    transaction.onabort=()=>reject(transaction.error||new Error('Motion knowledge delete was aborted.'));
  }));
}