async function parseImportedMotionFbx(file, sourceBuffer, sourceHash){
  if(!file || !/\.fbx$/i.test(file.name || '')) throw new Error('Choose an .fbx motion file.');
  if(!THREE.FBXLoader) throw new Error('FBX loader is not available.');
  let root = null;
  try{
    root = new THREE.FBXLoader().parse(sourceBuffer || await file.arrayBuffer(), '');
    if(!root) throw new Error('The FBX file did not contain a scene.');
    root.updateMatrixWorld(true);
    const skeleton = buildSkeletonRegistry(root);
    if(!skeleton.bones.length) throw new Error('No skeleton was found in this FBX.');
    const analysis = analyzeImportedMotionStructure(root, root.animations || [], skeleton);
    let minY = Infinity, maxY = -Infinity;
    for(const record of skeleton.bones){
      minY = Math.min(minY, record.worldPosition.y);
      maxY = Math.max(maxY, record.worldPosition.y);
    }
    return {
      root,
      animations:Array.isArray(root.animations) ? root.animations : [],
      skeleton,
      analysis,
      sourceHash:sourceHash || null,
      sourceHeight:Number.isFinite(maxY - minY) ? maxY - minY : 0,
    };
  }catch(error){
    disposeImportedMotionSource(root);
    throw error;
  }
}

function disposeImportedMotionSource(root){
  if(!root) return;
  root.traverse(object=>{
    if(object.geometry) object.geometry.dispose();
    if(!object.material) return;
    for(const material of (Array.isArray(object.material) ? object.material : [object.material])){
      for(const key in material) if(material[key] && material[key].isTexture) material[key].dispose();
      material.dispose();
    }
  });
}