let importedMotionPageRoot = null;

function renderImportedMotionsPage(){
  if(!importedMotionPageRoot) return;
  const list = importedMotionPageRoot.querySelector('#importedMotionList');
  list.textContent = '';
  const records = getImportedMotionRecords();
  if(!records.length){
    const empty = document.createElement('p');
    empty.className = 'imported-motion-empty';
    empty.textContent = 'No imported motions yet.';
    list.appendChild(empty);
    return;
  }
  for(const record of records){
    const item = document.createElement('article');
    item.className = 'imported-motion-item';
    const details = document.createElement('div');
    const name = document.createElement('h2');
    name.className = 'imported-motion-name';
    name.textContent = record.name;
    const meta = document.createElement('div');
    meta.className = 'imported-motion-meta';
    for(const value of [record.sourceFile, record.clipName, (Number(record.duration) || 0).toFixed(2) + ' s']){
      const part = document.createElement('span');
      part.textContent = value;
      meta.appendChild(part);
    }
    details.append(name, meta);
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'imported-motion-delete';
    remove.textContent = 'Delete';
    remove.setAttribute('aria-label', 'Delete ' + record.name);
    remove.addEventListener('click', async()=>{
      remove.disabled = true;
      try{ await removeImportedMotionRecord(record.id); renderImportedMotionsPage(); }
      catch(error){ setImportedMotionPageStatus(error.message || String(error), 'error'); remove.disabled = false; }
    });
    const mapping = document.createElement('div');
    mapping.className = 'imported-motion-map';
    mapping.dataset.kind = record.mappingStatus === 'Mapping Incomplete' ? 'warning' : 'ready';
    mapping.textContent = record.mappingStatus + ' · ' + record.mappedTrackCount + ' tracks mapped';
    if(record.skippedTracks && record.skippedTracks.length) mapping.textContent += ' · skipped: ' + record.skippedTracks.join(', ');
    item.append(details, remove, mapping);
    if(record.diagnostics){
      const diagnostics = document.createElement('details');
      diagnostics.className = 'imported-motion-diagnostics';
      const summary = document.createElement('summary');
      summary.textContent = 'Diagnostics';
      const content = document.createElement('p');
      const source = record.diagnostics;
      const channels = source.channels || {};
      const mappingInfo = record.mapping || {};
      const sourceBones = mappingInfo.source || [];
      const mappedBones = sourceBones.filter(bone=>bone.semanticRole && bone.status !== 'unmapped').length;
      const unmapped = sourceBones.filter(bone=>!bone.semanticRole || bone.status === 'unmapped').map(bone=>bone.name);
      const matches = sourceBones.filter(bone=>bone.target).map(bone=>bone.name + ' -> ' + bone.target + ' (' + Math.round((bone.targetConfidence || 0) * 100) + '%)');
      content.textContent = [
        'Bones: ' + (source.sourceBoneCount || 0),
        'Semantic bones: ' + mappedBones + ' mapped',
        'Tracks: ' + (source.trackCount || 0),
        'Translation: ' + (channels.translation || 0),
        'Rotation: ' + (channels.rotation || 0),
        'Scale: ' + (channels.scale || 0),
        'Unsupported: ' + (channels.unsupported || 0),
        'Unresolved tracks: ' + (channels.unresolved || 0),
        'Sample rate: ' + (source.sampleRate ? source.sampleRate + ' Hz (inferred)' : 'not inferred'),
        'Coordinate space: ' + (source.coordinateSystem || 'unknown'),
        'Root candidate: ' + (record.rootMotion ? record.rootMotion.nodeName + (record.rootMotion.isPelvisRoot ? ' (pelvis root)' : ' (ancestor root)') : 'no animated root candidate detected'),
        'Pelvis source: ' + (record.rootMotion && record.rootMotion.pelvisNodeName || 'not identified'),
        'Missing semantic bones: ' + ((mappingInfo.missingSource || []).join(', ') || 'none'),
        'Unmapped bones: ' + (unmapped.length ? unmapped.join(', ') : 'none'),
        'Bone mapping: ' + (matches.length ? matches.join(', ') : 'none'),
      ].join(' · ');
      diagnostics.append(summary, content);
      item.appendChild(diagnostics);
    }
    if(record.learning){
      const learning=document.createElement('details');
      learning.className='imported-motion-diagnostics';
      const summary=document.createElement('summary');
      summary.textContent='Motion Learning: '+record.learning.status;
      const content=document.createElement('p');
      content.textContent=record.learning.status==='analysis-failed'
        ? record.learning.error||'Motion analysis did not complete.'
        : [
          'Sampled frames: '+(record.learning.frameCount||0),
          'Phases: '+(record.learning.phaseCount||0),
          'Contacts: '+(record.learning.contactCount||0),
          'Features: '+(record.learning.featureCount||0),
        ].join(' · ');
      learning.append(summary,content);
      if(record.learning.id){
        const inspectButton=document.createElement('button');
        inspectButton.type='button';
        inspectButton.className='imported-motion-export';
        inspectButton.textContent='Inspect Knowledge';
        inspectButton.addEventListener('click',async()=>{
          inspectButton.disabled=true;
          try{
            const knowledge=await window.motionLearningRuntime.get(record.learning.id);
            if(!knowledge) throw new Error('Motion Knowledge was not found in IndexedDB.');
            const ir=knowledge.motionIR;
            const root=ir.rootMotion||{};
            content.textContent=[
              'Root source: '+(root.sourceNode||'not separated'),
              'Root displacement: '+JSON.stringify(root.displacement||{x:0,y:0,z:0}),
              'Phases: '+(ir.phases||[]).map(phase=>phase.label+' '+phase.startTime.toFixed(2)+'-'+phase.endTime.toFixed(2)+'s').join(', '),
              'Contacts: '+(ir.contacts||[]).map(contact=>contact.type+' '+contact.startTime.toFixed(2)+'-'+contact.endTime.toFixed(2)+'s').join(', '),
              'Joint ranges: '+(ir.motionFeatures.jointRanges||[]).map(joint=>joint.name+' '+joint.min.toFixed(2)+'..'+joint.max.toFixed(2)+'rad').join(', '),
              'Relationships: '+(ir.relationships||[]).map(relation=>relation.from+' to '+relation.to+' '+relation.distance.mean.toFixed(3)+'h avg').join(', '),
              'Warnings: '+((ir.validation.warnings||[]).map(warning=>warning.code).join(', ')||'none'),
            ].join(' · ');
          }catch(error){ setImportedMotionPageStatus(error.message||String(error),'error'); }
          finally{ inspectButton.disabled=false; }
        });
        learning.appendChild(inspectButton);
        const exportButton=document.createElement('button');
        exportButton.type='button';
        exportButton.className='imported-motion-export';
        exportButton.textContent='Export Motion IR';
        exportButton.addEventListener('click',async()=>{
          exportButton.disabled=true;
          try{
            const knowledge=await window.motionLearningRuntime.get(record.learning.id);
            if(!knowledge) throw new Error('Motion IR was not found in IndexedDB.');
            const blob=new Blob([JSON.stringify(knowledge,null,2)],{ type:'application/json' });
            const url=URL.createObjectURL(blob);
            const anchor=document.createElement('a');
            anchor.href=url;
            anchor.download=(record.name||'motion')+'-motion-ir.json';
            anchor.click();
            URL.revokeObjectURL(url);
          }catch(error){ setImportedMotionPageStatus(error.message||String(error),'error'); }
          finally{ exportButton.disabled=false; }
        });
        learning.appendChild(exportButton);
      }
      item.appendChild(learning);
    }
    list.appendChild(item);
  }
}

function setImportedMotionPageStatus(message, kind){
  if(!importedMotionPageRoot) return;
  const status = importedMotionPageRoot.querySelector('#importedMotionStatus');
  status.textContent = message || '';
  status.dataset.kind = kind || 'ready';
}

function mountImportedMotionsPage(element){
  importedMotionPageRoot = element;
  const template = document.getElementById('importedMotionsPageTpl');
  element.appendChild(template.content.cloneNode(true));
  const input = element.querySelector('#importedMotionFile');
  input.addEventListener('change', async()=>{
    const files = input.files ? [...input.files] : [];
    input.value = '';
    if(!files.length) return;
    setImportedMotionPageStatus('Reading ' + files.length + ' FBX file(s)…');
    try{
      const result = await window.importedMotionRuntime.importFiles(files,progress=>{
        setImportedMotionPageStatus('Analyzing ' + progress.current + ' of ' + progress.total + ': ' + progress.file);
      });
      const failed = result.failures.length;
      const status = result.imported.length + ' motion(s) imported and analyzed';
      setImportedMotionPageStatus(status + (failed ? ' · ' + failed + ' file/clip(s) skipped.' : ''), failed ? 'error' : 'ready');
      renderImportedMotionsPage();
    }catch(error){
      setImportedMotionPageStatus(error.message || String(error), 'error');
    }
  });
  renderImportedMotionsPage();
}

window.addEventListener('imported-motions:changed', renderImportedMotionsPage);

nav.registerPage({
  id:'imported-motions',
  label:'Imported Motion',
  order:12,
  icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19V5M4 19h16"/><path d="m7 14 3-4 3 3 4-6"/></svg>',
  mount:mountImportedMotionsPage,
  onShow:renderImportedMotionsPage,
});