async function importMotionFile(file){
  if(!window.viewerRuntime.isReady()) throw new Error('The 3D library is not ready yet.');
  if(!window.characterRuntime.getModel()) throw new Error('Wait for the X_Bot character to finish loading.');
  if(!window.characterRuntime.getRig()) throw new Error('The current character does not have the required X_Bot-compatible bones.');

  const sourceBuffer=await file.arrayBuffer();
  const sourceHash=await hashImportedMotionFile(sourceBuffer);
  if(await hasImportedMotionSourceHash(sourceHash)){
    return { imported:[],failures:[{ name:file.name,error:'This FBX file has already been imported.' }] };
  }
  const parsed = await parseImportedMotionFbx(file,sourceBuffer,sourceHash);
  try{
    const clips = extractImportedAnimationClips(parsed.animations, file.name);
    const targetRegistry = window.characterRuntime.getSkeletonRegistry();
    const targetHeight = window.characterRuntime.getMeasurements()?.dimensions.height || 0;
    const imported = [], failures = [];
    for(const entry of clips){
      try{
        const result = retargetImportedClipToXBot(entry.clip, parsed.skeleton, targetRegistry, parsed.sourceHeight, targetHeight, parsed.analysis);
        const importedId=createImportedMotionId();
        let learning=null;
        try{
          const sourceClipAnalysis=parsed.analysis.clips.find(analysis=>analysis.clip===entry.clip);
          const frames=await sampleMotionLearningFrames(parsed.root,entry.clip,parsed.skeleton,sourceClipAnalysis);
          const motionIR=createMotionIR({
            id:importedId+'-knowledge',
            sourceFile:file.name,
            sourceHeight:parsed.sourceHeight,
            skeleton:parsed.skeleton,
            targetRegistry,
            clip:entry.clip,
            clipAnalysis:sourceClipAnalysis,
            frames,
            retargetResult:result,
          });
          const knowledge=await window.motionLearningRuntime.register({
            id:motionIR.metadata.id,
            name:entry.name,
            source:file.name,
            sourceMotionId:importedId,
            createdAt:Date.now(),
            motionIR,
          });
          learning={ id:knowledge.id,status:motionIR.validation.valid?'ready':'validation-warning',frameCount:frames.length,phaseCount:motionIR.phases.length,contactCount:motionIR.contacts.length,featureCount:Object.keys(motionIR.motionFeatures).length };
        }catch(error){
          learning={ status:'analysis-failed',error:error.message||String(error) };
        }
        const record = {
          id:importedId,
          name:entry.name,
          sourceFile:file.name,
          sourceHash,
          clipName:entry.sourceClipName,
          duration:result.clip.duration,
          mappingStatus:result.mappingStatus,
          mappedTrackCount:result.mappedTrackCount,
          skippedTracks:result.skippedTracks.map(track=>track.name),
          diagnostics:result.sourceDiagnostics,
          mapping:result.mapping,
          rootMotion:result.rootMotion,
          sourceMotion:{
            duration:result.clip.duration,
            sampleRate:result.sourceDiagnostics && result.sourceDiagnostics.sampleRate,
            sourceRig:parsed.analysis.sourceRig,
            hierarchy:parsed.analysis.nodes.map(node=>({
              name:node.name,
              normalizedName:node.normalizedName,
              parent:node.parent,
              depth:node.depth,
              isBone:node.isBone,
              localPosition:node.position.toArray(),
              worldRotation:node.worldRotation.toArray(),
            })),
            coordinateSystem:parsed.analysis.coordinateSystem,
            sourceScale:parsed.sourceHeight,
            clip:THREE.AnimationClip.toJSON(entry.clip),
          },
          learning,
          heightRatio:result.heightRatio,
          createdAt:Date.now(),
          clip:THREE.AnimationClip.toJSON(result.clip),
        };
        try{
          imported.push(await persistImportedMotionRecord(record));
        }catch(error){
          if(learning&&learning.id) await window.motionLearningRuntime.remove(learning.id).catch(()=>{});
          throw error;
        }
      }catch(error){ failures.push({ name:entry.name, error:error.message || String(error) }); }
    }
    if(!imported.length){
      const detail = failures.map(failure=>failure.name + ': ' + failure.error).join(' ');
      throw new Error(detail || 'No compatible animation clips could be imported.');
    }
    return { imported, failures };
  }finally{
    disposeImportedMotionSource(parsed.root);
  }
}

async function hashImportedMotionFile(buffer){
  if(window.crypto&&crypto.subtle){
    const digest=await crypto.subtle.digest('SHA-256',buffer);
    return [...new Uint8Array(digest)].map(value=>value.toString(16).padStart(2,'0')).join('');
  }
  const bytes=new Uint8Array(buffer);
  let first=2166136261,second=2246822519;
  for(const byte of bytes){
    first=Math.imul(first^byte,16777619);
    second=Math.imul(second^byte,3266489917);
  }
  return (first>>>0).toString(16).padStart(8,'0')+(second>>>0).toString(16).padStart(8,'0')+':'+bytes.length;
}

async function importMotionFiles(files,onProgress){
  const queue=Array.from(files||[]);
  const imported=[],failures=[];
  for(let index=0;index<queue.length;index++){
    if(typeof onProgress==='function') onProgress({ current:index+1,total:queue.length,file:queue[index].name });
    try{
      const result=await importMotionFile(queue[index]);
      imported.push(...result.imported);
      failures.push(...result.failures.map(failure=>({ ...failure,file:queue[index].name })));
    }catch(error){ failures.push({ name:queue[index].name,file:queue[index].name,error:error.message||String(error) }); }
  }
  return { imported,failures };
}

Object.assign(window.importedMotionRuntime, {
  importFile:importMotionFile,
  importFiles:importMotionFiles,
  retarget:retargetImportedClipToXBot,
});