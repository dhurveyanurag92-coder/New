function resolveImportedTrackNode(root, track){
  const parsed = THREE.PropertyBinding.parseTrackName(track.name);
  const candidates = [parsed.nodeName, parsed.objectName, ...track.name.split(/[|/:.()[\]]+/).reverse()]
    .filter(name=>typeof name === 'string' && name.length);
  for(const name of candidates){
    const node = root.getObjectByName(name);
    if(node) return node;
  }
  return null;
}

function importedNodeDepth(node, root){
  let depth = 0;
  for(let parent = node.parent; parent && parent !== root.parent; parent = parent.parent){
    depth++;
    if(parent === root) break;
  }
  return depth;
}

function inferImportedSampleRate(clip){
  let smallestStep = Infinity;
  for(const track of clip.tracks || []){
    for(let index = 1; index < track.times.length; index++){
      const step = track.times[index] - track.times[index - 1];
      if(step > 1e-6) smallestStep = Math.min(smallestStep, step);
    }
  }
  return Number.isFinite(smallestStep) ? Math.round(1 / smallestStep) : null;
}

function analyzeImportedMotionStructure(root, animations, skeleton){
  const nodes = [];
  root.updateMatrixWorld(true);
  root.traverse(node=>{
    const record = {
      node,
      name:node.name || '(unnamed)',
      normalizedName:normName(node.name),
      parent:node.parent ? node.parent.name || '(unnamed)' : null,
      depth:importedNodeDepth(node, root),
      isBone:!!node.isBone,
      position:node.position.clone(),
      worldRotation:new THREE.Quaternion(),
    };
    node.getWorldQuaternion(record.worldRotation);
    nodes.push(record);
  });

  const clips = (animations || []).map(clip=>{
    const trackNodes = new Map();
    const channels = { translation:0, rotation:0, scale:0, unsupported:0, unresolved:0 };
    const animatedNodes = new Set();
    for(const track of clip.tracks || []){
      const parsed = THREE.PropertyBinding.parseTrackName(track.name);
      const node = resolveImportedTrackNode(root, track);
      trackNodes.set(track, node);
      if(node) animatedNodes.add(node.name || '(unnamed)');
      else channels.unresolved++;
      if(parsed.propertyName === 'position') channels.translation++;
      else if(parsed.propertyName === 'quaternion' || parsed.propertyName === 'rotation') channels.rotation++;
      else if(parsed.propertyName === 'scale') channels.scale++;
      else channels.unsupported++;
    }

    const pelvis = skeleton.bones.find(record=>record.semanticRole === 'Pelvis' && !record.isAuxiliaryClone)
      || skeleton.bones.filter(record=>!record.isAuxiliaryClone).slice().sort((left, right)=>{
        const leftKnown = /hip|pelvis/.test(left.normalizedName) ? 1 : 0;
        const rightKnown = /hip|pelvis/.test(right.normalizedName) ? 1 : 0;
        return rightKnown - leftKnown || right.children.length - left.children.length || left.hierarchyDepth - right.hierarchyDepth;
      })[0];
    const pelvisNode = pelvis && pelvis.bone;
    const rootCandidates = (clip.tracks || [])
      .filter(track=>['position', 'quaternion', 'rotation', 'scale'].includes(THREE.PropertyBinding.parseTrackName(track.name).propertyName))
      .map(track=>trackNodes.get(track))
      .filter((node, index, candidates)=>node && candidates.indexOf(node) === index
        && pelvisNode && (node === pelvisNode || isImportedAncestor(node, pelvisNode)))
      .sort((left, right)=>importedNodeDepth(left, root) - importedNodeDepth(right, root));
    const rootNode = rootCandidates[0] || null;
    const rootTracks = rootNode ? (clip.tracks || []).filter(track=>trackNodes.get(track) === rootNode
      && ['position', 'quaternion', 'rotation', 'scale'].includes(THREE.PropertyBinding.parseTrackName(track.name).propertyName)) : [];
    return {
      clip,
      name:clip.name || 'Unnamed clip',
      duration:Number(clip.duration) || 0,
      sampleRate:inferImportedSampleRate(clip),
      trackCount:(clip.tracks || []).length,
      channels,
      animatedNodes:[...animatedNodes],
      rootMotion:rootNode ? {
        nodeName:rootNode.name || '(unnamed)',
        isBone:!!rootNode.isBone,
        isPelvisRoot:rootNode === pelvisNode,
        pelvisNodeName:pelvisNode && (pelvisNode.name || '(unnamed)'),
        motionSpace:rootNode === pelvisNode ? 'skeleton-root' : 'ancestor-root',
        node:rootNode,
        tracks:rootTracks,
      } : null,
      trackNodes,
    };
  });

  return {
    nodes,
    clips,
    sourceRig:skeleton.bones.map(record=>({
      originalName:record.originalName,
      normalizedName:record.normalizedName,
      parent:record.parent,
      children:record.children,
      hierarchyDepth:record.hierarchyDepth,
      side:record.side,
      semanticRole:record.semanticRole,
      mappingStatus:record.mappingStatus,
      mappingConfidence:record.mappingConfidence,
      restPosition:record.restPosition.toArray(),
      restRotation:record.restRotation.toArray(),
      restScale:record.restScale.toArray(),
    })),
    coordinateSystem:'Three.js scene space (FBXLoader output)',
  };
}

function isImportedAncestor(ancestor, node){
  for(let parent=node.parent; parent; parent=parent.parent){
    if(parent === ancestor) return true;
  }
  return false;
}