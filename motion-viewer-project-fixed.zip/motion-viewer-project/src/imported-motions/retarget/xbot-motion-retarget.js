function retargetImportedClipToXBot(clip, sourceRegistry, targetRegistry, sourceHeight, targetHeight, sourceAnalysis){
  const mapping = inspectXBotBoneMapping(sourceRegistry, targetRegistry);
  if(mapping.missingTarget.length){
    throw new Error('The current character is missing required bones: ' + mapping.missingTarget.join(', '));
  }
  const heightRatio = sourceHeight > 0 && targetHeight > 0 ? targetHeight / sourceHeight : 1;
  const sourceClip = sourceAnalysis && sourceAnalysis.clips.find(entry=>entry.clip === clip);
  const rootMotion = sourceClip && sourceClip.rootMotion;
  const rootTrackSet = new Set(rootMotion ? rootMotion.tracks : []);
  const tracks = rootMotion ? clip.tracks.filter(track=>!rootTrackSet.has(track)) : clip.tracks;
  const result = retargetAnimationClip(new THREE.AnimationClip(clip.name, clip.duration, tracks, clip.blendMode), sourceRegistry, targetRegistry, { heightRatio });
  let retargetedTracks = result.clip.tracks.slice();
  if(rootMotion){
    retargetedTracks.push(...retargetImportedRootTracks(rootMotion, window.characterRuntime.getModel(), heightRatio));
  }
  const rootPositionTrack = retargetedTracks.find(track=>track.name === '.position');
  const rootRotationTrack = retargetedTracks.find(track=>track.name === '.quaternion');
  let cycleDelta = null, cycleRotation = null;
  if(rootPositionTrack && rootPositionTrack.values.length >= 6){
    const last = rootPositionTrack.values.length - 3;
    cycleDelta = [
      rootPositionTrack.values[last] - rootPositionTrack.values[0],
      rootPositionTrack.values[last + 1] - rootPositionTrack.values[1],
      rootPositionTrack.values[last + 2] - rootPositionTrack.values[2],
    ];
  }
  if(rootRotationTrack && rootRotationTrack.values.length >= 8){
    const last = rootRotationTrack.values.length - 4;
    const start = new THREE.Quaternion(...rootRotationTrack.values.slice(0, 4));
    const end = new THREE.Quaternion(...rootRotationTrack.values.slice(last));
    const delta = end.multiply(start.invert()).normalize();
    cycleRotation = [delta.x, delta.y, delta.z, delta.w];
  }
  const retargetedClip = new THREE.AnimationClip(clip.name, clip.duration, retargetedTracks, clip.blendMode);
  const unresolvedSourceRoles = mapping.missingSource.filter(key=>{
    const targetBone = mapping.targetMapping.bones[key];
    return !targetBone || !result.boneMapping.some(match=>match.targetName === targetBone.name);
  });
  return {
    clip:retargetedClip,
    mappedTrackCount:retargetedTracks.length,
    skippedTracks:result.skippedTracks,
    mappingStatus:result.skippedTracks.length || unresolvedSourceRoles.length ? 'Mapping Incomplete' : 'Mapping Successful',
    mapping:{
      missingSource:unresolvedSourceRoles,
      missingTarget:mapping.missingTarget,
      source:sourceRegistry.bones.map(record=>{
        const match = result.boneMapping.find(entry=>entry.sourceName === record.originalName);
        return {
          name:record.originalName,
          role:record.semanticRole,
          side:record.side,
          status:record.mappingStatus,
          confidence:record.mappingConfidence,
          target:match ? match.targetName : null,
          method:match ? match.method : null,
          targetConfidence:match ? match.confidence : 0,
        };
      }),
    },
    rootMotion:rootMotion ? {
      nodeName:rootMotion.nodeName,
      isPelvisRoot:rootMotion.isPelvisRoot,
      pelvisNodeName:rootMotion.pelvisNodeName,
      motionSpace:rootMotion.motionSpace,
      trackNames:rootMotion.tracks.map(track=>track.name),
      cycleDelta,
      cycleRotation,
    } : null,
    heightRatio,
    sourceDiagnostics:sourceClip ? {
      duration:sourceClip.duration,
      sampleRate:sourceClip.sampleRate,
      trackCount:sourceClip.trackCount,
      channels:sourceClip.channels,
      animatedNodeCount:sourceClip.animatedNodes.length,
      coordinateSystem:sourceAnalysis.coordinateSystem,
      sourceBoneCount:sourceRegistry.bones.length,
    } : null,
  };
}