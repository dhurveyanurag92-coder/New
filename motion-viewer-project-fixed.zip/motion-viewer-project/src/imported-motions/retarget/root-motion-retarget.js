function retargetImportedRootTracks(rootMotion, targetModel, heightRatio){
  if(!rootMotion || !targetModel) return [];
  const sourceParent = rootMotion.node.parent;
  const sourceParentRotation = new THREE.Quaternion();
  const sourceParentScale = new THREE.Vector3(1, 1, 1);
  if(sourceParent){
    sourceParent.getWorldQuaternion(sourceParentRotation);
    sourceParent.getWorldScale(sourceParentScale);
  }
  const targetParent = targetModel.parent;
  const targetParentRotation = new THREE.Quaternion();
  const targetParentScale = new THREE.Vector3(1, 1, 1);
  if(targetParent){
    targetParent.getWorldQuaternion(targetParentRotation);
    targetParent.getWorldScale(targetParentScale);
  }
  const targetParentInverse = targetParentRotation.clone().invert();
  const targetBaseRotation = targetModel.quaternion.clone();
  const targetBasePosition = targetModel.position.clone();
  const targetBaseScale = targetModel.scale.clone();
  const sourceRestRotation = rootMotion.node.quaternion.clone();
  const sourceRestInverse = sourceRestRotation.clone().invert();
  const sourceWorldInverse = sourceParentRotation.clone().invert();
  const tracks = rootMotion.tracks || [];
  const hasQuaternion = tracks.some(track=>THREE.PropertyBinding.parseTrackName(track.name).propertyName === 'quaternion');
  const retargeted = [];

  for(const sourceTrack of tracks){
    const property = THREE.PropertyBinding.parseTrackName(sourceTrack.name).propertyName;
    const step = sourceTrack.getValueSize();
    if(property === 'position' && step === 3){
      const values = new Float32Array(sourceTrack.values.length);
      const delta = new THREE.Vector3();
      for(let index=0; index<sourceTrack.values.length; index+=step){
        delta.set(
          sourceTrack.values[index] - rootMotion.node.position.x,
          sourceTrack.values[index + 1] - rootMotion.node.position.y,
          sourceTrack.values[index + 2] - rootMotion.node.position.z,
        ).multiply(sourceParentScale).applyQuaternion(sourceParentRotation).applyQuaternion(targetParentInverse);
        delta.divide(targetParentScale).multiplyScalar(heightRatio);
        values[index] = targetBasePosition.x + delta.x;
        values[index + 1] = targetBasePosition.y + delta.y;
        values[index + 2] = targetBasePosition.z + delta.z;
      }
      const track = sourceTrack.clone();
      track.name = '.position';
      track.values = values;
      retargeted.push(track);
      continue;
    }
    if(property === 'scale' && step === 3){
      const values = new Float32Array(sourceTrack.values.length);
      for(let index=0; index<sourceTrack.values.length; index+=step){
        values[index] = targetBaseScale.x * sourceTrack.values[index] / (rootMotion.node.scale.x || 1);
        values[index + 1] = targetBaseScale.y * sourceTrack.values[index + 1] / (rootMotion.node.scale.y || 1);
        values[index + 2] = targetBaseScale.z * sourceTrack.values[index + 2] / (rootMotion.node.scale.z || 1);
      }
      const track = sourceTrack.clone();
      track.name = '.scale';
      track.values = values;
      retargeted.push(track);
      continue;
    }
    if((property !== 'quaternion' && property !== 'rotation') || step !== (property === 'quaternion' ? 4 : 3)) continue;
    if(property === 'rotation' && hasQuaternion) continue;
    const values = new Float32Array(sourceTrack.values.length);
    const sourceAnimated = new THREE.Quaternion();
    const sourceDelta = new THREE.Quaternion();
    const worldDelta = new THREE.Quaternion();
    const targetDelta = new THREE.Quaternion();
    const targetRotation = new THREE.Quaternion();
    const sourceEuler = new THREE.Euler(0, 0, 0, rootMotion.node.rotation.order);
    const targetEuler = new THREE.Euler(0, 0, 0, targetModel.rotation.order);
    for(let index=0; index<sourceTrack.values.length; index+=step){
      if(property === 'quaternion'){
        sourceAnimated.set(sourceTrack.values[index], sourceTrack.values[index + 1], sourceTrack.values[index + 2], sourceTrack.values[index + 3]);
      }else{
        sourceEuler.set(sourceTrack.values[index], sourceTrack.values[index + 1], sourceTrack.values[index + 2], rootMotion.node.rotation.order);
        sourceAnimated.setFromEuler(sourceEuler);
      }
      sourceDelta.copy(sourceRestInverse).multiply(sourceAnimated);
      worldDelta.copy(sourceParentRotation).multiply(sourceDelta).multiply(sourceWorldInverse);
      targetDelta.copy(targetParentInverse).multiply(worldDelta).multiply(targetParentRotation);
      targetRotation.copy(targetBaseRotation).multiply(targetDelta).normalize();
      if(property === 'quaternion'){
        values.set([targetRotation.x, targetRotation.y, targetRotation.z, targetRotation.w], index);
      }else{
        targetEuler.setFromQuaternion(targetRotation, targetModel.rotation.order);
        values.set([targetEuler.x, targetEuler.y, targetEuler.z], index);
      }
    }
    const track = property === 'quaternion'
      ? sourceTrack.clone()
      : new THREE.QuaternionKeyframeTrack('.quaternion', sourceTrack.times, values, sourceTrack.getInterpolation());
    track.name = '.quaternion';
    track.values = values;
    retargeted.push(track);
  }
  return retargeted;
}