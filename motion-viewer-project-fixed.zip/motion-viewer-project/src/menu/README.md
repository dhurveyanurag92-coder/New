# Menu

Owns the app header, drawer markup/styles, open/close behavior, page transitions, and menu rendering. Edit `menu.html`, `menu.css`, and `menu.js` for menu changes.

Pages register themselves with `nav.registerPage({...})` in their feature entry file. The menu only consumes that page contract; it does not implement Frame Code, Motion Analysis, or GLB behavior. Register menu markup/styles/runtime in the `menu` entry in `build.py` and keep its runtime phase before page modules.
