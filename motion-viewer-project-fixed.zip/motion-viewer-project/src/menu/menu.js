/* ------------------------------------------------------------------ navigation: header menu + pages
   To add a page, call nav.registerPage({...}) once (see the two below). It appears in the slide-out menu by itself.
     id      unique key                       label   text shown in the menu
     icon    optional inline <svg> string     order   menu position (lower = higher up)
   Then give it ONE of:
     mount(el)        builds the page inside a fresh container `el` (called once, the page is kept afterwards)
     open()/close()   for pages that own their own screen; open() may return false if it could not open
     canOpen()        optional: return false to stay on the current page (show your own message)
   Optional: onShow() / onHide() for mount pages. Nothing here reloads the app, so the viewer state stays as it is. */
const nav = (function(){
  const pages = new Map();
  const menuBtn = $('#menuBtn'), scrim = $('#navScrim'), drawer = $('#sideNav'), list = $('#navList');
  const host = $('#pageHost'), hdrPage = $('#hdrPage');
  let activeId = 'home', token = 0;
  const isOpen = () => drawer.classList.contains('open');

  function renderMenu(){
    list.textContent = '';
    [...pages.values()].sort((a,b)=>(a.order ?? 100)-(b.order ?? 100)).forEach(p=>{
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'navItem'; b.dataset.id = p.id;
      if(p.icon){ const i = document.createElement('span'); i.style.display = 'contents'; i.innerHTML = p.icon; b.appendChild(i); }
      const t = document.createElement('span'); t.textContent = p.label; b.appendChild(t);
      if(p.id === activeId) b.setAttribute('aria-current', 'page');
      b.addEventListener('click', ()=>go(p.id));
      list.appendChild(b);
    });
  }
  function setActive(id){
    activeId = id; const p = pages.get(id);
    hdrPage.hidden = (id === 'home'); hdrPage.textContent = (id === 'home' || !p) ? '' : '· ' + p.label;
    list.querySelectorAll('.navItem').forEach(b=>{ if(b.dataset.id === id) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  }
  function registerPage(def){
    if(!def || !def.id || !def.label) throw new Error('A page needs an id and a label.');
    pages.set(def.id, def); renderMenu();
  }

  function openMenu(){
    if(isOpen()) return;
    drawer.classList.add('open'); scrim.classList.add('open');
    document.body.classList.add('modal-nav-open');
    menuBtn.setAttribute('aria-expanded', 'true'); menuBtn.setAttribute('aria-label', 'Close menu');
    requestAnimationFrame(()=>{ const f = drawer.querySelector('[aria-current]') || drawer.querySelector('.navItem'); if(f) f.focus({preventScroll:true}); });
  }
  function closeMenu(){
    if(!isOpen()) return;
    const hadFocus = drawer.contains(document.activeElement);
    drawer.classList.remove('open'); scrim.classList.remove('open');
    document.body.classList.remove('modal-nav-open');
    menuBtn.setAttribute('aria-expanded', 'false'); menuBtn.setAttribute('aria-label', 'Open menu');
    if(hadFocus) menuBtn.focus({preventScroll:true});
  }
  const toggleMenu = () => isOpen() ? closeMenu() : openMenu();

  async function enter(p){
    if(p.canOpen && p.canOpen() === false) return false;
    if(p.mount){
      host.hidden = false;
      if(!p._el){ p._el = document.createElement('section'); p._el.className = 'page'; host.appendChild(p._el); p.mount(p._el); }
      p._el.hidden = false; if(p.onShow) p.onShow();
      return true;
    }
    return p.open ? p.open() : true;
  }
  function leave(p){
    if(!p) return;
    if(p._el){ p._el.hidden = true; host.hidden = true; if(p.onHide) p.onHide(); }
    if(p.close) p.close();
  }
  async function go(id){
    closeMenu();
    const next = pages.get(id);
    if(!next || id === activeId) return;
    const mine = ++token;
    leave(pages.get(activeId));
    setActive('home');
    let ok;
    try{ ok = await enter(next); }
    catch(err){ console.error(err); ok = false; toast('Could not open this page.', 3000); }
    if(mine !== token){ leave(next); return; }
    if(ok !== false) setActive(id);
  }

  menuBtn.addEventListener('click', toggleMenu);
  scrim.addEventListener('click', closeMenu);
  window.addEventListener('keydown', e=>{
    if(!isOpen()) return;
    if(e.key === 'Escape'){ closeMenu(); menuBtn.focus({preventScroll:true}); }
    else if(e.code === 'Space') e.stopPropagation();       // Space on a menu item must not also toggle Play
  }, true);

  return { registerPage, go, openMenu, closeMenu, toggleMenu, get active(){ return activeId; } };
})();
