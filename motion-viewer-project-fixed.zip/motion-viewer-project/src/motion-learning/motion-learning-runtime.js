const motionLearningIndex=new Map();
let motionLearningReady=Promise.resolve([]);

function motionLearningSummary(record){
  return createMotionKnowledgeIndexRecord(record);
}

function registerMotionKnowledge(record){
  const summary=motionLearningSummary(record);
  return saveMotionKnowledgeRecord(record).then(()=>{
    motionLearningIndex.set(record.id,summary);
    window.dispatchEvent(new CustomEvent('motion-learning:changed',{ detail:{ id:record.id } }));
    return summary;
  });
}

function hydrateMotionKnowledgeIndex(){
  motionLearningReady=listMotionKnowledgeIndex().then(records=>{
    motionLearningIndex.clear();
    for(const record of records||[]) motionLearningIndex.set(record.id,record);
    return [...motionLearningIndex.values()];
  });
  return motionLearningReady;
}

function findMotionKnowledge(idOrName){
  const key=String(idOrName||'').trim();
  if(!key) return null;
  return motionLearningIndex.get(key)||[...motionLearningIndex.values()].find(record=>record.name.toLowerCase()===key.toLowerCase())||null;
}

function queryMotionKnowledge(criteria={}){
  const text=String(criteria.text||'').toLowerCase();
  return [...motionLearningIndex.values()].filter(record=>{
    if(text&&!record.name.toLowerCase().includes(text)&&!String(record.source||'').toLowerCase().includes(text)
      &&!(record.motionFeatures.descriptors||[]).some(value=>value.includes(text))
      &&!record.contacts.some(contact=>contact.type.includes(text))
      &&!record.relationships.some(relation=>(relation.from+' '+relation.to).toLowerCase().includes(text))) return false;
    if(Number.isFinite(criteria.minDuration)&&record.duration<criteria.minDuration) return false;
    if(criteria.hasRootMotion!==undefined&&record.rootMotion.detected!==!!criteria.hasRootMotion) return false;
    if(Number.isFinite(criteria.minRootSpeed)&&record.motionFeatures.maximumRootSpeed<criteria.minRootSpeed) return false;
    if(criteria.descriptor&&!(record.motionFeatures.descriptors||[]).includes(criteria.descriptor)) return false;
    if(criteria.phase&&!record.phases.some(phase=>phase.label===criteria.phase)) return false;
    if(criteria.contactType&&!record.contacts.some(contact=>contact.type===criteria.contactType)) return false;
    if(criteria.relationshipFrom&&!record.relationships.some(relation=>relation.from===criteria.relationshipFrom)) return false;
    if(criteria.relationshipTo&&!record.relationships.some(relation=>relation.to===criteria.relationshipTo)) return false;
    if(criteria.joint&&Number.isFinite(criteria.minJointRange)){
      const joint=record.jointRanges.find(range=>range.name===criteria.joint);
      if(!joint||joint.range<criteria.minJointRange) return false;
    }
    return true;
  });
}

function interpolateMotionSamples(samples,time,field){
  if(!samples||!samples.length) return null;
  if(time<=samples[0].time) return samples[0][field];
  const last=samples[samples.length-1];
  if(time>=last.time) return last[field];
  let upper=1;
  while(upper<samples.length&&samples[upper].time<time) upper++;
  const before=samples[upper-1],after=samples[upper];
  const alpha=(time-before.time)/Math.max(1e-8,after.time-before.time);
  const from=before[field],to=after[field];
  if(Array.isArray(from)&&Array.isArray(to)) return from.map((value,index)=>value+(to[index]-value)*alpha);
  if(from&&to&&typeof from==='object'&&typeof to==='object') return Object.fromEntries(Object.keys(from).map(key=>[key,from[key]+(to[key]-from[key])*alpha]));
  return from+(to-from)*alpha;
}

function sampleMotionKnowledge(idOrName,time,actionDuration,cycleCount=0){
  const record=findMotionKnowledge(idOrName);
  if(!record) return null;
  const sourceDuration=Math.max(0,record.duration||0);
  const normalized=actionDuration>0?Math.max(0,Math.min(1,(Number(time)||0)/actionDuration)):0;
  const sampleTime=sourceDuration*normalized;
  const controls={};
  for(const curve of record.controlCurves||[]){
    const rotation=interpolateMotionRotation(curve.samples,sampleTime,'rotation');
    if(rotation){
      const euler=new THREE.Euler().setFromQuaternion(rotation,'XYZ');
      controls[curve.key]=[euler.x,euler.y,euler.z];
    }
  }
  const trajectory=record.rootMotion&&record.rootMotion.trajectory||[];
  const rootSample=interpolateMotionSamples(trajectory,sampleTime,'normalizedPosition');
  const rotation=interpolateMotionRotation(trajectory,sampleTime,'rotation');
  const targetHeight=window.characterRuntime&&window.characterRuntime.getMeasurements()?.dimensions.height||1;
  let rootMotion=null;
  if(rootSample){
    const trajectory=record.rootMotion&&record.rootMotion.trajectory||[];
    const cyclePosition=trajectory.length?trajectory[trajectory.length-1].normalizedPosition:{x:0,y:0,z:0};
    const cycleRotation=trajectory.length?new THREE.Quaternion(...trajectory[trajectory.length-1].rotation):new THREE.Quaternion();
    const cycleOffset=new THREE.Vector3();
    const cycleStep=new THREE.Vector3(cyclePosition.x,cyclePosition.y,cyclePosition.z);
    const cycleOrientation=new THREE.Quaternion();
    for(let index=0;index<Math.max(0,cycleCount);index++){
      cycleOffset.add(cycleStep.clone().applyQuaternion(cycleOrientation));
      cycleOrientation.multiply(cycleRotation).normalize();
    }
    const position=new THREE.Vector3(rootSample.x,rootSample.y,rootSample.z).applyQuaternion(cycleOrientation).add(cycleOffset).multiplyScalar(targetHeight);
    const combinedRotation=cycleOrientation.clone().multiply(rotation||new THREE.Quaternion()).normalize();
    rootMotion={
      position:{x:position.x,y:position.y,z:position.z},
      rotation:[combinedRotation.x,combinedRotation.y,combinedRotation.z,combinedRotation.w],
    };
  }
  const activeContacts=(record.contacts||[]).filter(contact=>sampleTime>=contact.startTime&&sampleTime<=contact.endTime);
  return { motionId:record.id,time:sampleTime,controls,rootMotion,activeContacts,cycleCount };
}

function interpolateMotionRotation(samples,time,field){
  if(!samples||!samples.length) return null;
  if(time<=samples[0].time) return new THREE.Quaternion(...samples[0][field]).normalize();
  const last=samples[samples.length-1];
  if(time>=last.time) return new THREE.Quaternion(...last[field]).normalize();
  let upper=1;
  while(upper<samples.length&&samples[upper].time<time) upper++;
  const before=samples[upper-1],after=samples[upper];
  const alpha=(time-before.time)/Math.max(1e-8,after.time-before.time);
  return new THREE.Quaternion(...before[field]).slerp(new THREE.Quaternion(...after[field]),alpha).normalize();
}

async function getMotionKnowledge(id){
  return getMotionKnowledgeRecord(id);
}

async function removeMotionKnowledge(id){
  await deleteMotionKnowledgeRecord(id);
  motionLearningIndex.delete(id);
  window.dispatchEvent(new CustomEvent('motion-learning:changed',{ detail:{ id } }));
}

async function setMotionKnowledgePhaseOverrides(id,phaseRanges){
  const record=await getMotionKnowledgeRecord(id);
  if(!record) throw new Error('Motion Knowledge was not found.');
  const phases=(phaseRanges||[]).map((phase,index)=>{
    const startTime=Number(phase.startTime),endTime=Number(phase.endTime);
    if(!Number.isFinite(startTime)||!Number.isFinite(endTime)||startTime<0||endTime<=startTime||endTime>record.motionIR.duration){
      throw new Error('Phase '+(index+1)+' needs a valid time range inside the motion duration.');
    }
    return { label:String(phase.label||'manual-phase'),startTime,endTime,source:'manual' };
  }).sort((left,right)=>left.startTime-right.startTime);
  const updated={ ...record,motionIR:{ ...record.motionIR,phases } };
  await registerMotionKnowledge(updated);
  return phases;
}

window.motionLearningRuntime={
  ready:()=>motionLearningReady,
  hydrate:hydrateMotionKnowledgeIndex,
  register:registerMotionKnowledge,
  find:findMotionKnowledge,
  query:queryMotionKnowledge,
  sample:sampleMotionKnowledge,
  setPhaseOverrides:setMotionKnowledgePhaseOverrides,
  get:getMotionKnowledge,
  remove:removeMotionKnowledge,
  getIndex:()=>[...motionLearningIndex.values()],
};

window.addEventListener('character:loaded',()=>{
  hydrateMotionKnowledgeIndex().catch(error=>console.error('Motion knowledge index could not be loaded.',error));
});