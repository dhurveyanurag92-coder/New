const MOTION_RELATION_PAIRS = [
  ['LeftHand', 'LeftKnee'], ['RightHand', 'RightKnee'],
  ['LeftHand', 'LeftShoulder'], ['RightHand', 'RightShoulder'],
  ['LeftForeArm', 'LeftArm'], ['RightForeArm', 'RightArm'],
  ['LeftKnee', 'LeftHip'], ['RightKnee', 'RightHip'],
  ['LeftKnee', 'LeftAnkle'], ['RightKnee', 'RightAnkle'],
  ['Head', 'Chest'], ['Chest', 'Pelvis'],
];

function motionLearningDistance(left, right){
  const x=left.x-right.x, y=left.y-right.y, z=left.z-right.z;
  return Math.sqrt(x*x+y*y+z*z);
}

function motionLearningMean(values){
  return values.length ? values.reduce((sum, value)=>sum+value, 0)/values.length : 0;
}

function motionLearningStatistics(values){
  if(!values.length) return { min:0, max:0, mean:0, range:0 };
  const min=Math.min(...values), max=Math.max(...values);
  return { min, max, mean:motionLearningMean(values), range:max-min };
}

function motionLearningDecimate(samples,limit=120){
  if(samples.length<=limit) return samples;
  return Array.from({ length:limit },(_,index)=>samples[Math.round(index*(samples.length-1)/(limit-1))]);
}

function motionLearningAnalysisSummary(analysis){
  if(!analysis) return null;
  return {
    frameCount:analysis.frameCount,
    duration:analysis.duration,
    timing:analysis.timing,
    characterMovement:analysis.characterMovement,
    characterRotation:analysis.characterRotation,
    mostActiveBones:(analysis.mostActiveBones||[]).map(bone=>({ name:bone.name,parent:bone.parent,totalPositionChange:bone.totalPositionChange,totalRotationChange:bone.totalRotationChange })),
    cycleAnalysis:analysis.cycleAnalysis,
    frameChanges:(analysis.frameChanges||[]).filter((_,index)=>index%Math.max(1,Math.ceil((analysis.frameChanges||[]).length/120))===0),
  };
}

function motionLearningFindBone(frame, semanticRole, side){
  return (frame.bones || []).find(bone=>bone.semanticRole === semanticRole && (!side || bone.side === side)) || null;
}

function motionLearningControlKey(bone){
  if(!bone || !bone.semanticRole) return null;
  const center={ Pelvis:'Hips', Spine:'Spine', Neck:'Neck', Head:'Head' };
  if(center[bone.semanticRole]) return center[bone.semanticRole];
  if(bone.semanticRole==='Chest'){
    const spine=String(bone.normalizedName||'').match(/spine(\d*)$/);
    return spine&&spine[1]?`Spine${Math.min(2,Number(spine[1])||2)}`:'Spine2';
  }
  const sided={ Shoulder:'Shoulder', UpperArm:'Arm', Elbow:'ForeArm', ForeArm:'ForeArm', Hand:'Hand', Thigh:'UpLeg', Knee:'Leg', Shin:'Leg', Ankle:'Foot', Foot:'Foot', Toes:'ToeBase' };
  if(!sided[bone.semanticRole] || bone.side === 'Center') return null;
  return bone.side + sided[bone.semanticRole];
}

function motionLearningControlCurves(frames, skeleton, targetRegistry, retargetResult, rootSource){
  const controls=new Map();
  for(const record of skeleton.bones){
    if(record.isAuxiliaryClone) continue;
    if(rootSource&&rootSource.isPelvisRoot&&record.bone===rootSource.node) continue;
    const mapping=retargetResult&&retargetResult.mapping&&retargetResult.mapping.source.find(entry=>entry.name===record.originalName);
    const targetRecord=mapping&&mapping.target&&targetRegistry.byName.get(mapping.target)?.find(candidate=>!candidate.isAuxiliaryClone);
    if(!targetRecord) continue;
    const key=motionLearningControlKey(targetRecord);
    if(!key) continue;
    const samples=[];
    const sourceRestInverse=record.restRotation.clone().invert();
    const sourceWorldInverse=record.restWorldRotation.clone().invert();
    const targetWorldInverse=targetRecord.restWorldRotation.clone().invert();
    for(const frame of frames){
      const source=frame.bones.find(bone=>bone.originalName === record.originalName);
      if(!source) continue;
      const sourceRotation=new THREE.Quaternion(...source.localRotation);
      const sourceDelta=sourceRestInverse.clone().multiply(sourceRotation);
      const worldDelta=record.restWorldRotation.clone().multiply(sourceDelta).multiply(sourceWorldInverse);
      const targetDelta=targetWorldInverse.clone().multiply(worldDelta).multiply(targetRecord.restWorldRotation).normalize();
      samples.push({ time:frame.time, rotation:[targetDelta.x,targetDelta.y,targetDelta.z,targetDelta.w] });
    }
    if(samples.length) controls.set(key, { key,sourceBone:record.originalName,targetBone:targetRecord.originalName,role:targetRecord.semanticRole,side:targetRecord.side,mappingMethod:mapping.method,mappingConfidence:mapping.targetConfidence,samples:motionLearningDecimate(samples) });
  }
  return [...controls.values()];
}

function motionLearningBuildRelationships(frames, characterHeight){
  const output=[];
  for(const [from,to] of MOTION_RELATION_PAIRS){
    const [fromSide,fromRole]=from.startsWith('Left')?['Left',from.slice(4)]:from.startsWith('Right')?['Right',from.slice(5)]:['Center',from];
    const [toSide,toRole]=to.startsWith('Left')?['Left',to.slice(4)]:to.startsWith('Right')?['Right',to.slice(5)]:['Center',to];
    const samples=[];
    for(const frame of frames){
      const a=motionLearningFindBone(frame, motionLearningRole(fromRole), fromSide);
      const b=motionLearningFindBone(frame, motionLearningRole(toRole), toSide);
      if(!a || !b) continue;
      const difference={ x:b.worldPosition.x-a.worldPosition.x, y:b.worldPosition.y-a.worldPosition.y, z:b.worldPosition.z-a.worldPosition.z };
      const distance=motionLearningDistance(a.worldPosition,b.worldPosition);
      const aRotation=new THREE.Quaternion(...a.worldRotation);
      const bRotation=new THREE.Quaternion(...b.worldRotation);
      const relativeRotation=aRotation.invert().multiply(bRotation).normalize();
      samples.push({ time:frame.time,distance,normalizedDistance:characterHeight>0?distance/characterHeight:distance,direction:difference,relativeRotation:[relativeRotation.x,relativeRotation.y,relativeRotation.z,relativeRotation.w],relativeAngle:2*Math.acos(Math.min(1,Math.abs(relativeRotation.w))) });
    }
    if(samples.length) output.push({ from, to, samples:motionLearningDecimate(samples), distance:motionLearningStatistics(samples.map(sample=>sample.normalizedDistance)) });
  }
  return output;
}

function motionLearningRole(shortName){
  const aliases={ Arm:'UpperArm', Knee:'Shin', Hip:'Thigh', Ankle:'Foot' };
  return aliases[shortName] || shortName;
}

function motionLearningAngle(a, pivot, b){
  if(!a || !pivot || !b) return null;
  const left=new THREE.Vector3(a.worldPosition.x-pivot.worldPosition.x,a.worldPosition.y-pivot.worldPosition.y,a.worldPosition.z-pivot.worldPosition.z);
  const right=new THREE.Vector3(b.worldPosition.x-pivot.worldPosition.x,b.worldPosition.y-pivot.worldPosition.y,b.worldPosition.z-pivot.worldPosition.z);
  if(left.lengthSq()<1e-10 || right.lengthSq()<1e-10) return null;
  return left.angleTo(right);
}

function motionLearningBuildJointCurves(frames){
  const definitions=[];
  for(const side of ['Left','Right']){
    definitions.push({ name:side+'Shoulder', a:['Chest','Center'], pivot:['UpperArm',side], b:['ForeArm',side] });
    definitions.push({ name:side+'Elbow', a:['UpperArm',side], pivot:['ForeArm',side], b:['Hand',side] });
    definitions.push({ name:side+'Hip', a:['Pelvis','Center'], pivot:['Thigh',side], b:['Shin',side] });
    definitions.push({ name:side+'Knee', a:['Thigh',side], pivot:['Shin',side], b:['Foot',side] });
    definitions.push({ name:side+'Ankle', a:['Shin',side], pivot:['Foot',side], b:['Toes',side] });
  }
  definitions.push({ name:'Spine', a:['Pelvis','Center'], pivot:['Spine','Center'], b:['Chest','Center'] });
  definitions.push({ name:'Neck', a:['Chest','Center'], pivot:['Neck','Center'], b:['Head','Center'] });
  const curves=[];
  for(const joint of definitions){
    const samples=[];
    for(const frame of frames){
      const angle=motionLearningAngle(
        motionLearningFindBone(frame,joint.a[0],joint.a[1]),
        motionLearningFindBone(frame,joint.pivot[0],joint.pivot[1]),
        motionLearningFindBone(frame,joint.b[0],joint.b[1]),
      );
      if(angle !== null){
        const previous=samples[samples.length-1];
        const dt=previous?Math.max(1e-5,frame.time-previous.time):1;
        samples.push({ time:frame.time,angle,velocity:previous?(angle-previous.angle)/dt:0 });
      }
    }
    if(samples.length) curves.push({ name:joint.name,samples:motionLearningDecimate(samples),statistics:motionLearningStatistics(samples.map(sample=>sample.angle)),velocityStatistics:motionLearningStatistics(samples.map(sample=>sample.velocity)),current:samples[samples.length-1].angle });
  }
  return curves;
}

function motionLearningBuildContactEvents(frames, characterHeight){
  const events=[];
  const footHeights=frames.flatMap(frame=>(frame.bones||[]).filter(bone=>bone.semanticRole==='Foot'||bone.semanticRole==='Toes').map(bone=>bone.worldPosition.y));
  const allHeights=frames.flatMap(frame=>(frame.bones||[]).map(bone=>bone.worldPosition.y));
  const floor=Math.min(...(footHeights.length?footHeights:allHeights));
  const height=Math.max(characterHeight,1e-5);
  for(const side of ['Left','Right']){
    const footSamples=frames.map((frame,index)=>{
      const foot=motionLearningFindBone(frame,'Foot',side)||motionLearningFindBone(frame,'Toes',side);
      const previous=frames[Math.max(0,index-1)];
      const previousFoot=previous && (motionLearningFindBone(previous,'Foot',side)||motionLearningFindBone(previous,'Toes',side));
      const dt=index>0?Math.max(1e-5,frame.time-previous.time):1;
      const speed=foot&&previousFoot?motionLearningDistance(foot.worldPosition,previousFoot.worldPosition)/dt:Infinity;
      return { time:frame.time, active:!!foot&&foot.worldPosition.y<=floor+height*0.035&&speed<=height*0.16, position:foot&&foot.worldPosition, speed };
    });
    events.push(...motionLearningSegments(footSamples,side.toLowerCase()+'-foot-ground'));
  }
  for(const side of ['Left','Right']){
    const handSamples=frames.map((frame,index)=>{
      const hand=motionLearningFindBone(frame,'Hand',side);
      const before=frames[Math.max(0,index-1)];
      const previous=before&&(motionLearningFindBone(before,'Hand',side));
      const dt=index?Math.max(1e-5,frame.time-before.time):1;
      const speed=hand&&previous?motionLearningDistance(hand.worldPosition,previous.worldPosition)/dt:Infinity;
      return { time:frame.time,active:!!hand&&hand.worldPosition.y<=floor+height*0.04&&speed<=height*0.18,position:hand&&hand.worldPosition,speed };
    });
    events.push(...motionLearningSegments(handSamples,side.toLowerCase()+'-hand-ground'));
  }
  for(const side of ['Left','Right']){
    const samples=frames.map(frame=>{
      const hand=motionLearningFindBone(frame,'Hand',side);
      const knee=motionLearningFindBone(frame,'Shin',side);
      const distance=hand&&knee?motionLearningDistance(hand.worldPosition,knee.worldPosition):Infinity;
      return { time:frame.time, active:distance<=height*0.12, position:hand&&hand.worldPosition, speed:0 };
    });
    events.push(...motionLearningSegments(samples,side.toLowerCase()+'-hand-knee'));
  }
  for(const role of ['Pelvis','Chest','Head','Thigh','Shin']){
    const samples=frames.map((frame,index)=>{
      const body=motionLearningFindBone(frame,role);
      const before=frames[Math.max(0,index-1)];
      const previous=before&&motionLearningFindBone(before,role);
      const dt=index?Math.max(1e-5,frame.time-before.time):1;
      const speed=body&&previous?motionLearningDistance(body.worldPosition,previous.worldPosition)/dt:Infinity;
      return { time:frame.time,active:!!body&&body.worldPosition.y<=floor+height*0.045&&speed<=height*0.18,position:body&&body.worldPosition,speed };
    });
    events.push(...motionLearningSegments(samples,role.toLowerCase()+'-ground'));
  }
  return events;
}

function motionLearningSegments(samples,type){
  const events=[];
  let start=-1;
  for(let index=0;index<=samples.length;index++){
    const active=index<samples.length&&samples[index].active;
    if(active&&start<0) start=index;
    if(!active&&start>=0){
      const first=samples[start],last=samples[index-1];
      events.push({ type,startTime:first.time,endTime:last.time,position:first.position,speed:first.speed,velocityAtContact:first.speed,surfaceRelation:type.endsWith('-ground')?'estimated-ground-plane':'body-contact' });
      start=-1;
    }
  }
  return events;
}

function motionLearningBuildPhases(frames, characterHeight){
  if(frames.length<2) return [];
  const height=Math.max(characterHeight,1e-5);
  const labels=frames.map((frame,index)=>{
    const delta=frame.character.deltaFromPrevious.position;
    const dt=index?Math.max(1e-5,frame.time-frames[index-1].time):1;
    const speed=Math.sqrt(delta.x*delta.x+delta.y*delta.y+delta.z*delta.z)/dt;
    const vertical=delta.y/dt;
    const activity=(frame.bones||[]).reduce((sum,bone)=>sum+Math.sqrt(bone.deltaFromPrevious.worldRotation.x**2+bone.deltaFromPrevious.worldRotation.y**2+bone.deltaFromPrevious.worldRotation.z**2),0)/Math.max(1,frame.bones.length)/dt;
    const label=Math.abs(vertical)>height*0.08?(vertical>0?'ascending':'descending'):speed>height*0.12?'translating':activity>0.7?'pose-change':'low-motion';
    return { time:frame.time,label,speed,verticalSpeed:vertical,activity };
  });
  const phases=[];
  let start=0;
  for(let index=1;index<=labels.length;index++){
    if(index<labels.length&&labels[index].label===labels[start].label) continue;
    const segment=labels.slice(start,index);
    phases.push({ label:labels[start].label,startTime:segment[0].time,endTime:segment[segment.length-1].time,frameStart:start+1,frameEnd:index,meanSpeed:motionLearningMean(segment.map(value=>value.speed)),meanActivity:motionLearningMean(segment.map(value=>value.activity)) });
    start=index;
  }
  return phases;
}

function motionLearningBuildRootMotion(frames, rootSource, characterHeight){
  if(!frames.length) return { detected:false, sourceNode:rootSource&&rootSource.nodeName||null, trajectory:[], velocity:[], acceleration:[] };
  const start=frames[0].character.position;
  const startRotation=frames[0].character.quaternion
    ? new THREE.Quaternion(...frames[0].character.quaternion)
    : new THREE.Quaternion().setFromEuler(new THREE.Euler(frames[0].character.rotation.x,frames[0].character.rotation.y,frames[0].character.rotation.z,'XYZ'));
  const startRotationInverse=startRotation.clone().invert();
  const trajectory=frames.map(frame=>{
    const euler=frame.character.rotation;
    const rotation=frame.character.quaternion
      ? new THREE.Quaternion(...frame.character.quaternion)
      : new THREE.Quaternion().setFromEuler(new THREE.Euler(euler.x,euler.y,euler.z,'XYZ'));
    const delta=startRotationInverse.clone().multiply(rotation).normalize();
    const position={ x:frame.character.position.x-start.x,y:frame.character.position.y-start.y,z:frame.character.position.z-start.z };
    const scale=Math.max(1e-5,characterHeight||0);
    return { time:frame.time,position,normalizedPosition:{ x:position.x/scale,y:position.y/scale,z:position.z/scale },rotation:[delta.x,delta.y,delta.z,delta.w] };
  });
  const velocity=trajectory.map((sample,index)=>{
    if(index===0) return { time:sample.time,x:0,y:0,z:0,speed:0 };
    const before=trajectory[index-1],dt=Math.max(1e-5,sample.time-before.time);
    const x=(sample.position.x-before.position.x)/dt,y=(sample.position.y-before.position.y)/dt,z=(sample.position.z-before.position.z)/dt;
    return { time:sample.time,x,y,z,speed:Math.sqrt(x*x+y*y+z*z) };
  });
  const acceleration=velocity.map((sample,index)=>{
    if(index===0) return { time:sample.time,x:0,y:0,z:0,magnitude:0 };
    const before=velocity[index-1],dt=Math.max(1e-5,sample.time-before.time);
    const x=(sample.x-before.x)/dt,y=(sample.y-before.y)/dt,z=(sample.z-before.z)/dt;
    return { time:sample.time,x,y,z,magnitude:Math.sqrt(x*x+y*y+z*z) };
  });
  const displacement=trajectory[trajectory.length-1].position;
  const translationDetected=trajectory.some(sample=>motionLearningDistance(sample.position,{x:0,y:0,z:0})>1e-5);
  const rotationDetected=trajectory.some(sample=>Math.abs(sample.rotation[0])+Math.abs(sample.rotation[1])+Math.abs(sample.rotation[2])>1e-5);
  const detected=!!rootSource&&(translationDetected||rotationDetected);
  return { detected,sourceNode:rootSource&&rootSource.nodeName||null,space:rootSource&&rootSource.motionSpace||'scene-root',displacement,trajectory,velocity,acceleration };
}

function createMotionIR(options){
  const { frames, skeleton, clip, clipAnalysis, sourceHeight, retargetResult, sourceFile }=options;
  const analysis=window.motionAnalysisRuntime&&window.motionAnalysisRuntime.analyzeFrames
    ? window.motionAnalysisRuntime.analyzeFrames(clip.name,frames)
    : null;
  if(analysis) analysis.solverState=null;
  const boneNames=new Set(skeleton.bones.map(record=>record.originalName));
  const curves=[];
  for(const name of boneNames){
    const samples=frames.map(frame=>({ time:frame.time,bone:frame.bones.find(bone=>bone.originalName===name) })).filter(sample=>sample.bone).map((sample,index,list)=>{
      const previous=list[index-1],next=list[index+1];
      const dt=previous?Math.max(1e-5,sample.time-previous.time):0;
      const velocity=previous?{
        x:(sample.bone.worldPosition.x-previous.bone.worldPosition.x)/dt,
        y:(sample.bone.worldPosition.y-previous.bone.worldPosition.y)/dt,
        z:(sample.bone.worldPosition.z-previous.bone.worldPosition.z)/dt,
      }:{ x:0,y:0,z:0 };
      const priorVelocity=previous&&index>1?{
        x:(previous.bone.worldPosition.x-list[index-2].bone.worldPosition.x)/Math.max(1e-5,previous.time-list[index-2].time),
        y:(previous.bone.worldPosition.y-list[index-2].bone.worldPosition.y)/Math.max(1e-5,previous.time-list[index-2].time),
        z:(previous.bone.worldPosition.z-list[index-2].bone.worldPosition.z)/Math.max(1e-5,previous.time-list[index-2].time),
      }:{ x:0,y:0,z:0 };
      return {
        time:sample.time,
        localPosition:sample.bone.localPosition,
        localRotation:sample.bone.localRotation,
        worldPosition:sample.bone.worldPosition,
        worldRotation:sample.bone.worldRotation,
        normalizedWorldPosition:{ x:sample.bone.worldPosition.x/Math.max(sourceHeight,1e-5),y:sample.bone.worldPosition.y/Math.max(sourceHeight,1e-5),z:sample.bone.worldPosition.z/Math.max(sourceHeight,1e-5) },
        velocity,
        acceleration:previous&&index>1?{ x:(velocity.x-priorVelocity.x)/dt,y:(velocity.y-priorVelocity.y)/dt,z:(velocity.z-priorVelocity.z)/dt }:{ x:0,y:0,z:0 },
        nextTime:next&&next.time,
      };
    });
    if(samples.length) curves.push({ bone:name,semanticRole:(skeleton.byName.get(name)||[])[0]?.semanticRole||null,samples:motionLearningDecimate(samples,30) });
  }
  const controlCurves=motionLearningControlCurves(frames,skeleton,options.targetRegistry,retargetResult,clipAnalysis&&clipAnalysis.rootMotion);
  const rootMotion=motionLearningBuildRootMotion(frames,clipAnalysis&&clipAnalysis.rootMotion,sourceHeight);
  const maximumRootSpeed=Math.max(0,...rootMotion.velocity.map(sample=>sample.speed));
  const hasTranslationalMotion=rootMotion.velocity.some(sample=>sample.speed>0.15);
  rootMotion.trajectory=motionLearningDecimate(rootMotion.trajectory);
  rootMotion.velocity=motionLearningDecimate(rootMotion.velocity);
  rootMotion.acceleration=motionLearningDecimate(rootMotion.acceleration);
  const relationships=motionLearningBuildRelationships(frames,sourceHeight);
  const jointCurves=motionLearningBuildJointCurves(frames);
  const contacts=motionLearningBuildContactEvents(frames,sourceHeight);
  const phases=motionLearningBuildPhases(frames,sourceHeight);
  const invalidTransformFrames=frames.map((frame,index)=>({ frame,index })).filter(({frame})=>!Number.isFinite(frame.time)
    || ![frame.character.position.x,frame.character.position.y,frame.character.position.z].every(Number.isFinite)
    || !(frame.bones||[]).every(bone=>[...Object.values(bone.localPosition),...bone.localRotation,...Object.values(bone.worldPosition),...bone.worldRotation].every(Number.isFinite)))
    .map(({frame,index})=>({ frame:index+1,time:frame.time }));
  const invalidTimingFrames=frames.slice(1).map((frame,index)=>({ frame,index:index+2,previousTime:frames[index].time }))
    .filter(({frame,previousTime})=>frame.time<=previousTime).map(({frame,index,previousTime})=>({ frame:index,time:frame.time,previousTime }));
  const warnings=[];
  for(const relation of relationships){
    if(relation.distance.max>2.5) warnings.push({ code:'relationship-distance-outlier',from:relation.from,to:relation.to,normalizedDistance:relation.distance.max });
  }
  if(invalidTransformFrames.length) warnings.push({ code:'invalid-transform-values',count:invalidTransformFrames.length });
  if(invalidTimingFrames.length) warnings.push({ code:'non-monotonic-frame-timing',count:invalidTimingFrames.length });
  if(retargetResult&&retargetResult.skippedTracks.length) warnings.push({ code:'unmapped-animation-tracks',count:retargetResult.skippedTracks.length });
  const finiteValues=invalidTransformFrames.length===0;
  const features={
    frameCount:frames.length,
    boneCount:skeleton.bones.filter(record=>!record.isAuxiliaryClone).length,
    mappedBoneCount:retargetResult&&retargetResult.mapping?retargetResult.mapping.source.filter(record=>record.target).length:0,
    rootDisplacement:rootMotion.displacement,
    maximumRootSpeed,
    contactCount:contacts.length,
    jointRanges:jointCurves.map(curve=>({ name:curve.name,...curve.statistics })),
    activeControls:controlCurves.map(curve=>curve.key),
    phaseLabels:[...new Set(phases.map(phase=>phase.label))],
    descriptors:[
      ...(rootMotion.detected?['root-trajectory']:[]),
      ...(hasTranslationalMotion?['translational-motion']:[]),
      ...(phases.some(phase=>phase.label==='ascending'||phase.label==='descending')?['vertical-motion']:[]),
      ...(contacts.some(contact=>contact.type.endsWith('-ground'))?['ground-interaction']:[]),
      ...(contacts.some(contact=>contact.type.endsWith('-hand-knee'))?['hand-knee-contact']:[]),
    ],
  };
  const validation={
    valid:finiteValues&&frames.length>0,
    frameCount:frames.length,
    invalidTimingFrames,
    invalidTransformFrames,
    unmappedBones:skeleton.bones.filter(record=>!record.semanticRole).map(record=>record.originalName),
    skippedTracks:retargetResult?retargetResult.skippedTracks:[],
    rootMotionDetected:rootMotion.detected,
    warnings,
  };
  const pelvisRecord=skeleton.bones.find(record=>record.semanticRole==='Pelvis'&&!record.isAuxiliaryClone);
  const forward=pelvisRecord?new THREE.Vector3(0,0,1).applyQuaternion(pelvisRecord.restWorldRotation):new THREE.Vector3(0,0,1);
  forward.y=0;
  if(forward.lengthSq()<1e-8) forward.set(0,0,1);
  forward.normalize();
  const right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),forward).normalize();
  return {
    schemaVersion:1,
    metadata:{ id:options.id,name:clip.name,sourceFile,duration:clip.duration,createdAt:Date.now() },
    duration:clip.duration,
    timing:{ duration:clip.duration,sampleRate:frames.length>1?(frames.length-1)/Math.max(clip.duration,1e-5):0,frameCount:frames.length,sourceSampleRate:clipAnalysis&&clipAnalysis.sampleRate||null },
    sourceRig:skeleton.bones.filter(record=>!record.isAuxiliaryClone).map(record=>({ name:record.originalName,normalizedName:record.normalizedName,parent:record.parent,children:record.children,depth:record.hierarchyDepth,side:record.side,semanticRole:record.semanticRole,mappingStatus:record.mappingStatus,mappingConfidence:record.mappingConfidence,restLocal:{ position:record.restPosition.toArray(),rotation:record.restRotation.toArray(),scale:record.restScale.toArray() },restWorld:{ position:record.restWorldPosition.toArray(),rotation:record.restWorldRotation.toArray() },boneLength:record.boneLength,normalizedBoneLength:record.boneLength/Math.max(sourceHeight,1e-5) })),
    coordinateSystem:{ name:'Three.js scene space after FBXLoader conversion',upAxis:[0,1,0],forwardAxis:forward.toArray(),rightAxis:right.toArray(),handedness:'right-handed',sourceScale:sourceHeight },
    rootMotion,
    boneCurves:curves,
    controlCurves,
    jointCurves,
    relationships,
    contacts,
    phases,
    motionFeatures:features,
    analysis:motionLearningAnalysisSummary(analysis),
    validation,
  };
}