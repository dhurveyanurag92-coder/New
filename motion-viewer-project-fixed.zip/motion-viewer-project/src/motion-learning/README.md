# Motion Learning

Motion Learning is separate from Imported Motion playback. The importer samples each source Mixamo clip against its source skeleton, runs the existing Motion Analysis frame builder, and stores a compact Motion IR in the existing IndexedDB database. The original source clip remains available for playback/export and the source scene is disposed after import.

The IR keeps skeleton/rest metadata, sampled bone and X_Bot-adapted control curves, root trajectory/velocity/acceleration, joint-angle curves, body relationships, inferred contact intervals, motion phases, validation warnings, and aggregate features. Dense transient frame records are not persisted; source clip curves remain the exact raw record. Curves are bounded-sampled for dataset size.

`window.motionLearningRuntime` exposes `ready()`, `query(criteria)`, `find(idOrName)`, `get(id)`, `sample(idOrName,time,duration)`, `setPhaseOverrides(id,ranges)`, and `remove(id)`. Query criteria include text/descriptors, duration/root speed, phase, contact type, relationship endpoints, and joint range.

The existing Action DSL can reference learned controller/root curves with a `useMotion` step. The action runs through the current procedural pose loop, so existing IK, grounding, balance, joint limits, validation, and export paths remain in use. Imported raw clips continue to use the existing AnimationMixer path.

Example Action DSL definition:

```json
{
  "name": "LearnedMotionAction",
  "steps": [
    { "command": "useMotion", "motion": "Learned Motion Name" }
  ]
}
```