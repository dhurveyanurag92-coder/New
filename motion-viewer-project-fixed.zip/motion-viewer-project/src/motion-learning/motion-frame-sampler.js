function motionLearningVector(vector){
  return { x:vector.x, y:vector.y, z:vector.z };
}

function motionLearningQuaternion(quaternion){
  return [quaternion.x, quaternion.y, quaternion.z, quaternion.w];
}

function motionLearningEuler(quaternion, order){
  const euler = new THREE.Euler().setFromQuaternion(quaternion, order || 'XYZ');
  return motionLearningVector(euler);
}

function createMotionLearningSampleTimes(clip, maxSamples = 1800){
  const duration = Math.max(0, Number(clip && clip.duration) || 0);
  const timing = typeof getAnimationTimingInfo === 'function' ? getAnimationTimingInfo(clip) : null;
  const frameRate = Math.max(1, Math.min(60, Number(timing && timing.fps) || 30));
  const count = Math.max(1, Math.min(maxSamples, Math.ceil(duration * frameRate) + 1));
  const interval = count > 1 ? duration / (count - 1) : 0;
  const times = new Set();
  for(let index=0; index<count; index++) times.add(index === count - 1 ? duration : index * interval);
  const keyTimes = new Set();
  for(const track of clip.tracks || []){
    for(const time of track.times){
      if(Number.isFinite(time) && time >= 0 && time <= duration) keyTimes.add(time);
    }
  }
  if(keyTimes.size + times.size <= maxSamples){
    for(const time of keyTimes) times.add(time);
  }
  const ordered = [...times].sort((left, right)=>left - right);
  if(ordered.length <= maxSamples) return ordered;
  return Array.from({ length:maxSamples }, (_, index)=>ordered[Math.round(index * (ordered.length - 1) / (maxSamples - 1))]);
}

function localEulerDelta(current, previous){
  const delta = previous.clone().invert().multiply(current).normalize();
  return motionLearningEuler(delta, 'XYZ');
}

function createMotionLearningBoneFrame(record, previous){
  const bone = record.bone;
  const worldPosition = new THREE.Vector3();
  const worldRotation = new THREE.Quaternion();
  bone.getWorldPosition(worldPosition);
  bone.getWorldQuaternion(worldRotation);
  const localPosition = motionLearningVector(bone.position);
  const localRotation = motionLearningQuaternion(bone.quaternion);
  const worldPositionValue = motionLearningVector(worldPosition);
  const worldRotationValue = motionLearningQuaternion(worldRotation);
  const localEuler = motionLearningEuler(bone.quaternion, bone.rotation.order);
  const worldEuler = motionLearningEuler(worldRotation, 'XYZ');
  const deltaFromPrevious = previous ? {
    localPosition:motionLearningVector(bone.position.clone().sub(previous.localPositionVector)),
    localRotation:localEulerDelta(bone.quaternion, previous.localQuaternion),
    worldPosition:motionLearningVector(worldPosition.clone().sub(previous.worldPositionVector)),
    worldRotation:localEulerDelta(worldRotation, previous.worldQuaternion),
  } : {
    localPosition:{ x:0, y:0, z:0 },
    localRotation:{ x:0, y:0, z:0 },
    worldPosition:{ x:0, y:0, z:0 },
    worldRotation:{ x:0, y:0, z:0 },
  };
  return {
    frame:{
      originalName:record.originalName,
      normalizedName:record.normalizedName,
      semanticName:record.semanticRole || record.normalizedName,
      semanticRole:record.semanticRole,
      mappingStatus:record.mappingStatus,
      mappingConfidence:record.mappingConfidence,
      side:record.side,
      parent:record.parent,
      children:record.children,
      depth:record.hierarchyDepth,
      chain:record.chain,
      boneLength:record.boneLength,
      localPosition,
      localRotation,
      localEuler,
      worldPosition:worldPositionValue,
      worldRotation:worldRotationValue,
      worldEuler,
      deltaFromPrevious,
      movementFromStart:null,
    },
    previous:{
      localPositionVector:bone.position.clone(),
      localQuaternion:bone.quaternion.clone(),
      worldPositionVector:worldPosition,
      worldQuaternion:worldRotation,
    },
  };
}

async function sampleMotionLearningFrames(root, clip, skeleton, clipAnalysis){
  if(!root || !clip || !skeleton || !Array.isArray(clip.tracks)) throw new Error('Motion learning needs a source scene, clip, and skeleton.');
  const sampleTimes = createMotionLearningSampleTimes(clip);
  if(!sampleTimes.length) throw new Error('The source clip has no sampleable time range.');
  const saved = [];
  root.traverse(node=>saved.push({ node, position:node.position.clone(), quaternion:node.quaternion.clone(), scale:node.scale.clone() }));
  const bones = skeleton.bones.filter(record=>!record.isAuxiliaryClone);
  const mixer = new THREE.AnimationMixer(root);
  const action = mixer.clipAction(clip);
  action.setLoop(THREE.LoopOnce, 1);
  action.clampWhenFinished = true;
  action.play();
  const frames = [];
  const previousBones = new Map();
  let previousRootPosition = null;
  let previousRootRotation = null;
  const rootNode = clipAnalysis && clipAnalysis.rootMotion && clipAnalysis.rootMotion.node || root;
  const startRootPosition = new THREE.Vector3();
  rootNode.getWorldPosition(startRootPosition);
  try{
    for(let index=0; index<sampleTimes.length; index++){
      const time = sampleTimes[index];
      action.time = time;
      mixer.update(0);
      root.updateMatrixWorld(true);
      const characterPosition = new THREE.Vector3();
      const characterRotation = new THREE.Quaternion();
      rootNode.getWorldPosition(characterPosition);
      rootNode.getWorldQuaternion(characterRotation);
      const position = motionLearningVector(characterPosition);
      const rotation = motionLearningEuler(characterRotation, 'XYZ');
      const deltaFromPrevious = previousRootPosition ? {
        position:motionLearningVector(characterPosition.clone().sub(previousRootPosition)),
        rotation:localEulerDelta(characterRotation, previousRootRotation),
      } : {
        position:{ x:0, y:0, z:0 },
        rotation:{ x:0, y:0, z:0 },
      };
      const boneRecords = [];
      for(const record of bones){
        const captured = createMotionLearningBoneFrame(record, previousBones.get(record.bone));
        previousBones.set(record.bone, captured.previous);
        captured.frame.movementFromStart = {
          localPosition:motionLearningVector(record.bone.position.clone().sub(record.restPosition)),
          worldPosition:motionLearningVector(captured.previous.worldPositionVector.clone().sub(record.restWorldPosition)),
          localRotation:motionLearningEuler(record.restRotation.clone().invert().multiply(record.bone.quaternion), 'XYZ'),
          worldRotation:motionLearningEuler(record.restWorldRotation.clone().invert().multiply(captured.previous.worldQuaternion), 'XYZ'),
        };
        boneRecords.push(captured.frame);
      }
      const character = {
        position,
        rotation,
        quaternion:motionLearningQuaternion(characterRotation),
        movementFromStart:motionLearningVector(characterPosition.clone().sub(startRootPosition)),
        deltaFromPrevious,
      };
      frames.push({
        number:index + 1,
        time,
        fps:clip.duration > 0 && sampleTimes.length > 1 ? (sampleTimes.length - 1) / clip.duration : 0,
        animationName:clip.name || 'Imported Motion',
        character,
        summary:{ ...character, facing:rotation.y },
        bones:boneRecords,
      });
      previousRootPosition = characterPosition.clone();
      previousRootRotation = characterRotation.clone();
      if((index + 1) % 60 === 0) await new Promise(resolve=>setTimeout(resolve, 0));
    }
  }finally{
    action.stop();
    mixer.uncacheRoot(root);
    for(const state of saved){
      state.node.position.copy(state.position);
      state.node.quaternion.copy(state.quaternion);
      state.node.scale.copy(state.scale);
    }
    root.updateMatrixWorld(true);
  }
  return frames;
}