# Source Architecture

Each feature owns its markup, styles, behavior, and focused state/calculation modules. `index.template.html` is the small assembly shell; `build.py` reads the ordered source manifest and writes a standalone `dist/index.html` with X_Bot embedded.

## Ownership

- `app/`: bootstrap sequence and Home page registration.
- `assets/characters/`: source character files used by the build.
- `core/`: shared styles and frame/motion sampling contracts used by Frame Code, Motion Analysis, and GLB export.
- `menu/`: header, drawer, navigation rendering/events, and `nav.registerPage`.
- `viewer/`, `character/`, `import/`: scene/camera, camera direction presets, skeleton registry/semantic mapping, rig setup, and character file validation/reading/orchestration.
- `motion/`: built-in motion folders, playback, custom actions, and pose editing. Add a built-in motion under `motion/motions/<name>/motion.js`; the build discovers it automatically.
- `imported-motions/`: Mixamo FBX hierarchy/clip analysis, semantic X_Bot retargeting, source disposal, batch intake, duplicate detection, and original-clip playback registration.
- `motion-learning/`: sampled source skeleton frames, compact Motion IR, reusable motion features, relationship/contact/phase extraction, IndexedDB knowledge indexing, structured queries, and Action DSL sampling. Raw source clips remain separate from learned records.
- `motion-engine/`: reusable procedural constraints and future solver modules.
- `keyframe/`: keyframe pose editor, strict versioned frame-code parsing, model-aware AI prompt copying, project persistence, and named motion saving.
- `frame-gallery/`: saved Keyframe motion library with its own preview and playback controls.
- `frame-code/`, `motion-analysis/`, `export/glb/`: independent user-facing feature pages. Analysis quaternion, frame/range, movement-cycle, rendering, and export code has separate owners.

## Build and Connections

Run `python build.py [Character.fbx]`. `FEATURES` in `build.py` is the central source manifest for feature styles, markup, and runtime modules; `RUNTIME_ORDER`, `STYLE_ORDER`, and `MARKUP_ORDER` preserve dependency and cascade order. The template has only shared CSS, markup, and script slots. Each page registers through `nav.registerPage({ id, label, order, mount, canOpen, onShow })`.

Feature communication uses `nav.registerPage` for navigation, `window.appUI` for app notifications, `window.motionRuntime` for motion/pose access, `window.characterRuntime` for character identity, `window.keyframeRuntime` for keyframe projects and saved motions, `window.frameGalleryRuntime` for the gallery, `window.motionDataApi` for canonical frame data, `window.motionAnalysisRuntime` for shared frame analysis, and `window.motionLearningRuntime` for learned knowledge/query/action sampling. Keyframe projects and named gallery motions are stored in browser local storage; original source clips, retargeted playback clips, and compact Motion IR are separate IndexedDB records, and source meshes are never stored. The standalone build currently assembles classic scripts in dependency order rather than loading browser ES modules.

For AI-assisted keyframe edits, the Keyframe editor's **Copy AI Prompt** action copies a guide containing the current character's skeleton profile and selected frame code. **Download AI Guide** saves the same content as a TXT file for upload to an AI. Returned code can be checked with **Validate Code** before applying. Frame code is a versioned pose format, not JavaScript; bone names must resolve to the loaded character's real skeleton.
