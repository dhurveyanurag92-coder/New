const SEMANTIC_BONE_ALIASES = {
  Root: ['root', 'skeletonroot'],
  Pelvis: ['hips', 'hip', 'pelvis'],
  Spine: ['spine'],
  Chest: ['spine1', 'spine2', 'chest', 'thorax'],
  Neck: ['neck'],
  Head: ['head'],
  Shoulder: ['shoulder', 'clavicle'],
  UpperArm: ['arm', 'upperarm', 'uparm'],
  Elbow: ['elbow'],
  ForeArm: ['forearm', 'lowerarm'],
  Hand: ['hand', 'wrist'],
  Thigh: ['upleg', 'thigh', 'upperleg'],
  Knee: ['knee'],
  Shin: ['leg', 'calf', 'shin', 'lowerleg'],
  Ankle: ['ankle'],
  Foot: ['foot'],
  Toes: ['toebase', 'toe', 'toes'],
  Finger: ['thumb', 'index', 'middle', 'ring', 'pinky', 'little', 'finger'],
};

function mapSemanticBoneName(name){
  const normalizedName = normName(name);
  let side = 'Center';
  let localName = normalizedName;
  if(localName.startsWith('left')){ side = 'Left'; localName = localName.slice(4); }
  else if(localName.startsWith('right')){ side = 'Right'; localName = localName.slice(5); }
  else if(localName.endsWith('left')){ side = 'Left'; localName = localName.slice(0, -4); }
  else if(localName.endsWith('right')){ side = 'Right'; localName = localName.slice(0, -5); }
  else if(localName.endsWith('l') && Object.values(SEMANTIC_BONE_ALIASES).flat().includes(localName.slice(0, -1))){ side = 'Left'; localName = localName.slice(0, -1); }
  else if(localName.endsWith('r') && Object.values(SEMANTIC_BONE_ALIASES).flat().includes(localName.slice(0, -1))){ side = 'Right'; localName = localName.slice(0, -1); }

  for(const [semanticRole, aliases] of Object.entries(SEMANTIC_BONE_ALIASES)){
    if(aliases.includes(localName)){
      return { normalizedName, semanticRole, side, mappingStatus: 'mapped', mappingConfidence: 1 };
    }
  }
  if(/^spine\d+$/.test(localName)){
    return { normalizedName, semanticRole: 'Chest', side, mappingStatus: 'inferred', mappingConfidence: 0.8 };
  }
  if(/^(hand)?(thumb|index|middle|ring|pinky|little|finger)/.test(localName)){
    return { normalizedName, semanticRole: 'Finger', side, mappingStatus: 'inferred', mappingConfidence: 0.8 };
  }
  return { normalizedName, semanticRole: null, side, mappingStatus: 'unmapped', mappingConfidence: 0 };
}