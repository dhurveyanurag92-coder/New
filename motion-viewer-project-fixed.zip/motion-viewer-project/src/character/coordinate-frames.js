const COORDINATE_FRAME_ROLES = new Set([
  'Pelvis', 'Spine', 'Chest', 'Neck', 'Head', 'Shoulder', 'UpperArm', 'Elbow',
  'ForeArm', 'Hand', 'Thigh', 'Knee', 'Shin', 'Ankle', 'Foot', 'Toes', 'Finger',
]);

function buildCharacterCoordinateFrames(registry){
  if(!registry) return new Map();
  const pelvis = registry.find('Pelvis');
  const pelvisPosition = pelvis ? pelvis.restWorldPosition.clone() : new THREE.Vector3();
  const up = new THREE.Vector3(0, 1, 0);
  const orientation = pelvis ? pelvis.restWorldRotation.clone() : new THREE.Quaternion();
  let forward = new THREE.Vector3(0, 0, 1).applyQuaternion(orientation);
  forward.addScaledVector(up, -forward.dot(up));
  if(forward.lengthSq() < 1e-8) forward.set(0, 0, 1);
  forward.normalize();
  const backward = forward.clone().negate();
  const worldFrames = new Map();
  for(const record of registry.bones){
    if(!record.semanticRole || !COORDINATE_FRAME_ROLES.has(record.semanticRole)) continue;
    const outward = record.restWorldPosition.clone().sub(pelvisPosition);
    outward.addScaledVector(up, -outward.dot(up));
    if(outward.lengthSq() < 1e-8){
      outward.set(record.side === 'Left' ? 1 : record.side === 'Right' ? -1 : 1, 0, 0).applyQuaternion(orientation);
    }
    outward.normalize();
    const inside = outward.clone().negate();
    const world = {
      up: up.clone(),
      down: up.clone().negate(),
      forward: forward.clone(),
      backward: backward.clone(),
      inside,
      outside: outward,
    };
    const inverse = record.restWorldRotation.clone().invert();
    const local = Object.fromEntries(Object.entries(world).map(([direction, axis])=>[
      direction,
      axis.clone().applyQuaternion(inverse).normalize(),
    ]));
    worldFrames.set(record.bone, {
      bone: record.bone,
      originalName: record.originalName,
      semanticRole: record.semanticRole,
      side: record.side,
      origin: record.restWorldPosition.clone(),
      rotation: record.restWorldRotation.clone(),
      world,
      local,
    });
  }
  return worldFrames;
}