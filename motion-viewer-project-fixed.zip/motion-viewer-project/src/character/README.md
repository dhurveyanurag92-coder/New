# Character

Owns character state, Mixamo skeleton naming, rig setup, model sizing, and pose control.

- `character-loader.js`: model lifecycle, sizing, imported animation clips.
- `skeleton-map.js`: normalized Mixamo bone names and required-bone contract.
- `semantic-mapper.js`: semantic roles, side, mapping status, and confidence for common humanoid naming patterns.
- `skeleton-registry.js`: all bone records, including unmapped extras and duplicate helpers, plus rest/current hierarchy metadata.
- `character-measurements.js`: body height, limb lengths, widths, and height-normalized ratios exposed through `characterRuntime.getMeasurements()`.
- `coordinate-frames.js`: per-joint local/world up, down, forward, back, inside, and outside axes from the captured rest pose.
- `rig-setup.js`: rest transforms, foot contacts, and arm lengths.
- `character-state.js`: current model, rig, and imported clip state.

Character import orchestration belongs to `../import/`. Rig setup uses `../motion-engine/retarget/` to map semantic roles to the procedural controller. Motion playback consumes the rig contract from `pose-controller.js`.