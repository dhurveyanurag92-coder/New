function buildRig(){
  rigMapping = retargetSkeletonToControlRig(skeletonRegistry, BONE_KEYS);
  const map = rigMapping.bones;
  const missing = REQUIRED.filter(k=>!map[k]);
  if(missing.length){
    rig = null;
    toast('Could not map required humanoid bones. Missing: ' + missing.slice(0,4).join(', ') + (missing.length>4?'…':''), 7000);
    return;
  }
  model.updateMatrixWorld(true);
  const rest = {};
  for(const k in map){
    const bone = map[k], pq = new THREE.Quaternion();
    if(bone.parent) bone.parent.getWorldQuaternion(pq);
    rest[k] = { bone, Lr:bone.quaternion.clone(), Pr:pq, PrInv:pq.clone().invert() };
  }
  const p = new THREE.Vector3();
  map.LeftFoot.getWorldPosition(p); const ay = p.y;
  let ankleH = 0;
  if(map.LeftToeBase){ map.LeftToeBase.getWorldPosition(p); ankleH = Math.max(0, ay - p.y); }
  rig = { rest, ankleH, restMin:0,
    contacts:[
      {bone:map.LeftFoot,off:ankleH},
      ...(map.LeftToeBase ? [{bone:map.LeftToeBase,off:0}] : []),
      {bone:map.RightFoot,off:ankleH},
      ...(map.RightToeBase ? [{bone:map.RightToeBase,off:0}] : []),
    ] };
  rig.restMin = lowestPoint();

  const boneDist = (a,b)=>{ if(!map[a] || !map[b]) return 0; const pa=new THREE.Vector3(), pb=new THREE.Vector3(); map[a].getWorldPosition(pa); map[b].getWorldPosition(pb); return pa.distanceTo(pb); };
  rig.armLengths = { Left:{}, Right:{} };
  for(const side of ['Left','Right']){
    const upper = boneDist(side+'Arm', side+'ForeArm');
    const fore  = map[side+'Hand'] ? boneDist(side+'ForeArm', side+'Hand') : upper;
    rig.armLengths[side] = { upper, fore, total: upper + fore };
  }
  rig.legLengths = { Left:{}, Right:{} };
  for(const side of ['Left','Right']){
    const upper = boneDist(side+'UpLeg', side+'Leg');
    const fore = boneDist(side+'Leg', side+'Foot');
    rig.legLengths[side] = { upper, fore, total: upper + fore };
  }
}

function lowestPoint(){
  let m = Infinity;
  for(const c of rig.contacts){ c.bone.getWorldPosition(_v); m = Math.min(m, _v.y - c.off); }
  return m;
}