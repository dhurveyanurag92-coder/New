/* ---- model loading and sizing */
function disposeTree(o){
  o.traverse(n=>{
    if(n.geometry) n.geometry.dispose();
    if(n.material){ (Array.isArray(n.material)?n.material:[n.material]).forEach(m=>{ for(const k in m){ if(m[k] && m[k].isTexture) m[k].dispose(); } m.dispose(); }); }
  });
}
function setModel(obj, label, baseName){
  clearImported();                                     // clips belong to the previous model
  if(model){ holder.remove(model); disposeTree(model); }
  model = obj; rig = null; rigMapping = null; skeletonRegistry = null; characterMeasurements = null; coordinateFrames = null;
  holder.position.set(0,0,0); holder.add(model);
  model.traverse(o=>{ if(o.isMesh){ o.frustumCulled = false; o.castShadow = true; } });
  holder.updateMatrixWorld(true);
  let box = new THREE.Box3().setFromObject(model);
  const h = box.max.y - box.min.y;
  if(!(h > 0)) throw new Error('The file has no visible mesh.');
  model.scale.multiplyScalar(1.8/h);                   // every character is shown about 1.8 m tall
  holder.updateMatrixWorld(true);
  box.setFromObject(model);
  model.position.x -= (box.min.x + box.max.x)/2;
  model.position.z -= (box.min.z + box.max.z)/2;
  model.position.y -= box.min.y;                       // feet on the floor, centred on the ring
  holder.updateMatrixWorld(true);
  el.fname.innerHTML = '';
  const b = document.createElement('b'); b.textContent = label; el.fname.appendChild(b);
  snapshotBind();
  skeletonRegistry = buildSkeletonRegistry(model);
  characterMeasurements = measureCharacter(model, skeletonRegistry, h);
  coordinateFrames = buildCharacterCoordinateFrames(skeletonRegistry);
  buildRig();
  const found = registerImported(obj.animations, baseName || label);
  buildChips(); syncUI();
  evalPose(t, 0);
  window.dispatchEvent(new Event('character:loaded'));
  return found;
}

/* ---- imported (embedded) animations: the file's own AnimationClips, played by THREE.AnimationMixer.
   Kept separate from the procedural actions above; they are never converted to action code. */
const MIN_CLIP = 0.1;                                  // shorter clips are a single static pose, not an animation
const GENERIC_CLIP = /^(mixamo\.com|take[ _]?0*\d+|default[ _]?take|default|animation[ _]?\d*|anim[ _]?\d*|clip[ _]?\d*|untitled|unnamed)$/i;
function cleanClipName(raw){
  let n = String(raw == null ? '' : raw).trim();
  if(n.indexOf('|') >= 0) n = n.split('|').map(x=>x.trim()).filter(x=>x && !/^(armature|layer\d*|mixamo\.com)$/i.test(x)).pop() || '';
  return (!n || GENERIC_CLIP.test(n)) ? '' : n;
}
function uniqueName(n){ let u = n, i = 2; while(actions.has(u)) u = n + ' (' + (i++) + ')'; return u; }
const importedRootTrackValues = new WeakMap();
let importedRootMotionMixer = null;
function resetImportedRootMotion(clip){
  if(!clip || !clip.tracks) return;
  for(const track of clip.tracks){
    if(track.name !== '.position' && track.name !== '.quaternion') continue;
    const original = importedRootTrackValues.get(track);
    if(original) track.values.set(original);
  }
}
function accumulateImportedRootMotion(event){
  if(!current || !current.imported || event.action !== activeAct) return;
  const rootMotion = current.metadata && current.metadata.rootMotion;
  if(!rootMotion) return;
  const loopDelta = Number(event.loopDelta) || 0;
  for(const track of event.action.getClip().tracks){
    if(track.name !== '.position' && track.name !== '.quaternion') continue;
    if(!importedRootTrackValues.has(track)) importedRootTrackValues.set(track, new Float32Array(track.values));
    if(track.name === '.position' && rootMotion.cycleDelta){
      for(let index=0; index<track.values.length; index+=3){
        track.values[index] += rootMotion.cycleDelta[0] * loopDelta;
        track.values[index + 1] += rootMotion.cycleDelta[1] * loopDelta;
        track.values[index + 2] += rootMotion.cycleDelta[2] * loopDelta;
      }
    }else if(track.name === '.quaternion' && rootMotion.cycleRotation){
      const shift = new THREE.Quaternion();
      const cycle = new THREE.Quaternion(...rootMotion.cycleRotation);
      const count = Math.abs(loopDelta);
      if(loopDelta < 0) cycle.invert();
      for(let index=0; index<count; index++) shift.multiply(cycle);
      const rotation = new THREE.Quaternion();
      for(let index=0; index<track.values.length; index+=4){
        rotation.set(track.values[index], track.values[index + 1], track.values[index + 2], track.values[index + 3]);
        rotation.premultiply(shift).normalize();
        track.values.set([rotation.x, rotation.y, rotation.z, rotation.w], index);
      }
    }
  }
}
function restoreImportedRootMotion(action){
  if(action && action.metadata && action.metadata.rootMotion) resetImportedRootMotion(action.clip);
}
function snapshotBind(){ bind = []; model.traverse(o=>bind.push({ o, p:o.position.clone(), q:o.quaternion.clone(), s:o.scale.clone() })); }
function restoreBind(){
  if(!model) return;
  for(const b of bind){ b.o.position.copy(b.p); b.o.quaternion.copy(b.q); b.o.scale.copy(b.s); }
  model.updateMatrixWorld(true);
}
function registerImported(clips, baseName){
  const list = (clips || []).filter(c=>{ if(!c || !c.tracks || !c.tracks.length) return false; c.resetDuration(); return c.duration >= MIN_CLIP; });
  const found = [];
  list.forEach((clip, i)=>{
    const raw = cleanClipName(clip.name);
    const name = uniqueName(raw || (list.length > 1 ? baseName + ' ' + (i+1) : baseName));   // name comes from the file
    actions.set(name, { name, category:'Imported', builtin:true, imported:true, clip, aliases:[], update(){} });
    found.push(name);
  });
  if(found.length) mixer = new THREE.AnimationMixer(model);
  return found;
}
function registerImportedAnimationClip(clip, metadata){
  if(!model || !clip || !Array.isArray(clip.tracks) || !clip.tracks.length) throw new Error('A retargeted animation clip is required.');
  const name = uniqueName(String(metadata.name || clip.name || 'Imported Motion').trim());
  clip.name = name;
  const action = {
    name,
    category:'Imported',
    builtin:false,
    imported:true,
    clip,
    duration:clip.duration,
    metadata:{
      importedMotionId:metadata.id,
      sourceFile:metadata.sourceFile,
      clipName:metadata.clipName,
      mappingStatus:metadata.mappingStatus,
      rootMotion:metadata.rootMotion || null,
    },
    aliases:[],
    update(){},
  };
  actions.set(name, action);
  if(!mixer) mixer = new THREE.AnimationMixer(model);
  buildChips(); syncUI();
  return action;
}
function removeImportedAnimationClip(id){
  const action = [...actions.values()].find(item=>item.metadata && item.metadata.importedMotionId === id);
  if(!action) return false;
  if(current === action) selectAction('T-pose');
  actions.delete(action.name);
  buildChips(); syncUI();
  return true;
}
function clearImported(){
  if(mixer){ mixer.stopAllAction(); if(model) mixer.uncacheRoot(model); }
  mixer = null; activeAct = null; bind = [];
  for(const [name, action] of [...actions]) if(action.imported) actions.delete(name);
  if(current && current.imported){ current = actions.get('T-pose'); playing = false; t = 0; }
}
function startImported(action){
  stopImported(); restoreBind(); holder.position.y = 0;
  if(!mixer) return;
  restoreImportedRootMotion(action);
  if(importedRootMotionMixer !== mixer){
    mixer.addEventListener('loop', accumulateImportedRootMotion);
    importedRootMotionMixer = mixer;
  }
  const active = mixer.clipAction(action.clip);
  active.reset();
  if(window.motionRuntime.getLooping()) active.setLoop(THREE.LoopRepeat, Infinity);
  else { active.setLoop(THREE.LoopOnce, 1); active.clampWhenFinished = true; }
  active.play(); activeAct = active;
  mixer.update(0);
}
function stopImported(){
  if(!activeAct) return;
  const previous = [...actions.values()].find(action=>action.clip === activeAct.getClip());
  restoreImportedRootMotion(previous);
  activeAct.stop(); activeAct = null;
  restoreBind(); holder.position.y = 0;
}

window.characterRuntime = {
  getLabel: () => el.fname.textContent || 'Character',
  getModel: () => model,
  getRig: () => rig,
  getRigMapping: () => rigMapping,
  getSkeletonRegistry: () => skeletonRegistry,
  getMeasurements: () => characterMeasurements,
  getCoordinateFrames: () => coordinateFrames,
  loadModel: setModel,
  registerImportedAnimationClip,
  removeImportedAnimationClip,
  resetImportedRootMotion:restoreImportedRootMotion,
  normalizeBoneName: normName,
};

