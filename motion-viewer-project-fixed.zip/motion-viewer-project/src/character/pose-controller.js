/* ------------------------------------------------------------------ pose controller (what actions talk to) */
const sideName = s => (String(s)[0]||'L').toUpperCase() === 'L' ? 'Left' : 'Right';
const ctrl = {
  _d:{}, lift:0, _rootMotion:null,
  rootMotion(value){ this._rootMotion=value||null; },
  set(name,x,y,z){ this._d[name] = [+x||0, +y||0, +z||0]; },
  arm(side, swing, relax, elbow){
    const n = sideName(side), s = n==='Left' ? 1 : -1;
    this.set(n+'Arm', -swing, 0, -s*relax);
    this.set(n+'ForeArm', 0, -s*elbow, 0);
  },
  leg(side, thigh, knee, foot){
    const n = sideName(side);
    this.set(n+'UpLeg', -thigh, 0, 0);
    this.set(n+'Leg', knee, 0, 0);
    this.set(n+'Foot', thigh - knee + (foot||0), 0, 0);
  },
  torso(lean, twist){ const l = lean/3, y = twist/3; this.set('Spine',l,y,0); this.set('Spine1',l,y,0); this.set('Spine2',l,y,0); },
  head(pitch, yaw){ this.set('Neck', pitch*0.4, yaw*0.4, 0); this.set('Head', pitch*0.6, yaw*0.6, 0); },
  // Part A2 (Arm IK foundation): world-space position of any rig bone, correct for THIS frame even
  // mid-update (e.g. after c.torso() but before c.arm()). applyPose() only touches bone quaternions
  // using whatever ctrl._d is set so far, so calling it here is safe/idempotent and gives an accurate
  // read without waiting for the frame's official applyPose() at the end of evalPose().
  getBoneWorldOrLocal(name){
    if(!rig || !rig.rest[name]) return null;
    applyPose();
    holder.updateMatrixWorld(true);
    const b = rig.rest[name].bone, v = new THREE.Vector3();
    b.getWorldPosition(v);
    return { x:v.x, y:v.y, z:v.z };
  }
};

