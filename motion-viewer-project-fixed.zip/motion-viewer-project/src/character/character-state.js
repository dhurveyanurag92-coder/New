let model = null, rig = null;
let mixer = null, activeAct = null, bind = [];
let skeletonRegistry = null;
let characterMeasurements = null;
let coordinateFrames = null;
let rigMapping = null;