function isSharedBoneClone(bone){
  const parent = bone.parent;
  if(!parent || !parent.isBone || parent.name !== bone.name) return false;
  const epsilon = 1e-6;
  return bone.position.lengthSq() < epsilon * epsilon
    && Math.abs(Math.abs(bone.quaternion.w) - 1) < epsilon
    && Math.abs(bone.scale.x - 1) < epsilon
    && Math.abs(bone.scale.y - 1) < epsilon
    && Math.abs(bone.scale.z - 1) < epsilon;
}
  function motionDataIsSharedBoneClone(bone){ return isSharedBoneClone(bone); }
  function getSkeletonChain(name){
    const normalized = String(name || '').toLowerCase();
    if(normalized.includes('hip') || normalized.includes('pelvis')) return 'Hips';
    if(normalized.includes('spine') || normalized.includes('chest')) return 'Spine';
    if(normalized.includes('neck') || normalized.includes('head')) return 'Head';
    if(normalized.includes('shoulder') || normalized.includes('arm') || normalized.includes('forearm') || normalized.includes('hand')) return 'Arm';
    if(normalized.includes('leg') || normalized.includes('thigh') || normalized.includes('shin') || normalized.includes('foot') || normalized.includes('toe')) return 'Leg';
    return 'Other';
  }

function buildSkeletonRegistry(root){
  if(!root) return { bones: [], byObject: new Map(), byName: new Map(), find: () => null };
  root.updateMatrixWorld(true);
  const bones = [];
  root.traverse(object=>{ if(object.isBone) bones.push(object); });
  const boneSet = new Set(bones);
  const worldPosition = new Map();
  for(const bone of bones){
    const position = new THREE.Vector3();
    bone.getWorldPosition(position);
    worldPosition.set(bone, position);
  }

  const records = bones.map(bone=>{
    let parentBone = bone.parent;
    while(parentBone && !boneSet.has(parentBone)) parentBone = parentBone.parent;
    const parent = parentBone || null;
    const children = bones.filter(candidate=>{
      let candidateParent = candidate.parent;
      while(candidateParent && !boneSet.has(candidateParent)) candidateParent = candidateParent.parent;
      return candidateParent === bone;
    });
    const semantic = mapSemanticBoneName(bone.name);
    const worldRotation = new THREE.Quaternion();
    bone.getWorldQuaternion(worldRotation);
    const position = worldPosition.get(bone);
    let hierarchyDepth = 0;
    for(let ancestor = parent; ancestor; ancestor = ancestor.parent){
      if(boneSet.has(ancestor)) hierarchyDepth++;
    }
    return {
      bone,
      originalName: bone.name,
      ...semantic,
      semanticRole: semantic.semanticRole,
      mappingStatus: semantic.mappingStatus,
      mappingConfidence: semantic.mappingConfidence,
      isAuxiliaryClone: isSharedBoneClone(bone),
      parent: parent ? parent.name : 'Root',
      children: children.map(child=>child.name),
      hierarchyDepth,
        chain: getSkeletonChain(bone.name),
      localPosition: bone.position.clone(),
      worldPosition: position.clone(),
      localRotation: bone.quaternion.clone(),
      worldRotation: worldRotation.clone(),
      localScale: bone.scale.clone(),
      restPosition: bone.position.clone(),
      restRotation: bone.quaternion.clone(),
      restScale: bone.scale.clone(),
      restWorldPosition: position.clone(),
      restWorldRotation: worldRotation.clone(),
      boneLength: parent ? position.distanceTo(worldPosition.get(parent)) : position.length(),
    };
  });
  const byObject = new Map(records.map(record=>[record.bone, record]));
  const byName = new Map();
  const byRole = new Map();
  for(const record of records){
    if(!byName.has(record.originalName)) byName.set(record.originalName, []);
    byName.get(record.originalName).push(record);
    if(record.semanticRole){
      if(!byRole.has(record.semanticRole)) byRole.set(record.semanticRole, []);
      byRole.get(record.semanticRole).push(record);
    }
  }
  return {
    bones: records,
    byObject,
    byName,
    byRole,
    findAll(semanticRole, side){
      const matches = byRole.get(semanticRole) || [];
      return side ? matches.filter(record=>record.side === side) : matches.slice();
    },
    find(semanticRole, side = 'Center'){
      return (byRole.get(semanticRole) || []).find(record=>record.side === side) || null;
    },
  };
}