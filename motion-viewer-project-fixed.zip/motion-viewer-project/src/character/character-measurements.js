function measureCharacter(root, registry, sourceHeight){
  if(!root || !registry) return null;
  root.updateMatrixWorld(true);
  const bounds = new THREE.Box3().setFromObject(root);
  const height = Math.max(0, bounds.max.y - bounds.min.y);
  const byRole = (role, side = 'Center') => registry.find(role, side);
  const worldPoint = record => record ? record.bone.getWorldPosition(new THREE.Vector3()) : null;
  const distance = (a, b) => {
    const first = worldPoint(a), second = worldPoint(b);
    return first && second ? first.distanceTo(second) : null;
  };
  const average = values => {
    const valid = values.filter(Number.isFinite);
    return valid.length ? valid.reduce((sum, value)=>sum + value, 0) / valid.length : null;
  };
  const segmentLength = (startRole, endRole) => average(['Left', 'Right'].map(side=>distance(byRole(startRole, side), byRole(endRole, side))));
  const pelvis = byRole('Pelvis');
  const pelvisPoint = worldPoint(pelvis);
  const leftShoulder = byRole('Shoulder', 'Left') || byRole('UpperArm', 'Left');
  const rightShoulder = byRole('Shoulder', 'Right') || byRole('UpperArm', 'Right');
  const leftThigh = byRole('Thigh', 'Left');
  const rightThigh = byRole('Thigh', 'Right');
  const leftFoot = byRole('Foot', 'Left');
  const rightFoot = byRole('Foot', 'Right');
  const leftToes = byRole('Toes', 'Left');
  const rightToes = byRole('Toes', 'Right');
  const handLength = side => {
    const hand = byRole('Hand', side);
    if(!hand) return null;
    const descendants = registry.bones.filter(record=>{
      if(record.side !== side || record.semanticRole !== 'Finger') return false;
      for(let parent = record.bone.parent; parent; parent = parent.parent){
        if(parent === hand.bone) return true;
      }
      return false;
    });
    const handPoint = worldPoint(hand);
    if(!descendants.length) return null;
    return descendants.reduce((max, record)=>Math.max(max, handPoint.distanceTo(worldPoint(record))), 0);
  };
  const dimensions = {
    height,
    pelvisHeight: pelvisPoint ? pelvisPoint.y - bounds.min.y : null,
    shoulderWidth: distance(leftShoulder, rightShoulder),
    hipWidth: distance(leftThigh, rightThigh),
    spineLength: registry.bones.filter(record=>record.side === 'Center' && (record.semanticRole === 'Spine' || record.semanticRole === 'Chest'))
      .reduce((sum, record)=>sum + record.boneLength, 0),
    neckLength: byRole('Neck') ? byRole('Neck').boneLength : null,
    upperArmLength: segmentLength('UpperArm', 'ForeArm'),
    forearmLength: segmentLength('ForeArm', 'Hand'),
    thighLength: segmentLength('Thigh', 'Shin'),
    shinLength: segmentLength('Shin', 'Foot'),
    footLength: average([distance(leftFoot, leftToes), distance(rightFoot, rightToes)]),
    footWidth: null,
    handLength: average([handLength('Left'), handLength('Right')]),
  };
  const normalized = {};
  for(const [key, value] of Object.entries(dimensions)) normalized[key] = Number.isFinite(value) && height > 0 ? value / height : null;
  return { sourceHeight, dimensions, normalized };
}