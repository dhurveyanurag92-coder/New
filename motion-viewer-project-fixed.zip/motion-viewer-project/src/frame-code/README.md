# Frame Code

Owns frame selection, code rendering, frame generation requests, and ZIP download.

- `frame-code.js`: page registration and selection workflow.
- `frame-code-state.js`: page and generated-frame state.
- `frame-renderer.js`: selected frame presentation.
- `frame-export.js`: ZIP creation and shared frame-data formatting.

Frame snapshots use `window.motionDataApi`; the page is registered with the menu through `nav.registerPage`.

This page's human-readable frame report/ZIP export is separate from the versioned pose code accepted by the Keyframe editor. For AI-generated poses, use Keyframe's **Copy AI Prompt** action so the AI receives the actual model skeleton and reference pose.