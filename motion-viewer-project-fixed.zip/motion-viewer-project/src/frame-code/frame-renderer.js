/* Frame Code - small UI building blocks (chips, code box, copy). Inlined into the app scope by build.py. */
function fcChip(label, pressed, onClick){
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'chip'; b.textContent = label; b.setAttribute('aria-pressed', String(pressed));
  b.addEventListener('click', onClick);
  return b;
}
async function fcCopy(text, btn){
  try { await navigator.clipboard.writeText(text); }
  catch(e) {
    const tx = document.createElement('textarea');
    tx.value = text; document.body.appendChild(tx); tx.select(); document.execCommand('copy'); tx.remove();
  }
  btn.textContent = 'Copied';
  setTimeout(()=>{ btn.textContent = '[ Copy ]'; }, 1100);
}
function fcCodeBox(frame){
  const wrap = document.createDocumentFragment();
  const label = document.createElement('h3'); label.className = 'fcCodeLabel'; label.textContent = 'Complete Frame Code';
  const box = document.createElement('div'); box.className = 'fcCodeBox';
  const head = document.createElement('div'); head.className = 'fcCodeHead';
  const title = document.createElement('div'); title.className = 'fcCodeTitle'; title.textContent = 'Frame ' + frame.number;
  const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'fcCopy'; copy.textContent = '[ Copy ]';
  copy.addEventListener('click', ()=>fcCopy(frame.code, copy));
  head.append(title, copy);
  const pre = document.createElement('pre'); pre.className = 'fcCode'; pre.textContent = frame.code;
  box.append(head, pre);
  wrap.append(label, box);
  return wrap;
}
