const frameCodePageState = { motion: null, frame: null, panel: null, busy: false, note: '' };
const frameCodeState = { frames: [], active: null, motionName: null };