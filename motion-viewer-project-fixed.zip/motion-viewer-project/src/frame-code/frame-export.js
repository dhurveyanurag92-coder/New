/* Frame Code - logic: builds the frame data for a motion and zips it. Inlined into the app scope by build.py. */
const FRAME_EXPORT_NAME = 'motion_export';
const FC_DL_LABEL = '[ Download ]';

const motionDataApi = window.motionDataApi || {};
const sanitizeFrameExportName = motionDataApi.sanitizeFrameExportName || function(name){
  const safe = String(name || 'Motion').trim().replace(/\s+/g, '-').replace(/[^a-zA-Z0-9._-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  return safe || 'Motion';
};
const safeNumber = motionDataApi.safeNumber || function(v, digits = 3){
  if(!Number.isFinite(v)) return 'Unavailable';
  return Number(v).toFixed(digits);
};
const deg = motionDataApi.deg || function(v){ return Number.isFinite(v) ? (v * 180 / Math.PI).toFixed(3) + '°' : 'Unavailable'; };
const vectorSummaryLabel = motionDataApi.vectorSummaryLabel || function(v){ return `${safeNumber(v.x,3)} / ${safeNumber(v.y,3)} / ${safeNumber(v.z,3)}`; };
const humanFacingDirection = motionDataApi.humanFacingDirection || function(rotY){
  if(!Number.isFinite(rotY)) return 'Unavailable';
  const rad = ((rotY % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
  if(rad < Math.PI * 0.125 || rad > Math.PI * 1.875) return 'Forward (Z+)';
  if(rad < Math.PI * 0.375) return 'Forward-Right';
  if(rad < Math.PI * 0.625) return 'Right';
  if(rad < Math.PI * 0.875) return 'Backward-Right';
  if(rad < Math.PI * 1.125) return 'Backward';
  if(rad < Math.PI * 1.375) return 'Backward-Left';
  if(rad < Math.PI * 1.625) return 'Left';
  if(rad < Math.PI * 1.875) return 'Forward-Left';
  return 'Forward (Z+)';
};
const vectorDelta = motionDataApi.vectorDelta || function(a, b){ return { x: (a && a.x || 0) - (b && b.x || 0), y: (a && a.y || 0) - (b && b.y || 0), z: (a && a.z || 0) - (b && b.z || 0) }; };
const zeroVector = motionDataApi.zeroVector || function(){ return { x: 0, y: 0, z: 0 }; };
const zeroRotation = motionDataApi.zeroRotation || function(){ return { x: 0, y: 0, z: 0 }; };
const asEuler = motionDataApi.asEuler || function(obj){
  if(!obj) return { x: 0, y: 0, z: 0 };
  if(obj.isEuler) return { x: obj.x, y: obj.y, z: obj.z };
  if(obj.isQuaternion){ const e = new THREE.Euler(); e.setFromQuaternion(obj, 'XYZ'); return { x: e.x, y: e.y, z: e.z }; }
  return { x: Number(obj.x) || 0, y: Number(obj.y) || 0, z: Number(obj.z) || 0 };
};
const getBoneSide = motionDataApi.getBoneSide || function(name){
  const n = String(name || '').toLowerCase();
  if(n.includes('left')) return 'Left';
  if(n.includes('right')) return 'Right';
  return 'Center';
};
const getBoneGroup = motionDataApi.getBoneGroup || function(name){
  const n = String(name || '').toLowerCase();
  if(n.includes('hip')) return 'Hips';
  if(n.includes('spine')) return 'Spine';
  if(n.includes('neck') || n.includes('head')) return 'Head';
  if(n.includes('shoulder') || n.includes('arm') || n.includes('forearm') || n.includes('hand')) return 'Arm';
  if(n.includes('leg') || n.includes('thigh') || n.includes('shin') || n.includes('foot') || n.includes('toe')) return 'Leg';
  return 'Other';
};
const getAnimationTimingInfo = motionDataApi.getAnimationTimingInfo || function(clip){
  if(!clip){ return { fps: 30, duration: 0, totalFrames: 1, times: [0], source: 'static' }; }
  const times = [];
  if(clip.tracks && clip.tracks.length){
    for(const track of clip.tracks){
      if(track && Array.isArray(track.times)){ for(const t of track.times){ if(Number.isFinite(t)) times.push(Number(t)); } }
    }
  }
  const uniqueTimes = [...new Set(times.map(t => Number(t)))].filter(t => Number.isFinite(t) && t >= 0).sort((a,b)=>a-b);
  if(uniqueTimes.length){
    const explicitFps = Number(clip.fps) || 0;
    return { fps: explicitFps > 0 ? explicitFps : (uniqueTimes.length > 1 ? 1 / Math.max(1e-6, uniqueTimes[1] - uniqueTimes[0]) : 30), duration: Number(clip.duration) || Math.max(...uniqueTimes, 0), totalFrames: uniqueTimes.length, times: uniqueTimes, source: 'clip-timing' };
  }
  const explicitFps = Number(clip.fps) || 0;
  if(explicitFps > 0){
    const totalFrames = Math.max(2, Math.ceil((Number(clip.duration) || 0) * explicitFps) + 1);
    const fpsTimes = [];
    for(let i = 0; i < totalFrames; i++) fpsTimes.push(Math.min(Number(clip.duration) || 0, i / explicitFps));
    return { fps: explicitFps, duration: Number(clip.duration) || 0, totalFrames, times: fpsTimes, source: 'clip-fps' };
  }
  const duration = Number(clip.duration) || 0; const fallbackFps = 30; const totalFrames = Math.max(1, Math.ceil(duration * fallbackFps) + 1); const fallbackTimes = []; for(let i = 0; i < totalFrames; i++) fallbackTimes.push(Math.min(duration, i / fallbackFps)); return { fps: fallbackFps, duration, totalFrames, times: fallbackTimes, source: 'fallback-duration' };
};
const getActualSkeletonBones = motionDataApi.getActualSkeletonBones || function(){ return []; };
const getBoneRecordsForCurrentPose = motionDataApi.getBoneRecordsForCurrentPose || function(){ return []; };
const collectFrameCodeBlock = motionDataApi.collectFrameCodeBlock || function(){ return { box: '', code: '' }; };
const chooseExportData = motionDataApi.chooseExportData || function(){ return { name: 'Current Motion', fps: 30, duration: 0, totalFrames: 1, times: [0], mode: 'static', sourceTiming: 'static' }; };
async function collectFrameExportFrames(){
  if(window.motionDataApi && typeof window.motionDataApi.collectCanonicalFrameData === 'function') return window.motionDataApi.collectCanonicalFrameData();
  return [];
}
function escapeHtml(val){
  return String(val).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

async function downloadAllFramesZip(){
  if(!frameCodeState.frames.length){
    window.appUI.toast('There are no frame files to download yet.', 2600); return;
  }
  const btn = $('#downloadFramesBtn');
  btn.disabled = true;
  try {
    if(!window.JSZip){
      await loadScript('https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js');
    }
    if(!window.JSZip){ throw new Error('ZIP library could not load.'); }
    const zip = new JSZip();
    const baseName = sanitizeFrameExportName(frameCodeState.motionName || frameCodeState.frames[0].animationName || 'Motion');
    for(const frame of frameCodeState.frames){
      zip.file(frame.fileName, frame.code);
    }
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${baseName}-Frames.zip`; a.style.display = 'none';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url), 5000);
    window.appUI.toast('ZIP downloaded with all frame files.', 2000);
  } catch (error) {
    console.error(error);
    window.appUI.toast('The ZIP export could not be created.', 4000);
  } finally {
    btn.disabled = false; btn.textContent = FC_DL_LABEL;
  }
}
