/* Frame Code - page: state, rendering and registration in the ☰ menu. Inlined into the app scope by build.py.
   The page is built only when Frame Code is opened from the menu; nothing of it exists on Home. */
function fcCurrentFrame(){ return frameCodePageState.frame == null ? null : (frameCodeState.frames.find(f => f.number === frameCodePageState.frame) || null); }

function renderFrameCodePage(){
  if(!$('#fcStatus')) return;                               // page not built yet
  const frames = frameCodeState.frames, frame = fcCurrentFrame();
  const motionBtn = $('#fcMotionBtn'), frameBtn = $('#fcFrameBtn'), dl = $('#downloadFramesBtn');
  motionBtn.disabled = frameBtn.disabled = dl.disabled = frameCodePageState.busy;
  motionBtn.setAttribute('aria-expanded', String(frameCodePageState.panel === 'motion'));
  frameBtn.setAttribute('aria-expanded', String(frameCodePageState.panel === 'frame'));

  let msg;
  if(frameCodePageState.note) msg = frameCodePageState.note;
  else if(frameCodePageState.busy) msg = 'Generating frames for ' + frameCodePageState.motion + '…';
  else if(!frameCodePageState.motion) msg = 'Select a Motion to begin.';
  else if(frame) msg = `${frameCodePageState.motion} · Frame ${frame.number} · ${safeNumber(frame.time, 3)} sec`;
  else msg = `${frameCodePageState.motion} · ${frames.length} frame${frames.length === 1 ? '' : 's'} — tap [ Frame ] to choose one.`;
  $('#fcStatus').textContent = msg;

  const picker = $('#fcPicker'); picker.textContent = '';
  picker.hidden = !frameCodePageState.panel || frameCodePageState.busy;
  if(frameCodePageState.panel === 'motion'){
    const cats = new Map();
    for(const a of window.motionRuntime.getActions()){ if(!cats.has(a.category)) cats.set(a.category, []); cats.get(a.category).push(a); }
    const order = [...cats.keys()].sort((x, y)=>{ const ix = CAT_ORDER.indexOf(x), iy = CAT_ORDER.indexOf(y); return (ix < 0 ? 99 : ix) - (iy < 0 ? 99 : iy); });
    for(const cat of order){
      const g = document.createElement('div');
      const l = document.createElement('div'); l.className = 'fcCat'; l.textContent = cat; g.appendChild(l);
      const row = document.createElement('div'); row.className = 'fcChips'; g.appendChild(row);
      for(const a of cats.get(cat)) row.appendChild(fcChip(a.name, a.name === frameCodePageState.motion, ()=>fcPickMotion(a.name)));
      picker.appendChild(g);
    }
  } else if(frameCodePageState.panel === 'frame'){
    const row = document.createElement('div'); row.className = 'fcChips frames';
    row.appendChild(fcChip('All', frameCodePageState.frame == null, ()=>fcPickFrame(null)));
    for(const f of frames) row.appendChild(fcChip('Frame ' + f.number, f.number === frameCodePageState.frame, ()=>fcPickFrame(f.number)));
    picker.appendChild(row);
  }

  const list = $('#frameCodeList'); list.textContent = '';
  if(frame && !frameCodePageState.busy) list.appendChild(fcCodeBox(frame));
}
async function fcPickMotion(name){
  if(frameCodePageState.busy || !window.motionRuntime.hasAction(name)) return;
  frameCodePageState.busy = true; frameCodePageState.note = ''; frameCodePageState.panel = null; frameCodePageState.motion = name; frameCodePageState.frame = null;
  frameCodeState.frames = []; frameCodeState.motionName = name;
  renderFrameCodePage();
  try {
    window.motionRuntime.selectAction(name);
    frameCodeState.frames = await collectFrameExportFrames();
  } catch (error) {
    console.error(error);
    frameCodePageState.motion = null; frameCodeState.frames = []; frameCodeState.motionName = null;
    window.appUI.toast('Could not generate frame code for this motion.', 4500);
  } finally {
    frameCodePageState.busy = false; renderFrameCodePage();
  }
}
function fcPickFrame(number){ frameCodePageState.frame = number; frameCodePageState.note = ''; renderFrameCodePage(); }

function mountFrameCodePage(el){
  el.appendChild(document.getElementById('frameCodePageTpl').content.cloneNode(true));
  $('#fcMotionBtn').addEventListener('click', ()=>{ frameCodePageState.note = ''; frameCodePageState.panel = (frameCodePageState.panel === 'motion') ? null : 'motion'; renderFrameCodePage(); });
  $('#fcFrameBtn').addEventListener('click', ()=>{
    if(!frameCodePageState.motion){ frameCodePageState.panel = null; frameCodePageState.note = 'Select a Motion first, then choose a Frame.'; renderFrameCodePage(); return; }
    frameCodePageState.note = ''; frameCodePageState.panel = (frameCodePageState.panel === 'frame') ? null : 'frame'; renderFrameCodePage();
  });
  $('#downloadFramesBtn').addEventListener('click', ()=>{
    if(!frameCodePageState.motion || !frameCodeState.frames.length){ frameCodePageState.note = 'Select a Motion first. Download saves the frames of the selected Motion.'; renderFrameCodePage(); return; }
    frameCodePageState.note = ''; renderFrameCodePage();
    downloadAllFramesZip();
  });
}
function showFrameCodePage(){
  // Initial state each time the page opens: nothing selected, no code shown. Motion first, then Frame.
  Object.assign(frameCodePageState, { motion:null, frame:null, panel:null, busy:false, note:'' });
  frameCodeState.frames = []; frameCodeState.motionName = null;
  renderFrameCodePage();
}

nav.registerPage({
  id:'frame-code', label:'Frame Code', order:10,
  icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/></svg>',
  canOpen(){
    if(window.motionRuntime.getModel()) return true;
    window.appUI.toast('Import a character before exporting frame code.', 2800);
    return false;
  },
  mount: mountFrameCodePage,
  onShow: showFrameCodePage
});
