  const validateMotionQuality = frames => {
    if (window.motionQuality && typeof window.motionQuality.analyzeFrames === 'function') {
      return window.motionQuality.analyzeFrames(frames || []);
    }
    return { status: 'PASS', warnings: [], phases: [], summary: { totalWarnings: 0, phaseCount: 0, frameCount: Array.isArray(frames) ? frames.length : 0 } };
  };

  const api = {
    sanitizeFrameExportName,
    safeNumber,
    deg,
    vectorSummaryLabel,
    humanFacingDirection,
    vectorDelta,
    zeroVector,
    zeroRotation,
    asEuler,
    asVector3,
    getBoneSide,
    getBoneGroup,
    getAnimationTimingInfo,
    motionDataIsSharedBoneClone,
    getActualSkeletonBones,
    getBoneRecordsForCurrentPose,
    collectFrameCodeBlock,
    chooseExportData,
    collectCanonicalFrameData,
    collectFrameExportFrames: () => collectCanonicalFrameData(),
    validateMotionQuality,
  };

  window.motionDataApi = api;
  window.collectCanonicalFrameData = collectCanonicalFrameData;
  window.getAnimationTimingInfo = getAnimationTimingInfo;
  window.getActualSkeletonBones = getActualSkeletonBones;
  window.getBoneRecordsForCurrentPose = getBoneRecordsForCurrentPose;
  window.collectFrameExportFrames = collectCanonicalFrameData;
  window.sanitizeFrameExportName = sanitizeFrameExportName;
  window.validateMotionQuality = validateMotionQuality;
})();
