  async function collectCanonicalFrameData(){
    const model = getRuntimeModel();
    const holder = getRuntimeHolder();
    const current = getRuntimeCurrent();
    const mixer = getRuntimeMixer();
    const activeAction = getRuntimeActiveAction();
    const rig = getRuntimeRig();
    if(!model || !holder) return [];
    const exportInfo = chooseExportData();
    const frames = [];
    const start = { position: holder.position.clone(), rotation: holder.rotation.clone() };
    const originalPlaying = window.playing;
    const originalT = window.t;
    const originalCurrent = current;
    const originalAction = activeAction;
    const originalTime = originalAction ? originalAction.time : 0;
    const wasImported = !!(current && current.imported);
    const startBoneSnapshot = getBoneRecordsForCurrentPose();
    const startBoneMap = new Map(startBoneSnapshot.map(b => [b.originalName, b]));

    try{
      if(wasImported && current && current.clip && mixer){
        const clipAction = activeAction || mixer.clipAction(current.clip);
        clipAction.reset();
        clipAction.setLoop(THREE.LoopRepeat, Infinity);
        clipAction.play();
        const startPos = holder.position.clone();
        const sampleTimes = Array.isArray(exportInfo.times) && exportInfo.times.length ? exportInfo.times.slice() : [];
        let previousCharacter = null;
        let previousBoneMap = null;
        for(let i = 0; i < sampleTimes.length; i++){
          const time = sampleTimes[i];
          if (clipAction) clipAction.time = time;
          mixer.update(0);
          const position = holder.position.clone();
          const rotation = holder.rotation.clone();
          const deltaFromPrevious = previousCharacter ? {
            position: vectorDelta(position, previousCharacter.position),
            rotation: vectorDelta(rotation, previousCharacter.rotation),
          } : { position: zeroVector(), rotation: zeroRotation() };
          const movementFromStart = { x: position.x - startPos.x, y: position.y - startPos.y, z: position.z - startPos.z };
          const rawBones = getBoneRecordsForCurrentPose();
          const boneRecords = rawBones.map(bone => {
            const prevBone = previousBoneMap ? previousBoneMap.get(bone.originalName) : null;
            const startBone = startBoneMap.get(bone.originalName) || null;
            const localPosDelta = prevBone ? vectorDelta(bone.localPosition, prevBone.localPosition) : zeroVector();
            const localRotDelta = prevBone ? vectorDelta(asEuler(bone.localEuler), asEuler(prevBone.localEuler)) : zeroRotation();
            const worldPosDelta = prevBone ? vectorDelta(bone.worldPosition, prevBone.worldPosition) : zeroVector();
            const worldRotDelta = prevBone ? vectorDelta(asEuler(bone.worldEuler), asEuler(prevBone.worldEuler)) : zeroRotation();
            const movementFromStartBone = startBone ? {
              localPosition: vectorDelta(bone.localPosition, startBone.localPosition),
              localRotation: vectorDelta(asEuler(bone.localEuler), asEuler(startBone.localEuler)),
              worldPosition: vectorDelta(bone.worldPosition, startBone.worldPosition),
              worldRotation: vectorDelta(asEuler(bone.worldEuler), asEuler(startBone.worldEuler)),
            } : {
              localPosition: zeroVector(),
              localRotation: zeroRotation(),
              worldPosition: zeroVector(),
              worldRotation: zeroRotation(),
            };
            return Object.assign({}, bone, {
              deltaFromPrevious: {
                localPosition: localPosDelta,
                localRotation: localRotDelta,
                worldPosition: worldPosDelta,
                worldRotation: worldRotDelta,
              },
              movementFromStart: movementFromStartBone,
            });
          });
          const summary = { position, rotation, movementFromStart, deltaFromPrevious, facing: humanFacingDirection(rotation.y) };
          const characterState = { position, rotation, movementFromStart, deltaFromPrevious };
          const code = collectFrameCodeBlock(i + 1, time, exportInfo.fps, exportInfo.name, characterState, boneRecords, summary.facing);
          frames.push({
            number: i + 1,
            time,
            fps: exportInfo.fps,
            animationName: exportInfo.name,
            summary,
            code: code.code,
            box: code.box,
            fileName: `frame_${String(i + 1).padStart(4, '0')}.txt`,
            character: characterState,
            bones: boneRecords,
          });
          previousCharacter = { position, rotation };
          previousBoneMap = new Map(boneRecords.map(b => [b.originalName, b]));
          if ((i + 1) % 20 === 0) await new Promise(resolve => requestAnimationFrame(resolve));
        }
      } else if (rig && current){
        const sampleTimes = Array.isArray(exportInfo.times) && exportInfo.times.length ? exportInfo.times.slice() : [];
        const startPos = holder.position.clone();
        let previousCharacter = null;
        let previousBoneMap = null;
        for(let i = 0; i < sampleTimes.length; i++){
          const time = sampleTimes[i];
          const before = { holderPosition: holder.position.clone(), holderRotation: holder.rotation.clone() };
          if (typeof window.evalPose === 'function') window.evalPose(time, 0);
          const position = holder.position.clone();
          const rotation = holder.rotation.clone();
          const deltaFromPrevious = previousCharacter ? {
            position: vectorDelta(position, previousCharacter.position),
            rotation: vectorDelta(rotation, previousCharacter.rotation),
          } : { position: zeroVector(), rotation: zeroRotation() };
          const movementFromStart = { x: position.x - startPos.x, y: position.y - startPos.y, z: position.z - startPos.z };
          const rawBones = getBoneRecordsForCurrentPose();
          const boneRecords = rawBones.map(bone => {
            const prevBone = previousBoneMap ? previousBoneMap.get(bone.originalName) : null;
            const startBone = startBoneMap.get(bone.originalName) || null;
            const localPosDelta = prevBone ? vectorDelta(bone.localPosition, prevBone.localPosition) : zeroVector();
            const localRotDelta = prevBone ? vectorDelta(asEuler(bone.localEuler), asEuler(prevBone.localEuler)) : zeroRotation();
            const worldPosDelta = prevBone ? vectorDelta(bone.worldPosition, prevBone.worldPosition) : zeroVector();
            const worldRotDelta = prevBone ? vectorDelta(asEuler(bone.worldEuler), asEuler(prevBone.worldEuler)) : zeroRotation();
            const movementFromStartBone = startBone ? {
              localPosition: vectorDelta(bone.localPosition, startBone.localPosition),
              localRotation: vectorDelta(asEuler(bone.localEuler), asEuler(startBone.localEuler)),
              worldPosition: vectorDelta(bone.worldPosition, startBone.worldPosition),
              worldRotation: vectorDelta(asEuler(bone.worldEuler), asEuler(startBone.worldEuler)),
            } : {
              localPosition: zeroVector(),
              localRotation: zeroRotation(),
              worldPosition: zeroVector(),
              worldRotation: zeroRotation(),
            };
            return Object.assign({}, bone, {
              deltaFromPrevious: {
                localPosition: localPosDelta,
                localRotation: localRotDelta,
                worldPosition: worldPosDelta,
                worldRotation: worldRotDelta,
              },
              movementFromStart: movementFromStartBone,
            });
          });
          const finalPos = holder.position.clone();
          holder.position.copy(before.holderPosition);
          holder.rotation.copy(before.holderRotation);
          const summary = { position: finalPos, rotation, movementFromStart, deltaFromPrevious, facing: humanFacingDirection(rotation.y) };
          const characterState = { position: finalPos, rotation, movementFromStart, deltaFromPrevious };
          const code = collectFrameCodeBlock(i + 1, time, exportInfo.fps, exportInfo.name, characterState, boneRecords, summary.facing);
          frames.push({
            number: i + 1,
            time,
            fps: exportInfo.fps,
            animationName: exportInfo.name,
            summary,
            code: code.code,
            box: code.box,
            fileName: `frame_${String(i + 1).padStart(4, '0')}.txt`,
            character: characterState,
            bones: boneRecords,
          });
          previousCharacter = { position: finalPos, rotation };
          previousBoneMap = new Map(boneRecords.map(b => [b.originalName, b]));
          if ((i + 1) % 20 === 0) await new Promise(resolve => requestAnimationFrame(resolve));
        }
        if (rig && current && !current.imported) {
          if (typeof window.restoreBind === 'function') window.restoreBind();
          if (typeof window.evalPose === 'function') window.evalPose(window.t || 0, 0);
        }
      } else {
        const position = holder.position.clone();
        const rotation = holder.rotation.clone();
        const movementFromStart = { x: 0, y: 0, z: 0 };
        const deltaFromPrevious = { position: zeroVector(), rotation: zeroRotation() };
        const boneRecords = getBoneRecordsForCurrentPose();
        const summary = { position, rotation, movementFromStart, deltaFromPrevious, facing: humanFacingDirection(rotation.y) };
        const characterState = { position, rotation, movementFromStart, deltaFromPrevious };
        const code = collectFrameCodeBlock(1, 0, exportInfo.fps, exportInfo.name, characterState, boneRecords, summary.facing);
        frames.push({
          number: 1,
          time: 0,
          fps: exportInfo.fps,
          animationName: exportInfo.name,
          summary,
          code: code.code,
          box: code.box,
          fileName: 'frame_0001.txt',
          character: characterState,
          bones: boneRecords,
        });
      }
    } finally {
      if (current && current.imported && mixer && originalAction) {
        const restart = mixer.clipAction(current.clip);
        restart.reset();
        restart.time = originalTime;
        restart.play();
      }
      if (originalCurrent && originalCurrent.imported) {
        if(mixer){
          const act = mixer.clipAction(originalCurrent.clip);
          act.reset();
          act.play();
          if (typeof originalTime === 'number') act.time = originalTime;
        }
      }
      if(!wasImported && rig && originalCurrent && !originalCurrent.imported){
        if (typeof window.restoreBind === 'function') window.restoreBind();
        if (typeof window.evalPose === 'function') window.evalPose(window.t || 0, 0);
      }
      holder.position.copy(start.position);
      holder.rotation.copy(start.rotation);
    }
    return frames;
  }

    function motionPipelineCaptureFrame(frameData, previousFrame){
      const root = frameData && frameData.root ? frameData.root : { position: [0,0,0], rotation: [0,0,0] };
      const bones = frameData && frameData.bones ? frameData.bones : {};
      const previousRoot = previousFrame && previousFrame.root ? previousFrame.root : { position: [0,0,0], rotation: [0,0,0] };
      const velocity = {
        position: [
          root.position[0] - previousRoot.position[0],
          root.position[1] - previousRoot.position[1],
          root.position[2] - previousRoot.position[2],
        ],
        rotation: [
          root.rotation[0] - previousRoot.rotation[0],
          root.rotation[1] - previousRoot.rotation[1],
          root.rotation[2] - previousRoot.rotation[2],
        ],
      };
      const boneVelocity = {};
      for (const [boneName, bonePose] of Object.entries(bones)) {
        const prev = previousFrame && previousFrame.bones && previousFrame.bones[boneName] ? previousFrame.bones[boneName] : { position: [0,0,0], rotation: [0,0,0] };
        boneVelocity[boneName] = {
          position: [
            bonePose.position[0] - prev.position[0],
            bonePose.position[1] - prev.position[1],
            bonePose.position[2] - prev.position[2],
          ],
          rotation: [
            bonePose.rotation[0] - prev.rotation[0],
            bonePose.rotation[1] - prev.rotation[1],
            bonePose.rotation[2] - prev.rotation[2],
          ],
        };
      }
      return { root, velocity, boneVelocity };
    }

    function motionPipelineAnalyzeFrames(frames){
      const list = Array.isArray(frames) ? frames.filter(Boolean) : [];
      const warnings = [];
      if (!list.length) return { status: 'PASS', warnings, phases: [], summary: { frameCount: 0, phaseCount: 0, totalWarnings: 0 } };
      for (let i = 1; i < list.length; i++) {
        const current = list[i];
        const previous = list[i - 1];
        const capture = motionPipelineCaptureFrame(current, previous);
        const speed = Math.hypot(capture.velocity.position[0], capture.velocity.position[1], capture.velocity.position[2]);
        if (speed > 1.5) warnings.push('VELOCITY SPIKE WARNING at frame ' + (current.number || i + 1));
        for (const [boneName, delta] of Object.entries(capture.boneVelocity || {})) {
          const strength = Math.hypot(delta.position[0], delta.position[1], delta.position[2]);
          if (strength > 2.0) warnings.push('BONE VELOCITY WARNING at frame ' + (current.number || i + 1) + ' on ' + boneName);
        }
      }
      const phases = [
        { label: 'CONTACT', startFrame: 1, endFrame: Math.max(1, Math.ceil(list.length * 0.25)) },
        { label: 'PUSH', startFrame: Math.max(1, Math.ceil(list.length * 0.25) + 1), endFrame: Math.max(1, Math.ceil(list.length * 0.5)) },
        { label: 'FLIGHT', startFrame: Math.max(1, Math.ceil(list.length * 0.5) + 1), endFrame: Math.max(1, Math.ceil(list.length * 0.75)) },
        { label: 'RECOVER', startFrame: Math.max(1, Math.ceil(list.length * 0.75) + 1), endFrame: list.length },
      ];
      return {
        status: warnings.length ? 'WARNING' : 'PASS',
        warnings,
        phases,
        summary: {
          frameCount: list.length,
          phaseCount: phases.length,
          totalWarnings: warnings.length,
        },
      };
    }

    window.motionPipeline = {
      captureFrame: motionPipelineCaptureFrame,
      analyzeFrames: motionPipelineAnalyzeFrames,
      validateFrames: motionPipelineAnalyzeFrames,
    };

