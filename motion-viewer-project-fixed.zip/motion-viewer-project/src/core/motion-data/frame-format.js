  function collectFrameCodeBlock(frameIndex, time, fps, animationName, characterState, boneRecords, facingDirection){
    const rootPosition = characterState.position;
    const rootRotation = characterState.rotation;
    const movementFromStart = characterState.movementFromStart || zeroVector();
    const deltaFromPrevious = characterState.deltaFromPrevious || { position: zeroVector(), rotation: zeroRotation() };
    const lines = [];
    const title = `FRAME ${String(frameIndex).padStart(3, '0')}`;
    const width = 38;
    const posDelta = deltaFromPrevious.position || zeroVector();
    const rotDelta = deltaFromPrevious.rotation || zeroRotation();
    lines.push('┌' + '─'.repeat(width) + '┐');
    lines.push('│ ' + title.padEnd(width - 2, ' ') + '│');
    lines.push(`│ Time: ${safeNumber(time, 3).padStart(7, ' ')} sec${' '.repeat(Math.max(1, width - 19 - safeNumber(time, 3).length))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ [ COMPLETE FRAME CODE ]' + ' '.repeat(Math.max(1, width - 26)) + '│');
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ Character Position: ' + ' '.repeat(Math.max(1, width - 22)) + '│');
    lines.push(`│ X: ${safeNumber(rootPosition.x, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push(`│ Y: ${safeNumber(rootPosition.y, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push(`│ Z: ${safeNumber(rootPosition.z, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ Character Rotation: ' + ' '.repeat(Math.max(1, width - 23)) + '│');
    lines.push(`│ X: ${deg(rootRotation.x).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 30))}│`);
    lines.push(`│ Y: ${deg(rootRotation.y).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 30))}│`);
    lines.push(`│ Z: ${deg(rootRotation.z).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 30))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ Position Δ prev: ' + ' '.repeat(Math.max(1, width - 19)) + '│');
    lines.push(`│ X: ${safeNumber(posDelta.x, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push(`│ Y: ${safeNumber(posDelta.y, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push(`│ Z: ${safeNumber(posDelta.z, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ Rotation Δ prev: ' + ' '.repeat(Math.max(1, width - 18)) + '│');
    lines.push(`│ X: ${deg(rotDelta.x).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 30))}│`);
    lines.push(`│ Y: ${deg(rotDelta.y).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 30))}│`);
    lines.push(`│ Z: ${deg(rotDelta.z).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 30))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ Movement from Start: ' + ' '.repeat(Math.max(1, width - 22)) + '│');
    lines.push(`│ X: ${safeNumber(movementFromStart.x, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push(`│ Y: ${safeNumber(movementFromStart.y, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push(`│ Z: ${safeNumber(movementFromStart.z, 3).padStart(12, ' ')} ${' '.repeat(Math.max(1, width - 28))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ Bone Data: ' + ' '.repeat(Math.max(1, width - 14)) + '│');
    for(let i = 0; i < Math.min(boneRecords.length, 12); i++){
      const bone = boneRecords[i];
      const label = bone.originalName || 'UnknownBone';
      const content = `${label}: ${safeNumber(bone.worldPosition.x, 3)}, ${safeNumber(bone.worldPosition.y, 3)}, ${safeNumber(bone.worldPosition.z, 3)}`;
      lines.push('│ ' + content.substring(0, width - 4).padEnd(width - 4, ' ') + ' │');
    }
    if (boneRecords.length > 12) lines.push(`│ ... ${' '.repeat(Math.max(1, width - 8))}│`);
    lines.push('│ ' + ''.padEnd(width - 2, ' ') + '│');
    lines.push('│ [ COPY FRAME CODE ]' + ' '.repeat(Math.max(1, width - 23)) + '│');
    lines.push('└' + '─'.repeat(width) + '┘');

    const flat = [
      'Frame Number: ' + frameIndex,
      'Time: ' + safeNumber(time, 3) + ' sec',
      'FPS: ' + safeNumber(fps, 3),
      'Animation Name: ' + (animationName || 'Current Animation'),
      '',
      'Character Position:',
      `X: ${safeNumber(rootPosition.x, 3)}`,
      `Y: ${safeNumber(rootPosition.y, 3)}`,
      `Z: ${safeNumber(rootPosition.z, 3)}`,
      '',
      'Character Rotation:',
      `X: ${deg(rootRotation.x)}`,
      `Y: ${deg(rootRotation.y)}`,
      `Z: ${deg(rootRotation.z)}`,
      '',
      'Delta From Previous Frame:',
      `Position: X=${safeNumber(posDelta.x, 3)} Y=${safeNumber(posDelta.y, 3)} Z=${safeNumber(posDelta.z, 3)}`,
      `Rotation: X=${deg(rotDelta.x)} Y=${deg(rotDelta.y)} Z=${deg(rotDelta.z)}`,
      '',
      'Movement from Start:',
      `X: ${safeNumber(movementFromStart.x, 3)}`,
      `Y: ${safeNumber(movementFromStart.y, 3)}`,
      `Z: ${safeNumber(movementFromStart.z, 3)}`,
      '',
      'Facing Direction:',
      facingDirection,
      '',
      'Bone Data:',
      ...boneRecords.map(b => {
        const semantic = b.semanticName || b.originalName || 'UnknownBone';
        const prev = b.deltaFromPrevious || { localPosition: zeroVector(), localRotation: zeroRotation(), worldPosition: zeroVector(), worldRotation: zeroRotation() };
        const move = b.movementFromStart || { localPosition: zeroVector(), localRotation: zeroRotation(), worldPosition: zeroVector(), worldRotation: zeroRotation() };
        return `${b.originalName || 'UnknownBone'} | normalized=${semantic} | parent=${b.parent || 'Root'} | children=${(b.children || []).join(',') || 'None'} | depth=${b.depth ?? 0} | side=${b.side || 'Center'} | group=${b.chain || 'Other'} | localPos=${safeNumber(b.localPosition.x, 3)}/${safeNumber(b.localPosition.y, 3)}/${safeNumber(b.localPosition.z, 3)} | localRot=${deg(b.localEuler.x)}/${deg(b.localEuler.y)}/${deg(b.localEuler.z)} | worldPos=${safeNumber(b.worldPosition.x, 3)}/${safeNumber(b.worldPosition.y, 3)}/${safeNumber(b.worldPosition.z, 3)} | worldRot=${deg(b.worldEuler.x)}/${deg(b.worldEuler.y)}/${deg(b.worldEuler.z)} | deltaLocalPos=${safeNumber(prev.localPosition.x, 3)}/${safeNumber(prev.localPosition.y, 3)}/${safeNumber(prev.localPosition.z, 3)} | deltaLocalRot=${deg(prev.localRotation.x)}/${deg(prev.localRotation.y)}/${deg(prev.localRotation.z)} | moveFromStartWorld=${safeNumber(move.worldPosition.x, 3)}/${safeNumber(move.worldPosition.y, 3)}/${safeNumber(move.worldPosition.z, 3)}`;
      })
    ].join('\n');
    return { box: lines.join('\n'), code: flat };
  }
