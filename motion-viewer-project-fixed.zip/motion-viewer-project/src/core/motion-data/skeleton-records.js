  function getRuntimeContext(){
    return (window.motionRuntime && typeof window.motionRuntime === 'object') ? window.motionRuntime : null;
  }
  function getRuntimeModel(){
    const runtime = getRuntimeContext();
    if(runtime && typeof runtime.getModel === 'function') return runtime.getModel();
    return window.model || null;
  }
  function getRuntimeCurrent(){
    const runtime = getRuntimeContext();
    if(runtime && typeof runtime.getCurrent === 'function') return runtime.getCurrent();
    return window.current || null;
  }
  function getRuntimeHolder(){
    const runtime = getRuntimeContext();
    if(runtime && typeof runtime.getHolder === 'function') return runtime.getHolder();
    return window.holder || null;
  }
  function getRuntimeMixer(){
    const runtime = getRuntimeContext();
    if(runtime && typeof runtime.getMixer === 'function') return runtime.getMixer();
    return window.mixer || null;
  }
  function getRuntimeActiveAction(){
    const runtime = getRuntimeContext();
    if(runtime && typeof runtime.getActiveAction === 'function') return runtime.getActiveAction();
    return window.activeAct || null;
  }
  function getRuntimeRig(){
    const runtime = getRuntimeContext();
    if(runtime && typeof runtime.getRig === 'function') return runtime.getRig();
    return window.rig || null;
  }
  function getBoneSide(name){
    const n = String(name || '').toLowerCase();
    if(n.includes('left')) return 'Left';
    if(n.includes('right')) return 'Right';
    return 'Center';
  }
  function getBoneGroup(name){
    const n = String(name || '').toLowerCase();
    if(n.includes('hip')) return 'Hips';
    if(n.includes('spine')) return 'Spine';
    if(n.includes('neck') || n.includes('head')) return 'Head';
    if(n.includes('shoulder') || n.includes('arm') || n.includes('forearm') || n.includes('hand')) return 'Arm';
    if(n.includes('leg') || n.includes('thigh') || n.includes('shin') || n.includes('foot') || n.includes('toe')) return 'Leg';
    return 'Other';
  }
  function getAnimationTimingInfo(clip){
    if(!clip){ return { fps: 30, duration: 0, totalFrames: 1, times: [0], source: 'static' }; }
    const times = [];
    if(clip.tracks && clip.tracks.length){
      for(const track of clip.tracks){
        if(track && Array.isArray(track.times)){
          for(const t of track.times){
            if(Number.isFinite(t)) times.push(Number(t));
          }
        }
      }
    }
    const uniqueTimes = [...new Set(times.map(t => Number(t)))].filter(t => Number.isFinite(t) && t >= 0).sort((a, b) => a - b);
    if(uniqueTimes.length){
      const explicitFps = Number(clip.fps) || 0;
      return {
        fps: explicitFps > 0 ? explicitFps : (uniqueTimes.length > 1 ? 1 / Math.max(1e-6, uniqueTimes[1] - uniqueTimes[0]) : 30),
        duration: Number(clip.duration) || Math.max(...uniqueTimes, 0),
        totalFrames: uniqueTimes.length,
        times: uniqueTimes,
        source: 'clip-timing',
      };
    }
    const explicitFps = Number(clip.fps) || 0;
    if(explicitFps > 0){
      const totalFrames = Math.max(2, Math.ceil((Number(clip.duration) || 0) * explicitFps) + 1);
      const fpsTimes = [];
      for(let i = 0; i < totalFrames; i++) fpsTimes.push(Math.min(Number(clip.duration) || 0, i / explicitFps));
      return { fps: explicitFps, duration: Number(clip.duration) || 0, totalFrames, times: fpsTimes, source: 'clip-fps' };
    }
    const duration = Number(clip.duration) || 0;
    const fallbackFps = 30;
    const totalFrames = Math.max(1, Math.ceil(duration * fallbackFps) + 1);
    const fallbackTimes = [];
    for(let i = 0; i < totalFrames; i++) fallbackTimes.push(Math.min(duration, i / fallbackFps));
    return { fps: fallbackFps, duration, totalFrames, times: fallbackTimes, source: 'fallback-duration' };
  }
  function getActualSkeletonBones(){
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry();
    if(registry) return registry.bones.filter(record=>!record.isAuxiliaryClone).map(record=>record.bone);
    const model = getRuntimeModel();
    if(!model) return [];
    const bones = [];
    model.traverse(object=>{ if(object.isBone) bones.push(object); });
    return bones.filter(bone=>!isSharedBoneClone(bone));
  }
  function getBoneRecordsForCurrentPose(){
    const model = getRuntimeModel();
    if(!model) return [];
    model.updateMatrixWorld(true);
    const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry();
    const realBones = getActualSkeletonBones();
    const realSet = new Set(realBones);
    const records = [];
    for(const o of realBones){
      let parentBone = null;
      for(let p = o.parent; p; p = p.parent){
        if(p.isBone && realSet.has(p)){ parentBone = p; break; }
      }
      const worldPos = new THREE.Vector3();
      const worldQuat = new THREE.Quaternion();
      o.getWorldPosition(worldPos); o.getWorldQuaternion(worldQuat);
      const localEuler = new THREE.Euler().setFromQuaternion(o.quaternion.clone(), 'XYZ');
      const children = realBones.filter(child => child.parent && child.parent.isBone && child.parent.uuid === o.uuid).map(child => child.name);
      const parent = parentBone ? parentBone.name : 'Root';
      const registryRecord = registry && registry.byObject.get(o);
      const semantic = registryRecord ? registryRecord.normalizedName : ((typeof window.normName === 'function') ? (window.normName(o.name) || o.name) : o.name);
      const boneLength = registryRecord ? registryRecord.boneLength : (parentBone ? worldPos.distanceTo(parentBone.getWorldPosition(new THREE.Vector3())) : o.position.length());
      records.push({
        originalName: o.name,
        normalizedName: semantic,
        semanticName: semantic,
        semanticRole: registryRecord ? registryRecord.semanticRole : null,
        mappingStatus: registryRecord ? registryRecord.mappingStatus : 'unmapped',
        mappingConfidence: registryRecord ? registryRecord.mappingConfidence : 0,
        parent,
        children,
        depth: parentBone ? (function(){ let d = 0; let p = o.parent; while(p && p.isBone && realSet.has(p)){ d += 1; p = p.parent; } return d; })() : 0,
        side: getBoneSide(o.name),
        chain: getBoneGroup(o.name),
        boneLength,
        localPosition: o.position.clone(),
        localRotation: o.quaternion.clone(),
        restPosition: registryRecord ? registryRecord.restPosition.clone() : o.position.clone(),
        restRotation: registryRecord ? registryRecord.restRotation.clone() : o.quaternion.clone(),
        restWorldPosition: registryRecord ? registryRecord.restWorldPosition.clone() : worldPos.clone(),
        restWorldRotation: registryRecord ? registryRecord.restWorldRotation.clone() : worldQuat.clone(),
        localEuler,
        worldPosition: worldPos,
        worldRotation: worldQuat,
        worldEuler: new THREE.Euler().setFromQuaternion(worldQuat, 'XYZ'),
        deltaFromPrevious: zeroVector(),
        movementFromStart: zeroVector(),
      });
    }
    return records;
  }
