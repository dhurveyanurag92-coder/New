(function(){
  'use strict';

  function zeroVector(){ return { x: 0, y: 0, z: 0 }; }
  function zeroRotation(){ return { x: 0, y: 0, z: 0 }; }

  function sanitizeFrameExportName(name){
    const safe = String(name || 'Motion').trim().replace(/\s+/g, '-').replace(/[^a-zA-Z0-9._-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    return safe || 'Motion';
  }
  function safeNumber(v, digits = 3){
    if(!Number.isFinite(v)) return 'Unavailable';
    return Number(v).toFixed(digits);
  }
  function deg(v){ return Number.isFinite(v) ? (v * 180 / Math.PI).toFixed(3) + '°' : 'Unavailable'; }
  function vectorSummaryLabel(v){ return `${safeNumber(v.x,3)} / ${safeNumber(v.y,3)} / ${safeNumber(v.z,3)}`; }
  function humanFacingDirection(rotY){
    if(!Number.isFinite(rotY)) return 'Unavailable';
    const rad = ((rotY % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
    if(rad < Math.PI * 0.125 || rad > Math.PI * 1.875) return 'Forward (Z+)';
    if(rad < Math.PI * 0.375) return 'Forward-Right';
    if(rad < Math.PI * 0.625) return 'Right';
    if(rad < Math.PI * 0.875) return 'Backward-Right';
    if(rad < Math.PI * 1.125) return 'Backward';
    if(rad < Math.PI * 1.375) return 'Backward-Left';
    if(rad < Math.PI * 1.625) return 'Left';
    if(rad < Math.PI * 1.875) return 'Forward-Left';
    return 'Forward (Z+)';
  }
  function vectorDelta(a, b){ return { x: (a && a.x || 0) - (b && b.x || 0), y: (a && a.y || 0) - (b && b.y || 0), z: (a && a.z || 0) - (b && b.z || 0) }; }
  function asEuler(obj){
    if(!obj) return { x: 0, y: 0, z: 0 };
    if(obj.isEuler) return { x: obj.x, y: obj.y, z: obj.z };
    if(obj.isQuaternion){ const e = new THREE.Euler(); e.setFromQuaternion(obj, 'XYZ'); return { x: e.x, y: e.y, z: e.z }; }
    return { x: Number(obj.x) || 0, y: Number(obj.y) || 0, z: Number(obj.z) || 0 };
  }
  function asVector3(v){
    if(!v) return { x: 0, y: 0, z: 0 };
    return { x: Number(v.x) || 0, y: Number(v.y) || 0, z: Number(v.z) || 0 };
  }
