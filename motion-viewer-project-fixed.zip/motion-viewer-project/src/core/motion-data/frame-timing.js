  function chooseExportData(){
    const current = getRuntimeCurrent();
    const rig = getRuntimeRig();
    const baseName = current && current.name ? current.name : 'Current Motion';
    if(current && current.imported && current.clip){
      const timing = getAnimationTimingInfo(current.clip);
      return {
        name: current.clip.name || baseName,
        fps: timing.fps,
        duration: timing.duration,
        totalFrames: timing.totalFrames,
        times: timing.times,
        mode: 'imported',
        sourceTiming: timing.source,
      };
    }
    if(rig && current){
      const fps = 30;
      const totalFrames = Math.max(1, Math.ceil(2.5 * fps) + 1);
      const times = [];
      for(let i = 0; i < totalFrames; i++) times.push(Math.min(2.5, i / fps));
      return { name: current.name || 'Procedural Action', fps, duration: 2.5, totalFrames, times, mode: 'procedural', sourceTiming: 'procedural-duration' };
    }
    return { name: baseName, fps: 30, duration: 0, totalFrames: 1, times: [0], mode: 'static', sourceTiming: 'static' };
  }
