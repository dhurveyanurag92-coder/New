const collisionVolumeCache = new Map();
const activeCollisionVolumes = [];

function buildCollisionVolumes(){
  activeCollisionVolumes.length = 0;
  if(!rig) return activeCollisionVolumes;
  const measurements = window.characterRuntime.getMeasurements();
  const dimensions = measurements ? measurements.dimensions : {};
  const volume = (id, group, startKey, endKey, radius, side = 'Center')=>{
    const startBone = rig.rest[startKey] && rig.rest[startKey].bone;
    const endBone = rig.rest[endKey] && rig.rest[endKey].bone;
    if(!startBone || !endBone) return null;
    let entry = collisionVolumeCache.get(id);
    if(!entry){
      entry = { id, group, side, start:new THREE.Vector3(), end:new THREE.Vector3(), radius:0 };
      collisionVolumeCache.set(id, entry);
    }
    startBone.getWorldPosition(entry.start); endBone.getWorldPosition(entry.end);
    entry.radius = Math.max(0.015, radius || 0.04);
    return entry;
  };
  for(const side of ['Left', 'Right']){
    const thigh = volume(side + 'Thigh', 'thigh', side + 'UpLeg', side + 'Leg', (dimensions.thighLength || 0.4) * 0.12, side);
    const shin = volume(side + 'Shin', 'shin', side + 'Leg', side + 'Foot', (dimensions.shinLength || 0.4) * 0.09, side);
    const upperArm = volume(side + 'UpperArm', 'arm', side + 'Arm', side + 'ForeArm', (dimensions.upperArmLength || 0.3) * 0.10, side);
    const forearm = volume(side + 'ForeArm', 'arm', side + 'ForeArm', side + 'Hand', (dimensions.forearmLength || 0.3) * 0.08, side);
    if(thigh) activeCollisionVolumes.push(thigh);
    if(shin) activeCollisionVolumes.push(shin);
    if(upperArm) activeCollisionVolumes.push(upperArm);
    if(forearm) activeCollisionVolumes.push(forearm);
  }
  const torso = volume('Torso', 'torso', 'Hips', 'Spine2', (dimensions.shoulderWidth || 0.4) * 0.22);
  if(torso) activeCollisionVolumes.push(torso);
  const head = rig.rest.Head && rig.rest.Head.bone;
  if(head){
    let entry = collisionVolumeCache.get('Head');
    if(!entry){
      entry = { id:'Head', group:'head', side:'Center', start:new THREE.Vector3(), end:new THREE.Vector3(), radius:0 };
      collisionVolumeCache.set('Head', entry);
    }
    head.getWorldPosition(entry.start); entry.end.copy(entry.start);
    entry.radius = Math.max(0.04, (dimensions.height || 1.8) * 0.07);
    activeCollisionVolumes.push(entry);
  }
  return activeCollisionVolumes;
}