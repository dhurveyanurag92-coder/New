let collisionScratch = null;
const collisionCorrections = [];

function getCollisionScratch(){
  if(!collisionScratch){
    collisionScratch = { segment:new THREE.Vector3(), relative:new THREE.Vector3(), nearest:new THREE.Vector3(), offset:new THREE.Vector3() };
  }
  return collisionScratch;
}
function closestPointOnSegment(point, start, end, output){
  const scratch = getCollisionScratch();
  const segment = scratch.segment.copy(end).sub(start);
  const lengthSquared = segment.lengthSq();
  if(lengthSquared < 1e-10) return output.copy(start);
  const amount = Math.max(0, Math.min(1, scratch.relative.copy(point).sub(start).dot(segment) / lengthSquared));
  return output.copy(start).addScaledVector(segment, amount);
}

function resolveSelfCollisionTargets(targets, preserveCorrections = false){
  if(!preserveCorrections) collisionCorrections.length = 0;
  if(!targets.length) return;
  const volumes = buildCollisionVolumes();
  const scratch = getCollisionScratch();
  for(const target of targets){
    if(target.chain !== 'arm') continue;
    const point = new THREE.Vector3(target.position.x, target.position.y, target.position.z);
    for(const volume of volumes){
      if(volume.group === 'arm') continue;
      const nearest = closestPointOnSegment(point, volume.start, volume.end, scratch.nearest);
      const offset = scratch.offset.copy(point).sub(nearest);
      const minimumDistance = volume.radius + Math.max(0, target.contactClearance || 0);
      if(offset.length() >= minimumDistance) continue;
      if(offset.lengthSq() < 1e-10){
        const hand = rig.rest[target.side + 'Hand'];
        const frames = window.characterRuntime.getCoordinateFrames();
        const contactFrame = hand && frames ? frames.get(hand.bone) : null;
        offset.copy(contactFrame ? contactFrame.world.forward : new THREE.Vector3(0, 0, 1));
      }
      offset.normalize().multiplyScalar(minimumDistance);
      point.copy(nearest).add(offset);
      collisionCorrections.push({ side:target.side, volume:volume.id, correction:minimumDistance });
    }
    target.position.x = point.x;
    target.position.y = point.y;
    target.position.z = point.z;
  }
}

window.selfCollisionRuntime = {
  beginPass(){ collisionCorrections.length = 0; },
  resolveTargets: resolveSelfCollisionTargets,
  lastCorrections: collisionCorrections,
};