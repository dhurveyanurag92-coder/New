let motionModelProvider = null;

function setMotionModelProvider(provider){
  if(provider != null && typeof provider !== 'function') throw new TypeError('Motion model provider must be a function.');
  motionModelProvider = provider;
}

async function requestMotionPrior(input){
  if(!motionModelProvider) throw new Error('No optional motion model provider is configured.');
  const pose = await motionModelProvider(input);
  return window.referencePoseRuntime.map(pose, { space:input && input.space, minimumConfidence:input && input.minimumConfidence });
}

window.motionModelAdapter = { setProvider:setMotionModelProvider, requestPrior:requestMotionPrior };