const CONTROL_BONE_ROLES = {
  Hips: ['Pelvis', 'Center'], Spine: ['Spine', 'Center'], Neck: ['Neck', 'Center'], Head: ['Head', 'Center'],
  LeftShoulder: ['Shoulder', 'Left'], RightShoulder: ['Shoulder', 'Right'],
  LeftArm: ['UpperArm', 'Left'], RightArm: ['UpperArm', 'Right'],
  LeftForeArm: ['ForeArm', 'Left'], RightForeArm: ['ForeArm', 'Right'],
  LeftHand: ['Hand', 'Left'], RightHand: ['Hand', 'Right'],
  LeftUpLeg: ['Thigh', 'Left'], RightUpLeg: ['Thigh', 'Right'],
  LeftLeg: ['Shin', 'Left'], RightLeg: ['Shin', 'Right'],
  LeftFoot: ['Foot', 'Left'], RightFoot: ['Foot', 'Right'],
  LeftToeBase: ['Toes', 'Left'], RightToeBase: ['Toes', 'Right'],
};

function retargetSkeletonToControlRig(registry, controlKeys){
  const records = registry ? registry.bones.filter(record=>!record.isAuxiliaryClone) : [];
  const chestRecords = (registry && registry.byRole.get('Chest') || []).filter(record=>!record.isAuxiliaryClone)
    .sort((a, b)=>a.hierarchyDepth - b.hierarchyDepth);
  const bones = {}, details = {}, used = new Set();
  for(const key of controlKeys){
    let record = records.find(candidate=>!used.has(candidate.bone) && candidate.normalizedName === normName(key));
    if(!record && (key === 'Spine1' || key === 'Spine2')) record = chestRecords.find(candidate=>!used.has(candidate.bone));
    if(!record){
      const [role, side] = CONTROL_BONE_ROLES[key] || [];
      if(role) record = records.find(candidate=>!used.has(candidate.bone) && candidate.semanticRole === role && candidate.side === side);
    }
    if(!record) continue;
    bones[key] = record.bone;
    details[key] = {
      originalName:record.originalName,
      semanticRole:record.semanticRole,
      side:record.side,
      confidence:record.mappingConfidence,
      method:record.normalizedName === normName(key) ? 'exact-name' : 'semantic-role',
    };
    used.add(record.bone);
  }
  return { bones, details, missing:controlKeys.filter(key=>!bones[key]) };
}

function mapRetargetBones(sourceRegistry, targetRegistry, heightRatio){
  const sources = sourceRegistry.bones.filter(record=>!record.isAuxiliaryClone).slice()
    .sort((left, right)=>left.hierarchyDepth - right.hierarchyDepth);
  const targets = targetRegistry.bones.filter(record=>!record.isAuxiliaryClone);
  const mapping = new Map();
  const usedTargets = new Set();
  const sourceToTarget = new Map();
  const assign = (source, target, method, confidence)=>{
    usedTargets.add(target.bone);
    sourceToTarget.set(source.originalName, target);
    mapping.set(source, { target, method, confidence });
  };
  for(const source of sources){
    const target = targets.find(candidate=>!usedTargets.has(candidate.bone) && candidate.normalizedName === source.normalizedName);
    if(target) assign(source, target, 'normalized-name', 1);
  }
  for(const source of sources){
    if(mapping.has(source) || !source.semanticRole) continue;
    const target = targets.find(candidate=>!usedTargets.has(candidate.bone)
      && candidate.semanticRole === source.semanticRole && candidate.side === source.side);
    if(target) assign(source, target, 'semantic-role', Math.min(1, Number(source.mappingConfidence) || 0.8));
  }
  for(const source of sources){
    if(mapping.has(source)) continue;
    let bestTarget = null;
    let bestScore = Infinity;
    for(const candidate of targets){
      if(usedTargets.has(candidate.bone)) continue;
      let score = Math.abs(source.hierarchyDepth - candidate.hierarchyDepth) * 1.1;
      const sourceChildren = source.children ? source.children.length : 0;
      const targetChildren = candidate.children ? candidate.children.length : 0;
      score += Math.abs(sourceChildren - targetChildren) * 0.8;
      if(source.parent && sourceToTarget.has(source.parent)){
        const expectedParent = sourceToTarget.get(source.parent);
        score += candidate.parent === expectedParent.originalName ? -2 : 1.5;
      }
      if(source.boneLength > 1e-5 && candidate.boneLength > 1e-5){
        score += Math.abs(Math.log((source.boneLength * heightRatio) / candidate.boneLength)) * 0.75;
      }
      if(source.semanticRole && candidate.semanticRole && source.semanticRole !== candidate.semanticRole) score += 3;
      if(source.side !== 'Center' && candidate.side !== 'Center' && source.side !== candidate.side) score += 2;
      if(score < bestScore){ bestScore = score; bestTarget = candidate; }
    }
    if(bestTarget && bestScore <= 3.75){
      assign(source, bestTarget, 'hierarchy-structure', Math.max(0.35, Math.min(0.75, 1 - bestScore / 5)));
    }
  }
  return mapping;
}

function retargetAnimationClip(clip, sourceRegistry, targetRegistry, options = {}){
  if(!clip || !Array.isArray(clip.tracks)) throw new Error('A valid AnimationClip is required.');
  if(!sourceRegistry || !targetRegistry) throw new Error('Source and target skeleton registries are required.');
  const sourceRecords = sourceRegistry.bones.filter(record=>!record.isAuxiliaryClone);
  const targetRecords = targetRegistry.bones.filter(record=>!record.isAuxiliaryClone);
  const heightRatio = Math.max(0.1, Math.min(10, Number(options.heightRatio) || 1));
  const boneMapping = mapRetargetBones(sourceRegistry, targetRegistry, heightRatio);
  const mappedTracks = [], skippedTracks = [];
  for(const sourceTrack of clip.tracks){
    const parsed = THREE.PropertyBinding.parseTrackName(sourceTrack.name);
    const candidateNames = [parsed.nodeName, parsed.objectName, ...sourceTrack.name.split(/[|/:.()[\]]+/).reverse()]
      .filter(name=>typeof name === 'string' && name.length);
    let sourceRecord = null;
    for(const name of candidateNames){
      const normalized = normName(name);
      sourceRecord = sourceRecords.find(record=>record.normalizedName === normalized);
      if(sourceRecord) break;
    }
    if(!sourceRecord){ skippedTracks.push({ name:sourceTrack.name, reason:'Unmapped source node' }); continue; }
    const match = boneMapping.get(sourceRecord);
    const targetRecord = match && match.target;
    if(!targetRecord){ skippedTracks.push({ name:sourceTrack.name, reason:'No target semantic bone' }); continue; }

    const property = parsed.propertyName;
    const values = new Float32Array(sourceTrack.values.length);
    const sourceRestPosition = sourceRecord.restPosition;
    const targetRestPosition = targetRecord.restPosition;
    const sourceRestScale = sourceRecord.restScale;
    const targetRestScale = targetRecord.restScale;
    const sourceRestRotation = sourceRecord.restRotation;
    const targetRestRotation = targetRecord.restRotation;
    const sourceRestWorld = sourceRecord.restWorldRotation;
    const targetRestWorld = targetRecord.restWorldRotation;
    const sourceInverse = sourceRestRotation.clone().invert();
    const sourceWorldInverse = sourceRestWorld.clone().invert();
    const targetWorldInverse = targetRestWorld.clone().invert();
    const sourceDelta = new THREE.Quaternion();
    const worldDelta = new THREE.Quaternion();
    const targetDelta = new THREE.Quaternion();
    const sourceEuler = new THREE.Euler(0, 0, 0, sourceRecord.bone.rotation.order);
    const targetEuler = new THREE.Euler(0, 0, 0, targetRecord.bone.rotation.order);
    const positionOffset = new THREE.Vector3();
    const step = sourceTrack.getValueSize();
    const supportedTransform = (property === 'quaternion' && step === 4)
      || ((property === 'rotation' || property === 'position' || property === 'scale') && step === 3);
    if(!supportedTransform){
      skippedTracks.push({ name:sourceTrack.name, reason:'Unsupported transform property' });
      continue;
    }
    for(let index = 0; index < sourceTrack.values.length; index += step){
      if(property === 'quaternion' && step === 4){
        const sourceRotation = new THREE.Quaternion(sourceTrack.values[index], sourceTrack.values[index + 1], sourceTrack.values[index + 2], sourceTrack.values[index + 3]);
        sourceDelta.copy(sourceInverse).multiply(sourceRotation);
        worldDelta.copy(sourceRestWorld).multiply(sourceDelta).multiply(sourceWorldInverse);
        targetDelta.copy(targetWorldInverse).multiply(worldDelta).multiply(targetRestWorld);
        const result = targetRestRotation.clone().multiply(targetDelta).normalize();
        values.set([result.x, result.y, result.z, result.w], index);
      } else if(property === 'rotation' && step === 3){
        sourceEuler.set(sourceTrack.values[index], sourceTrack.values[index + 1], sourceTrack.values[index + 2], sourceRecord.bone.rotation.order);
        const sourceRotation = new THREE.Quaternion().setFromEuler(sourceEuler);
        sourceDelta.copy(sourceInverse).multiply(sourceRotation);
        worldDelta.copy(sourceRestWorld).multiply(sourceDelta).multiply(sourceWorldInverse);
        targetDelta.copy(targetWorldInverse).multiply(worldDelta).multiply(targetRestWorld);
        const result = targetRestRotation.clone().multiply(targetDelta).normalize();
        targetEuler.setFromQuaternion(result, targetRecord.bone.rotation.order);
        values.set([targetEuler.x, targetEuler.y, targetEuler.z], index);
      } else if(property === 'position' && step === 3){
        positionOffset.set(
          sourceTrack.values[index] - sourceRestPosition.x,
          sourceTrack.values[index + 1] - sourceRestPosition.y,
          sourceTrack.values[index + 2] - sourceRestPosition.z,
        ).applyQuaternion(sourceRestWorld).multiplyScalar(heightRatio).applyQuaternion(targetWorldInverse);
        values[index] = targetRestPosition.x + positionOffset.x;
        values[index + 1] = targetRestPosition.y + positionOffset.y;
        values[index + 2] = targetRestPosition.z + positionOffset.z;
      } else if(property === 'scale' && step === 3){
        values[index] = targetRestScale.x * sourceTrack.values[index] / (sourceRestScale.x || 1);
        values[index + 1] = targetRestScale.y * sourceTrack.values[index + 1] / (sourceRestScale.y || 1);
        values[index + 2] = targetRestScale.z * sourceTrack.values[index + 2] / (sourceRestScale.z || 1);
      }
    }
    const track = sourceTrack.clone();
    track.name = targetRecord.originalName + '.' + parsed.propertyName;
    track.values = values;
    mappedTracks.push(track);
  }
  if(!mappedTracks.length) throw new Error('No animation tracks matched the target skeleton.');
  return {
    clip:new THREE.AnimationClip(clip.name, clip.duration, mappedTracks, clip.blendMode),
    mappedTrackCount:mappedTracks.length,
    skippedTracks,
    boneMapping:[...boneMapping].map(([source, match])=>({
      sourceName:source.originalName,
      targetName:match.target.originalName,
      role:source.semanticRole,
      side:source.side,
      method:match.method,
      confidence:match.confidence,
    })),
  };
}