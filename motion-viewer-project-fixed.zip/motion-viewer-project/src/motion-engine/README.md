# Motion Engine

Owns reusable procedural-motion solving modules that sit between high-level actions and character pose application.

- `constraints/joint-limits.js`: conservative local controller-delta limits for known Mixamo joints.
- `ik/two-bone-ik.js`: reusable proportion-aware two-bone chain solver for arm/leg targets.
- `ik/chain-solver.js`: iterative CCD for arbitrary registered bone chains.
- `ik/full-body-ik.js`: per-frame prioritized target queue with configurable solver passes.
- `feet/foot-grounding.js`: opt-in stance spread and foot-anchor targets solved through the leg chains.
- `body/pelvis-solver.js`: coordinate-frame-aware pelvis translation and rotation controls.
- `body/balance-solver.js`: approximate COM/support-margin report and bounded grounded-pose pelvis correction.
- `body/head-target.js`: weighted world-space look target blended with the current head pose.
- `ik/knee-solver.js`: character-forward/outward pole direction for leg chains.
- `contact/hand-placement.js`: parameterized hand targets for estimated body-surface contact, with queryable target metadata.
- `collision/`: approximate torso/limb capsules and pre-IK hand-target penetration correction.
- `pose/pose-generator.js`: high-level tired crouch/hand-contact pose command.
- `pose/pose-transition.js`: eased bone/holder interpolation when changing selected actions.
- `pose/pose-validation.js`: on-demand and opt-in per-frame report for constraint, target, stretch, foot, balance, and collision state.
- `motion/breathing.js`: reusable low-amplitude chest/head breathing layer.
- `actions/action-compiler.js`: JSON Action DSL parser/compiler/registrar for existing motion commands.
- `retarget/motion-retargeter.js`: semantic controller mapping plus imported AnimationClip track retargeting between registered humanoid skeletons.
- `debug/solver-inspector.js`: serializable rig, measurements, targets, limits, balance, collision, and validation snapshot for Motion Analysis.
- `debug/solver-visualizer.js`: opt-in axes, IK target, COM, and support-line overlays.
- `performance/solver-metrics.js`: opt-in solve timing, target count, and iteration metrics; collision capsules are pooled and reused.
- `reference/reference-mapper.js`: landmark-to-limb-target adapter; pose-estimation itself is intentionally external.
- `ai/motion-model-adapter.js`: optional provider interface whose output passes through reference mapping before use.

The current limits are a first-pass safety clamp. IK currently solves limb targets only; per-character constraint calibration, feet/contact, balance, and collision remain later phases.