const REFERENCE_LANDMARK_TARGETS = {
  leftWrist:['arm', 'Left'], rightWrist:['arm', 'Right'],
  leftAnkle:['leg', 'Left'], rightAnkle:['leg', 'Right'],
  nose:['head', 'Center'],
};

function mapReferencePose(pose, options = {}){
  const landmarks = pose && pose.landmarks ? pose.landmarks : pose;
  if(!landmarks || typeof landmarks !== 'object') throw new Error('Reference pose must contain a landmarks object.');
  const normalized = options.space === 'normalized';
  const scale = normalized ? (window.characterRuntime.getMeasurements()?.dimensions.height || 1.8) : 1;
  const frames = window.characterRuntime.getCoordinateFrames();
  const pelvis = window.characterRuntime.getSkeletonRegistry().find('Pelvis');
  const pelvisFrame = pelvis && frames.get(pelvis.bone);
  const origin = pelvisFrame ? pelvisFrame.origin : new THREE.Vector3();
  const axes = pelvisFrame ? pelvisFrame.world : {
    up:new THREE.Vector3(0, 1, 0),
    forward:new THREE.Vector3(0, 0, 1),
    outside:new THREE.Vector3(1, 0, 0),
  };
  const targets = [];
  for(const [landmarkName, value] of Object.entries(landmarks)){
    const targetDefinition = REFERENCE_LANDMARK_TARGETS[landmarkName];
    if(!targetDefinition || !value || ![value.x, value.y, value.z].every(Number.isFinite)) continue;
    const confidence = Number(value.confidence ?? value.score ?? 1);
    if(confidence < (options.minimumConfidence ?? 0.25)) continue;
    const position = normalized
      ? origin.clone().addScaledVector(axes.outside, value.x * scale).addScaledVector(axes.up, value.y * scale).addScaledVector(axes.forward, value.z * scale)
      : new THREE.Vector3(value.x, value.y, value.z);
    targets.push({ landmark:landmarkName, chain:targetDefinition[0], side:targetDefinition[1], position:{x:position.x,y:position.y,z:position.z}, confidence });
  }
  return { space:normalized ? 'normalized-character' : 'world', targets, unsupported:Object.keys(landmarks).filter(name=>!REFERENCE_LANDMARK_TARGETS[name]) };
}

function queueReferencePose(pose, options = {}){
  const mapped = mapReferencePose(pose, options);
  const current = window.motionRuntime.getCurrent();
  if(current && current.imported) return { ...mapped, applied:false, reason:'Imported clips are not yet blended with procedural reference targets.' };
  for(const target of mapped.targets){
    window.fullBodyIK.queueExternal({ ...target, poleHint:target.chain === 'leg' ? getKneePoleHint(target.side) : 'down-out', priority:options.priority ?? 15, weight:target.confidence });
  }
  window.motionRuntime.evaluatePose(window.motionRuntime.getTime(), 0);
  return { ...mapped, applied:true };
}

function applyReferencePoseToAction(controller, pose, options = {}){
  const mapped = mapReferencePose(pose, options);
  for(const target of mapped.targets){
    if(target.chain === 'head'){
      controller.target('head', 'Center', target.position, { priority:options.priority ?? 15, weight:target.confidence });
      continue;
    }
    controller.target(target.chain, target.side, target.position, {
      poleHint:target.chain === 'leg' ? getKneePoleHint(target.side) : 'down-out',
      priority:options.priority ?? 15,
      weight:target.confidence,
    });
  }
  return mapped;
}

Object.assign(ctrl, { referencePose:applyReferencePoseToAction });
window.referencePoseRuntime = { map:mapReferencePose, queue:queueReferencePose, apply:applyReferencePoseToAction };