function applyBreathingMotion(controller, time, intensity = 1, base = {}){
  const amplitude = Math.max(0, Math.min(1, intensity));
  const cycle = Math.sin(time * Math.PI * 2 * 0.72);
  controller.torso((base.torsoLean || 0) + cycle * 0.08 * amplitude, cycle * 0.025 * amplitude);
  controller.head(-(base.headDown || 0) + cycle * 0.025 * amplitude, cycle * 0.02 * amplitude);
}