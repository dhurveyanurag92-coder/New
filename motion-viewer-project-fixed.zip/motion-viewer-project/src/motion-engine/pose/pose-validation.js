let poseValidationEnabled = false;
let lastPoseValidationReport = null;

function validateCurrentPose(){
  if(!rig){
    lastPoseValidationReport = {
      valid:false,
      status:'No supported procedural rig is mapped for this character.',
      jointLimitViolations:[], targetErrors:[], stretchViolations:[], footErrors:[],
      balance:window.balanceRuntime.getReport(), collisionCorrections:[],
    };
    return lastPoseValidationReport;
  }
  const limitViolations = [];
  for(const [boneName, delta] of Object.entries(ctrl._d)){
    const constrained = clampJointDelta(boneName, delta);
    const excess = delta.map((value, index)=>Math.abs(value - constrained[index]));
    if(excess.some(value=>value > 1e-5)) limitViolations.push({ bone:boneName, excess });
  }
  const targetErrors = window.fullBodyIK.getLastTargets().map(target=>({
    chain:target.chain,
    side:target.side,
    boneKey:target.boneKey || null,
    error:target.error,
    positionError:target.positionError,
    rotationError:target.rotationError,
    unreachable:target.unreachable,
    stretchFactor:target.stretchFactor,
  }));
  const stretchViolations = [];
  for(const side of ['Left', 'Right']){
    for(const [lengthsKey, startKey, middleKey, endKey] of [
      ['armLengths', side + 'Arm', side + 'ForeArm', side + 'Hand'],
      ['legLengths', side + 'UpLeg', side + 'Leg', side + 'Foot'],
    ]){
      const lengths = rig[lengthsKey] && rig[lengthsKey][side];
      if(!lengths || !rig.rest[endKey]) continue;
      const start = new THREE.Vector3(), middle = new THREE.Vector3(), end = new THREE.Vector3();
      rig.rest[startKey].bone.getWorldPosition(start); rig.rest[middleKey].bone.getWorldPosition(middle); rig.rest[endKey].bone.getWorldPosition(end);
      const actual = start.distanceTo(middle) + middle.distanceTo(end);
      if(actual > lengths.total * 1.02) stretchViolations.push({ chain:lengthsKey, side, actual, available:lengths.total });
    }
  }
  const supportPoints = window.footGroundingRuntime.getSupportPoints();
  const footErrors = [];
  for(const side of ['Left', 'Right']){
    const bone = rig.rest[side + 'Foot'] && rig.rest[side + 'Foot'].bone;
    const anchor = supportPoints[side === 'Left' ? 0 : 1];
    if(!bone || !anchor) continue;
    const point = new THREE.Vector3(); bone.getWorldPosition(point);
    footErrors.push({ side, penetration:Math.max(0, anchor.y - point.y), slip:Math.hypot(anchor.x - point.x, anchor.z - point.z) });
  }
  const balance = window.balanceRuntime.getReport();
  const collisions = window.selfCollisionRuntime.lastCorrections.slice();
  lastPoseValidationReport = {
    valid: !limitViolations.length && !stretchViolations.length && targetErrors.every(result=>!result.unreachable && (result.error == null || result.error < 0.05))
      && footErrors.every(result=>result.penetration < 0.01 && result.slip < 0.03),
    jointLimitViolations:limitViolations,
    targetErrors,
    stretchViolations,
    footErrors,
    balance,
    collisionCorrections:collisions,
  };
  return lastPoseValidationReport;
}

window.poseValidationRuntime = {
  inspect:validateCurrentPose,
  getLastReport:()=>lastPoseValidationReport,
  get enabled(){ return poseValidationEnabled; },
  set enabled(value){ poseValidationEnabled = !!value; },
  capture(){ if(poseValidationEnabled) validateCurrentPose(); },
};