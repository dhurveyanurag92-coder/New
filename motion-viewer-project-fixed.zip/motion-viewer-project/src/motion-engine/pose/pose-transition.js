const POSE_TRANSITION_SECONDS = 0.35;
let activePoseTransition = null;

function capturePoseSnapshot(){
  const registry = window.characterRuntime && window.characterRuntime.getSkeletonRegistry();
  if(!registry || !holder) return null;
  return {
    bones: registry.bones.filter(record=>!record.isAuxiliaryClone).map(record=>({
      bone:record.bone,
      position:record.bone.position.clone(),
      quaternion:record.bone.quaternion.clone(),
      targetPosition:new THREE.Vector3(),
      targetQuaternion:new THREE.Quaternion(),
    })),
    holderPosition:holder.position.clone(),
    holderRotation:holder.quaternion.clone(),
    targetHolderPosition:new THREE.Vector3(),
    targetHolderRotation:new THREE.Quaternion(),
  };
}

function beginPoseTransition(duration = POSE_TRANSITION_SECONDS){
  const from = capturePoseSnapshot();
  activePoseTransition = from ? { from, duration:Math.max(0.05, duration), elapsed:0 } : null;
}

function updatePoseTransition(deltaTime){
  if(!activePoseTransition) return;
  const transition = activePoseTransition;
  transition.elapsed += Math.max(0, deltaTime || 0);
  const amount = Math.min(1, transition.elapsed / transition.duration);
  const eased = amount * amount * (3 - 2 * amount);
  for(const entry of transition.from.bones){
    const { bone, position, quaternion, targetPosition, targetQuaternion } = entry;
    targetPosition.copy(bone.position);
    targetQuaternion.copy(bone.quaternion);
    bone.position.copy(position).lerp(targetPosition, eased);
    bone.quaternion.slerpQuaternions(quaternion, targetQuaternion, eased);
  }
  transition.from.targetHolderPosition.copy(holder.position);
  transition.from.targetHolderRotation.copy(holder.quaternion);
  holder.position.copy(transition.from.holderPosition).lerp(transition.from.targetHolderPosition, eased);
  holder.quaternion.slerpQuaternions(transition.from.holderRotation, transition.from.targetHolderRotation, eased);
  if(amount >= 1) activePoseTransition = null;
}