function degreesToRadians(value){ return (Number(value) || 0) * Math.PI / 180; }

function generateTiredPose(controller, options = {}){
  const thighBend = degreesToRadians(options.thighBend ?? 10);
  const kneeBend = degreesToRadians(options.kneeBend ?? 25);
  const torsoLean = degreesToRadians(options.torsoLean ?? 70);
  const headDown = degreesToRadians(options.headDown ?? 10);
  const feetSpread = Math.max(0, Number(options.feetSpread ?? 0.14));
  controller.feet.spread(feetSpread);
  controller.feet.grounded(options.grounded !== false);
  controller.pelvis({ hipDrop:options.hipDrop ?? 0.12, hipBack:options.hipBack ?? 0.05 });
  for(const side of ['Left', 'Right']){
    controller.leg(side, thighBend, kneeBend, 0);
    controller.arm(side, 0, 0.35, 0.3);
  }
  controller.torso(torsoLean, 0);
  controller.head(-headDown, 0);
  if(options.handContact !== false){
    controller.handsOnKnees({ surface:true, clearance:0.015, outwardOffset:0.02, forwardOffset:0.02, ...(options.handContact || {}) });
  }
  if(Number(options.breathingIntensity) > 0){
    applyBreathingMotion(controller, Number(options.time) || 0, Number(options.breathingIntensity), { torsoLean, headDown });
  }
}

Object.assign(ctrl, { tiredPose(options){ generateTiredPose(this, options); } });