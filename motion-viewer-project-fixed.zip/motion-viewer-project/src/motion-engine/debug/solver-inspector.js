function solverVector(value){ return value ? { x:value.x, y:value.y, z:value.z } : null; }
function solverQuaternion(value){ return value ? { x:value.x, y:value.y, z:value.z, w:value.w } : null; }

function inspectSolverState(){
  const registry = window.characterRuntime.getSkeletonRegistry();
  const mapping = window.characterRuntime.getRigMapping();
  const coordinateFrames = window.characterRuntime.getCoordinateFrames();
  const controlDetails = mapping ? mapping.details : {};
  const bones = registry ? registry.bones.map(record=>{
    const control = Object.entries(controlDetails).find(([, detail])=>detail.originalName === record.originalName);
    const currentPosition = new THREE.Vector3(), currentRotation = new THREE.Quaternion();
    record.bone.getWorldPosition(currentPosition); record.bone.getWorldQuaternion(currentRotation);
    const frame = coordinateFrames && coordinateFrames.get(record.bone);
    return {
      originalName:record.originalName,
      normalizedName:record.normalizedName,
      semanticRole:record.semanticRole,
      mappingStatus:record.mappingStatus,
      mappingConfidence:record.mappingConfidence,
      controlBone:control ? control[0] : null,
      controlMapping:control ? control[1] : null,
      parent:record.parent,
      children:record.children,
      hierarchyDepth:record.hierarchyDepth,
      side:record.side,
      chain:record.chain,
      boneLength:record.boneLength,
      restPosition:solverVector(record.restPosition),
      restRotation:solverQuaternion(record.restRotation),
      worldPosition:solverVector(currentPosition),
      worldRotation:solverQuaternion(currentRotation),
      axes:frame ? Object.fromEntries(Object.entries(frame.world).map(([axis, vector])=>[axis, solverVector(vector)])) : null,
      jointLimits:control ? window.jointLimitRuntime.getLimits(control[0]) : null,
      isAuxiliaryClone:record.isAuxiliaryClone,
    };
  }) : [];
  return {
    mapping:{ mapped:Object.keys(controlDetails).length, missing:mapping ? mapping.missing.slice() : [] },
    measurements:window.characterRuntime.getMeasurements(),
    bones,
    ikTargets:window.fullBodyIK.getLastTargets(),
    solverReport:window.fullBodyIK.getLastReport(),
    handContacts:window.handContactRuntime.getTargets(),
    collisionCorrections:window.selfCollisionRuntime.lastCorrections.slice(),
    balance:window.balanceRuntime.getReport(),
    validation:window.poseValidationRuntime.getLastReport(),
    performance:window.motionEnginePerformance.getSnapshot(),
  };
}

window.solverInspector = { inspect:inspectSolverState };