let solverVisualizationEnabled = false;
let visualizationModel = null;
let axisHelpers = [];
let targetMarkers = [];
let targetGeometry = null;
let targetMaterial = null;
let centerMarker = null;
let supportLine = null;
let collisionLines = [];
let collisionLineMaterial = null;

function disposeSolverHelpers(scene){
  axisHelpers.forEach(({ helper })=>{
    scene.remove(helper);
    helper.geometry.dispose();
    (Array.isArray(helper.material) ? helper.material : [helper.material]).forEach(material=>material.dispose());
  });
  targetMarkers.forEach(marker=>scene.remove(marker));
  if(targetGeometry) targetGeometry.dispose();
  if(targetMaterial) targetMaterial.dispose();
  if(centerMarker){ scene.remove(centerMarker); centerMarker.geometry.dispose(); centerMarker.material.dispose(); }
  if(supportLine){ scene.remove(supportLine); supportLine.geometry.dispose(); supportLine.material.dispose(); }
  collisionLines.forEach(line=>{ scene.remove(line); line.geometry.dispose(); });
  if(collisionLineMaterial) collisionLineMaterial.dispose();
  axisHelpers = []; targetMarkers = []; centerMarker = null; supportLine = null; visualizationModel = null;
  targetGeometry = null; targetMaterial = null; collisionLines = []; collisionLineMaterial = null;
}

function createSolverHelpers(scene, model){
  if(visualizationModel === model) return;
  disposeSolverHelpers(scene);
  visualizationModel = model;
  const registry = window.characterRuntime.getSkeletonRegistry();
  for(const record of registry.bones){
    if(record.isAuxiliaryClone || !record.semanticRole) continue;
    const helper = new THREE.AxesHelper(0.08);
    helper.renderOrder = 10;
    scene.add(helper); axisHelpers.push({ helper, bone:record.bone });
  }
  targetGeometry = new THREE.SphereGeometry(0.035, 8, 6);
  targetMaterial = new THREE.MeshBasicMaterial({ color:0xe24a3b, depthTest:false });
  for(let index = 0; index < 8; index++){
    const marker = new THREE.Mesh(targetGeometry, targetMaterial);
    marker.visible = false; marker.renderOrder = 11; scene.add(marker); targetMarkers.push(marker);
  }
  centerMarker = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color:0x168f69, depthTest:false }));
  centerMarker.visible = false; centerMarker.renderOrder = 12; scene.add(centerMarker);
  const lineGeometry = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
  supportLine = new THREE.Line(lineGeometry, new THREE.LineBasicMaterial({ color:0x168f69, depthTest:false }));
  supportLine.visible = false; supportLine.renderOrder = 12; scene.add(supportLine);
  collisionLineMaterial = new THREE.LineBasicMaterial({ color:0xe29a32, depthTest:false });
  for(const volume of buildCollisionVolumes()){
    const geometry = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    const line = new THREE.Line(geometry, collisionLineMaterial);
    line.renderOrder = 11; scene.add(line); collisionLines.push(line);
  }
}

function updateSolverVisualization(){
  if(!solverVisualizationEnabled) return;
  const scene = window.viewerRuntime.getScene();
  const model = window.characterRuntime.getModel();
  if(!scene || !model) return;
  createSolverHelpers(scene, model);
  for(const entry of axisHelpers){
    entry.bone.getWorldPosition(entry.helper.position);
    entry.bone.getWorldQuaternion(entry.helper.quaternion);
  }
  const targets = window.fullBodyIK.getLastTargets();
  targetMarkers.forEach((marker, index)=>{
    const target = targets[index];
    marker.visible = !!target;
    if(target) marker.position.set(target.position.x, target.position.y, target.position.z);
  });
  const balance = window.balanceRuntime.getReport();
  centerMarker.visible = !!(balance.enabled && balance.centerOfMass);
  if(centerMarker.visible) centerMarker.position.set(balance.centerOfMass.x, balance.centerOfMass.y, balance.centerOfMass.z);
  const supports = window.footGroundingRuntime.getSupportPoints();
  supportLine.visible = supports.length >= 2;
  if(supportLine.visible){
    const positions = supportLine.geometry.attributes.position;
    positions.setXYZ(0, supports[0].x, supports[0].y, supports[0].z);
    positions.setXYZ(1, supports[1].x, supports[1].y, supports[1].z);
    positions.needsUpdate = true;
    supportLine.geometry.computeBoundingSphere();
  }
  const volumes = buildCollisionVolumes();
  collisionLines.forEach((line, index)=>{
    const volume = volumes[index];
    line.visible = !!volume;
    if(!volume) return;
    const positions = line.geometry.attributes.position;
    positions.setXYZ(0, volume.start.x, volume.start.y, volume.start.z);
    positions.setXYZ(1, volume.end.x, volume.end.y, volume.end.z);
    positions.needsUpdate = true;
    line.geometry.computeBoundingSphere();
  });
}

const debugToggle = document.getElementById('solverDebugToggle');
debugToggle.addEventListener('click', ()=>{
  solverVisualizationEnabled = !solverVisualizationEnabled;
  debugToggle.setAttribute('aria-pressed', String(solverVisualizationEnabled));
  debugToggle.textContent = solverVisualizationEnabled ? 'Rig Debug: On' : 'Rig Debug';
  if(!solverVisualizationEnabled){
    const scene = window.viewerRuntime.getScene();
    if(scene && visualizationModel) disposeSolverHelpers(scene);
  }
});
window.solverVisualization = { get enabled(){ return solverVisualizationEnabled; }, update:updateSolverVisualization };