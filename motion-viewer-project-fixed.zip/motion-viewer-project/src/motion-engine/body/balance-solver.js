const BALANCE_MASS_WEIGHTS = [
  ['Hips', 0.28], ['Spine', 0.18], ['Spine1', 0.16], ['Spine2', 0.13], ['Neck', 0.04], ['Head', 0.07],
  ['LeftArm', 0.025], ['RightArm', 0.025], ['LeftForeArm', 0.015], ['RightForeArm', 0.015],
  ['LeftUpLeg', 0.025], ['RightUpLeg', 0.025], ['LeftLeg', 0.01], ['RightLeg', 0.01],
];
let lastBalanceReport = { enabled:false, stable:null, correction:{x:0,z:0} };

function getApproximateCenterOfMass(){
  if(!rig) return null;
  const total = new THREE.Vector3();
  let totalWeight = 0;
  for(const [key, weight] of BALANCE_MASS_WEIGHTS){
    const entry = rig.rest[key];
    if(!entry) continue;
    const point = new THREE.Vector3();
    entry.bone.getWorldPosition(point);
    total.addScaledVector(point, weight);
    totalWeight += weight;
  }
  return totalWeight ? total.multiplyScalar(1 / totalWeight) : null;
}

function applyBalanceSolver(){
  const supports = ctrl._groundFeet ? window.footGroundingRuntime.getSupportPoints() : [];
  const centerOfMass = getApproximateCenterOfMass();
  if(!centerOfMass || supports.length < 2){
    lastBalanceReport = { enabled:false, stable:null, correction:{x:0,z:0} };
    return;
  }
  const supportCenter = supports.reduce((sum, point)=>sum.add(point), new THREE.Vector3()).multiplyScalar(1 / supports.length);
  const offset = new THREE.Vector3(supportCenter.x - centerOfMass.x, 0, supportCenter.z - centerOfMass.z);
  const distance = offset.length();
  const margin = Math.max(0.04, (window.characterRuntime.getMeasurements()?.dimensions.height || 1.8) * 0.035);
  const correctionMagnitude = Math.min(0.06, Math.max(0, distance - margin) * 0.45);
  const correction = new THREE.Vector3();
  const pelvisFrame = window.characterRuntime.getCoordinateFrames().get(rig.rest.Hips.bone);
  if(correctionMagnitude > 0 && pelvisFrame){
    correction.copy(offset).normalize().multiplyScalar(correctionMagnitude);
    ctrl._pelvis.hipSide += correction.dot(pelvisFrame.world.outside);
    ctrl._pelvis.hipBack += correction.dot(pelvisFrame.world.backward);
  }
  lastBalanceReport = {
    enabled:true,
    stable: distance <= margin,
    centerOfMass:{ x:centerOfMass.x, y:centerOfMass.y, z:centerOfMass.z },
    supportCenter:{ x:supportCenter.x, y:supportCenter.y, z:supportCenter.z },
    supportMargin:margin,
    offset:distance,
    correction:{ x:correction.x, z:correction.z },
  };
}

window.balanceRuntime = {
  getReport: () => ({ ...lastBalanceReport, correction:{ ...lastBalanceReport.correction } }),
};