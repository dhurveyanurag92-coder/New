function resetPelvisFrame(){ ctrl._pelvis = { hipDrop:0, hipBack:0, hipSide:0, rotation:{x:0,y:0,z:0} }; }

function applyPelvisSolver(){
  if(!rig || !rig.rest.Hips) return;
  const options = ctrl._pelvis;
  const hips = rig.rest.Hips;
  const record = window.characterRuntime.getSkeletonRegistry().byObject.get(hips.bone);
  const frame = window.characterRuntime.getCoordinateFrames().get(hips.bone);
  const parentRotation = new THREE.Quaternion();
  if(hips.bone.parent) hips.bone.parent.getWorldQuaternion(parentRotation);
  parentRotation.invert();
  const displacement = new THREE.Vector3()
    .addScaledVector(frame.world.down, options.hipDrop)
    .addScaledVector(frame.world.backward, options.hipBack)
    .addScaledVector(frame.world.outside, options.hipSide)
    .applyQuaternion(parentRotation);
  hips.bone.position.copy(record.restPosition).add(displacement);
}

function solvePelvisPositionTarget(target){
  if(!rig || !rig.rest.Hips) return { solved:false, error:null };
  applyPelvisSolver();
  holder.updateMatrixWorld(true);
  const hips = rig.rest.Hips.bone;
  const position = new THREE.Vector3();
  hips.getWorldPosition(position);
  const desired = new THREE.Vector3(target.position.x, target.position.y, target.position.z);
  const delta = desired.sub(position).multiplyScalar(Math.max(0, Math.min(1, target.weight)));
  if(delta.length() > 0.18) delta.setLength(0.18);
  const frame = window.characterRuntime.getCoordinateFrames().get(hips);
  if(frame){
    ctrl._pelvis.hipDrop += delta.dot(frame.world.down);
    ctrl._pelvis.hipBack += delta.dot(frame.world.backward);
    ctrl._pelvis.hipSide += delta.dot(frame.world.outside);
    applyPelvisSolver();
    holder.updateMatrixWorld(true);
    hips.getWorldPosition(position);
  }
  return { solved:true, error:position.distanceTo(new THREE.Vector3(target.position.x, target.position.y, target.position.z)) };
}

Object.assign(ctrl, {
  pelvis(options = {}){
    const rotation = options.rotation || {};
    ctrl._pelvis = {
      hipDrop: Number(options.hipDrop) || 0,
      hipBack: Number(options.hipBack) || 0,
      hipSide: Number(options.hipSide) || 0,
      rotation: {
        x: Number(options.tilt ?? rotation.x) || 0,
        y: Number(rotation.y) || 0,
        z: Number(rotation.z) || 0,
      },
    };
  },
});