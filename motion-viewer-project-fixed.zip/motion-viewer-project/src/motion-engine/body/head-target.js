function solveHeadLookTarget(target){
  const boneKey = rig.rest.Head ? 'Head' : rig.rest.Neck ? 'Neck' : null;
  if(!boneKey) return false;
  const bone = rig.rest[boneKey].bone;
  const position = new THREE.Vector3();
  bone.getWorldPosition(position);
  const direction = new THREE.Vector3(target.position.x, target.position.y, target.position.z).sub(position);
  if(direction.lengthSq() < 1e-10) return false;
  direction.normalize();
  const currentWorld = new THREE.Quaternion();
  bone.getWorldQuaternion(currentWorld);
  const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(currentWorld);
  const desiredWorld = new THREE.Quaternion().setFromUnitVectors(forward, direction).multiply(currentWorld);
  const blendedWorld = currentWorld.clone().slerp(desiredWorld, Math.max(0, Math.min(1, target.weight)));
  return setBoneWorldQuaternion(boneKey, blendedWorld);
}