const ACTION_DSL_COMMANDS = new Set(['run', 'transitionTo', 'tiredPose', 'handsOnKnees', 'pant', 'useMotion']);

function createActionPoseBuffer(controller){
  const buffer = Object.create(controller);
  buffer._d = {};
  buffer.lift = 0;
  buffer._pelvis = { hipDrop:0, hipBack:0, hipSide:0, rotation:{x:0,y:0,z:0} };
  buffer._groundFeet = false;
  buffer._footSpread = 0;
  buffer._handContact = null;
  buffer._rootMotion = null;
  buffer.feet = {
    grounded:enabled=>{ buffer._groundFeet = !!enabled; },
    spread:width=>{ buffer._footSpread = Math.max(0, Number(width) || 0); },
  };
  buffer.pelvis = options=>{
    const rotation = options.rotation || {};
    buffer._pelvis = {
      hipDrop:Number(options.hipDrop) || 0,
      hipBack:Number(options.hipBack) || 0,
      hipSide:Number(options.hipSide) || 0,
      rotation:{ x:Number(options.tilt ?? rotation.x) || 0, y:Number(rotation.y) || 0, z:Number(rotation.z) || 0 },
    };
  };
  buffer.handsOnKnees = options=>{ buffer._handContact = options || {}; };
  buffer.rootMotion = value=>{ buffer._rootMotion = value || null; };
  return buffer;
}

function sampleActionPose(controller, action, time, deltaTime){
  const buffer = createActionPoseBuffer(controller);
  action.update(buffer, time, deltaTime);
  return buffer;
}

function blendActionPose(controller, source, target, amount){
  const mix = (from, to)=>from + (to - from) * amount;
  controller._d = {};
  for(const name of new Set([...Object.keys(source._d), ...Object.keys(target._d)])){
    const from = source._d[name] || [0, 0, 0];
    const to = target._d[name] || [0, 0, 0];
    controller.set(name, mix(from[0], to[0]), mix(from[1], to[1]), mix(from[2], to[2]));
  }
  controller.lift = mix(source.lift, target.lift);
  controller.pelvis({
    hipDrop:mix(source._pelvis.hipDrop, target._pelvis.hipDrop),
    hipBack:mix(source._pelvis.hipBack, target._pelvis.hipBack),
    hipSide:mix(source._pelvis.hipSide, target._pelvis.hipSide),
    rotation:{
      x:mix(source._pelvis.rotation.x, target._pelvis.rotation.x),
      y:mix(source._pelvis.rotation.y, target._pelvis.rotation.y),
      z:mix(source._pelvis.rotation.z, target._pelvis.rotation.z),
    },
  });
  controller.feet.grounded(amount < 0.5 ? source._groundFeet : target._groundFeet);
  controller.feet.spread(mix(source._footSpread, target._footSpread));
  if(target._handContact) controller.handsOnKnees({ ...target._handContact, weight:mix(Number(source._handContact && source._handContact.weight) || 0, Number(target._handContact.weight ?? 1) * amount) });
  if(source._rootMotion||target._rootMotion){
    const from=source._rootMotion||target._rootMotion;
    const to=target._rootMotion||source._rootMotion;
    const position={ x:mix(from.position.x,to.position.x),y:mix(from.position.y,to.position.y),z:mix(from.position.z,to.position.z) };
    const rotation=new THREE.Quaternion(...from.rotation).slerp(new THREE.Quaternion(...to.rotation),amount);
    controller.rootMotion({ position,rotation:[rotation.x,rotation.y,rotation.z,rotation.w] });
  }
}

function parseActionDsl(input){
  const definition = typeof input === 'string' ? JSON.parse(input) : input;
  if(!definition || typeof definition.name !== 'string' || !definition.name.trim()) throw new Error('Action DSL needs a name.');
  if(!Array.isArray(definition.steps) || !definition.steps.length) throw new Error('Action DSL needs at least one step.');
  const steps = definition.steps.map((step, index)=>{
    if(!step || !ACTION_DSL_COMMANDS.has(step.command)) throw new Error('Unsupported Action DSL command at step ' + (index + 1) + '.');
    const learned=step.command==='useMotion'&&window.motionLearningRuntime
      ? window.motionLearningRuntime.find(step.motionId||step.motion||step.action)
      : null;
    if(step.command==='useMotion'&&!learned) throw new Error('Action DSL references unknown Motion Knowledge.');
    const duration = Number(step.duration)||Number(learned&&learned.duration);
    if(!Number.isFinite(duration) || duration <= 0) throw new Error('Each Action DSL step needs a positive duration.');
    const action = step.fromAction || step.action || 'Run';
    if((step.command === 'run' || step.command === 'transitionTo') && !actions.has(action)) throw new Error('Action DSL references an unknown source action.');
    if(step.command === 'transitionTo' && (step.targetPose || 'tiredPose') !== 'tiredPose') throw new Error('transitionTo currently supports tiredPose as its target.');
    return { command:step.command, action, motionId:learned&&learned.id, targetPose:step.targetPose || 'tiredPose', duration, options:step.options || {} };
  });
  return {
    name:definition.name.trim(),
    category:definition.category || 'Custom',
    aliases:Array.isArray(definition.aliases) ? definition.aliases : [],
    steps,
    duration:steps.reduce((total, step)=>total + step.duration, 0),
    learnedMotion:steps.some(step=>step.command==='useMotion'),
  };
}

function compileActionDsl(input){
  const definition = parseActionDsl(input);
  return {
    name:definition.name,
    category:definition.category,
    duration:definition.duration,
    aliases:definition.aliases,
    update(controller, time, deltaTime){
      let elapsed = ((time % definition.duration) + definition.duration) % definition.duration;
      const step = definition.steps.find(candidate=>{
        if(elapsed < candidate.duration) return true;
        elapsed -= candidate.duration;
        return false;
      }) || definition.steps[definition.steps.length - 1];
      if(step.command === 'run'){
        actions.get(step.action).update(controller, elapsed, deltaTime);
      } else if(step.command === 'transitionTo'){
        const amount = Math.max(0, Math.min(1, elapsed / step.duration));
        const eased = amount * amount * (3 - 2 * amount);
        const source = sampleActionPose(controller, actions.get(step.action), Number(step.options.sourceTime || 0) + elapsed, deltaTime);
        const target = sampleActionPose(controller, { update(buffer, poseTime){ buffer.tiredPose({ ...step.options, time:poseTime }); } }, elapsed, deltaTime);
        blendActionPose(controller, source, target, eased);
      } else if(step.command === 'tiredPose'){
        controller.tiredPose({ ...step.options, time:elapsed });
      } else if(step.command === 'handsOnKnees'){
        controller.handsOnKnees(step.options);
      } else if(step.command === 'pant'){
        if(step.options.basePose){
          controller.tiredPose({ ...step.options.basePose, time:elapsed, breathingIntensity:step.options.intensity ?? 0.8 });
        } else {
          applyBreathingMotion(controller, elapsed, step.options.intensity ?? 0.8, step.options.base || {});
        }
      } else if(step.command === 'useMotion'){
        const cycleCount=Math.floor(Math.max(0,time)/definition.duration);
        const sample=window.motionLearningRuntime.sample(step.motionId,elapsed,step.duration,cycleCount);
        if(!sample) return;
        for(const [key,value] of Object.entries(sample.controls)) controller.set(key,value[0],value[1],value[2]);
        controller.rootMotion(sample.rootMotion);
        if(sample.activeContacts.some(contact=>contact.type.endsWith('-foot-ground'))) controller.feet.grounded(true);
        if(sample.activeContacts.some(contact=>contact.type.endsWith('-hand-knee'))){
          controller.handsOnKnees({ surface:true,clearance:0.015,outwardOffset:0.02,forwardOffset:0.02,weight:1 });
        }
      }
    },
  };
}

function registerActionDsl(input){
  const action = compileActionDsl(input);
  registerAction(action, false);
  buildChips();
  return action;
}

window.actionCompiler = { parse:parseActionDsl, compile:compileActionDsl, register:registerActionDsl };