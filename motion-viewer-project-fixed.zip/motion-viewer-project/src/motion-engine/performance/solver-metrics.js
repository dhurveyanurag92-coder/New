let solverMetricsEnabled = false;
let solverMetrics = { solves:0, targets:0, totalMilliseconds:0, maximumMilliseconds:0, iterations:0 };

function startSolverMetric(){ return solverMetricsEnabled ? performance.now() : 0; }
function finishSolverMetric(start, targetCount, iterationCount){
  if(!solverMetricsEnabled) return;
  const elapsed = performance.now() - start;
  solverMetrics.solves++;
  solverMetrics.targets += targetCount;
  solverMetrics.iterations += iterationCount;
  solverMetrics.totalMilliseconds += elapsed;
  solverMetrics.maximumMilliseconds = Math.max(solverMetrics.maximumMilliseconds, elapsed);
}

window.motionEnginePerformance = {
  get enabled(){ return solverMetricsEnabled; },
  set enabled(value){ solverMetricsEnabled = !!value; },
  getSnapshot(){
    return { ...solverMetrics, averageMilliseconds:solverMetrics.solves ? solverMetrics.totalMilliseconds / solverMetrics.solves : 0 };
  },
  reset(){ solverMetrics = { solves:0, targets:0, totalMilliseconds:0, maximumMilliseconds:0, iterations:0 }; },
};