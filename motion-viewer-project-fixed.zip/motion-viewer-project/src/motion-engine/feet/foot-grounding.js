let footGroundingState = { active: false, anchors: {} };

function resetFootGroundingFrame(){
  ctrl._groundFeet = false;
  ctrl._footSpread = 0;
}

function queueGroundedFootTargets(){
  if(!ctrl._groundFeet || !rig){
    footGroundingState = { active: false, anchors: {} };
    return;
  }
  holder.updateMatrixWorld(true);
  const frames = window.characterRuntime.getCoordinateFrames();
  if(!footGroundingState.active){
    const anchors = {};
    for(const side of ['Left', 'Right']){
      const contact = rig.contacts.find(item=>item.bone === rig.rest[side + 'Foot'].bone);
      const bone = rig.rest[side + 'Foot'].bone;
      const base = new THREE.Vector3();
      bone.getWorldPosition(base);
      const frame = frames && frames.get(bone);
      anchors[side] = { bone, base, outside:frame ? frame.world.outside.clone() : new THREE.Vector3(side === 'Left' ? 1 : -1, 0, 0), y:contact ? contact.off : 0 };
    }
    footGroundingState = { active: true, anchors };
  }
  for(const side of ['Left', 'Right']){
    const anchor = footGroundingState.anchors[side];
    if(!anchor) continue;
    const position = anchor.base.clone().addScaledVector(anchor.outside, ctrl._footSpread / 2);
    position.y = anchor.y;
    queueFullBodyIKTarget({
      chain: 'leg',
      side,
      position,
      priority: 20,
      weight: 1,
    });
  }
}

  function getFootSupportPoints(){
    return Object.entries(footGroundingState.anchors).map(([side, anchor])=>{
      const point = anchor.base.clone().addScaledVector(anchor.outside, ctrl._footSpread / 2);
      point.y = anchor.y;
      return point;
    });
  }

function detectFootContactState(frame){
  const bones = frame && frame.bones ? frame.bones : {};
  const leftFoot = bones.LeftFoot || bones['LeftFoot'];
  const rightFoot = bones.RightFoot || bones['RightFoot'];
  const result = { left: !!leftFoot, right: !!rightFoot, doubleSupport: !!(leftFoot && rightFoot) };
  if (leftFoot && rightFoot) result.type = 'double-support';
  else if (leftFoot) result.type = 'left-contact';
  else if (rightFoot) result.type = 'right-contact';
  else result.type = 'airborne';
  return result;
}

function detectFootSliding(frame, previousFrame){
  if (!frame || !previousFrame || !frame.bones || !previousFrame.bones) return [];
  const warnings = [];
  for (const side of ['LeftFoot', 'RightFoot']) {
    const current = frame.bones[side];
    const previous = previousFrame.bones[side];
    if (!current || !previous || !Array.isArray(current.position) || !Array.isArray(previous.position)) continue;
    const delta = Math.hypot(
      current.position[0] - previous.position[0],
      current.position[1] - previous.position[1],
      current.position[2] - previous.position[2]
    );
    if (delta > 0.08) {
      warnings.push('FOOT SLIDING WARNING at frame ' + (frame.number || 1) + ' for ' + side + ' (' + delta.toFixed(3) + ')');
    }
  }
  return warnings;
}

Object.assign(ctrl, {
  feet: {
    grounded(enabled = true){ ctrl._groundFeet = !!enabled; },
    spread(width){ ctrl._footSpread = Math.max(0, Number(width) || 0); },
  },
});
window.footGroundingRuntime = {
  getSupportPoints: getFootSupportPoints,
  detectFootContactState,
  detectFootSliding,
};