const JOINT_DEGREES_TO_RADIANS = Math.PI / 180;
const JOINT_LIMITS = {
  Hips: { x: [-45, 45], y: [-70, 70], z: [-45, 45] },
  Spine: { x: [-55, 55], y: [-45, 45], z: [-40, 40] },
  Spine1: { x: [-55, 55], y: [-45, 45], z: [-40, 40] },
  Spine2: { x: [-55, 55], y: [-45, 45], z: [-40, 40] },
  Neck: { x: [-60, 60], y: [-75, 75], z: [-50, 50] },
  Head: { x: [-60, 60], y: [-80, 80], z: [-50, 50] },
  LeftShoulder: { x: [-80, 80], y: [-70, 70], z: [-70, 70] },
  RightShoulder: { x: [-80, 80], y: [-70, 70], z: [-70, 70] },
  LeftArm: { x: [-150, 150], y: [-120, 120], z: [-120, 120] },
  RightArm: { x: [-150, 150], y: [-120, 120], z: [-120, 120] },
  LeftForeArm: { x: [-25, 25], y: [-155, 155], z: [-25, 25] },
  RightForeArm: { x: [-25, 25], y: [-155, 155], z: [-25, 25] },
  LeftUpLeg: { x: [-125, 125], y: [-70, 70], z: [-75, 75] },
  RightUpLeg: { x: [-125, 125], y: [-70, 70], z: [-75, 75] },
  LeftLeg: { x: [-5, 155], y: [-25, 25], z: [-25, 25] },
  RightLeg: { x: [-5, 155], y: [-25, 25], z: [-25, 25] },
  LeftFoot: { x: [-55, 55], y: [-45, 45], z: [-35, 35] },
  RightFoot: { x: [-55, 55], y: [-45, 45], z: [-35, 35] },
};

function clampJointDelta(boneName, delta){
  const limits = JOINT_LIMITS[boneName];
  if(!limits) return delta.map(value=>Math.max(-Math.PI, Math.min(Math.PI, value)));
  return ['x', 'y', 'z'].map((axis, index)=>{
    const [minimum, maximum] = limits[axis];
    return Math.max(minimum * JOINT_DEGREES_TO_RADIANS, Math.min(maximum * JOINT_DEGREES_TO_RADIANS, Number(delta[index]) || 0));
  });
}

window.jointLimitRuntime = {
  getLimits: boneName => JOINT_LIMITS[boneName] || null,
  clamp: clampJointDelta,
};