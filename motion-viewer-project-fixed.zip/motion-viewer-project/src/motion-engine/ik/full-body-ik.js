const FULL_BODY_IK = { iterations: 6, positionTolerance:0.012, rotationTolerance:0.035, priorityFalloff:0.05 };
let fullBodyIKTargets = [];
let lastFullBodyIKTargets = [];
let pendingExternalTargets = [];
let lastFullBodyIKReport = { iterations:0, converged:false, targets:[], conflicts:[], totalWeightedError:0 };
const CHAIN_JOINTS = {
  arm:side=>['Hips', 'Spine', 'Spine1', 'Spine2', side+'Shoulder', side+'Arm', side+'ForeArm', side+'Hand'],
  leg:side=>[side+'UpLeg', side+'Leg', side+'Foot', 'Hips'],
  spine:()=>['Hips', 'Spine', 'Spine1', 'Spine2', 'Neck', 'Head'],
  head:()=>['Neck', 'Head'],
  pelvis:()=>['Hips'],
};

function normalizeFullBodyIKTarget(target){
  if(!target || !['arm', 'leg', 'head', 'spine', 'pelvis', 'joint'].includes(target.chain)) return;
  if(['arm', 'leg'].includes(target.chain) && !['Left', 'Right'].includes(target.side)) return;
  if(target.chain === 'joint' && (!target.boneKey || !rig.rest[target.boneKey])) return;
  if(target.position && ![target.position.x, target.position.y, target.position.z].every(Number.isFinite)) return;
  if(target.rotation && ![target.rotation.x, target.rotation.y, target.rotation.z].every(Number.isFinite)) return;
  if(!target.position && !target.rotation) return;
  return {
    ...target,
    side:target.side || 'Center',
    priority:Number(target.priority) || 0,
    weight:Math.max(0, Math.min(1, Number(target.weight ?? 1))),
    bodyCoupling:Math.max(0, Math.min(1, Number(target.bodyCoupling ?? (target.chain === 'arm' ? 0.2 : 0.12)))),
    rotationSpace:target.rotationSpace === 'local' ? 'local' : 'world',
  };
}
function refreshFullBodyTarget(target){
  if(typeof target.positionProvider !== 'function') return;
  const updated = target.positionProvider();
  if(updated && updated.position) target.position = { ...updated.position };
  if(updated && updated.rotation) target.rotation = { ...updated.rotation };
}
function beginFullBodyIKFrame(){
  fullBodyIKTargets = pendingExternalTargets;
  pendingExternalTargets = [];
  lastFullBodyIKTargets = [];
  lastFullBodyIKReport = { iterations:0, converged:false, targets:[], conflicts:[], totalWeightedError:0 };
}
function queueFullBodyIKTarget(target){
  const normalized = normalizeFullBodyIKTarget(target);
  if(normalized) fullBodyIKTargets.push(normalized);
}
function queueExternalFullBodyIKTarget(target){
  const normalized = normalizeFullBodyIKTarget(target);
  if(normalized) pendingExternalTargets.push(normalized);
}
function getFullBodyTargetEnd(target){
  if(target.chain === 'arm') return rig.rest[target.side + 'Hand'] && rig.rest[target.side + 'Hand'].bone;
  if(target.chain === 'leg') return rig.rest[target.side + 'Foot'] && rig.rest[target.side + 'Foot'].bone;
  if(target.chain === 'head') return rig.rest.Head ? rig.rest.Head.bone : rig.rest.Neck && rig.rest.Neck.bone;
  if(target.chain === 'spine') return rig.rest.Head ? rig.rest.Head.bone : rig.rest.Spine2 && rig.rest.Spine2.bone;
  if(target.chain === 'pelvis') return rig.rest.Hips && rig.rest.Hips.bone;
  if(target.chain === 'joint') return rig.rest[target.boneKey] && rig.rest[target.boneKey].bone;
  return null;
}
function getJointChainKeys(boneKey){
  const end = rig.rest[boneKey] && rig.rest[boneKey].bone;
  if(!end) return [];
  const keys = [];
  for(let bone = end; bone; bone = bone.parent){
    if(!bone.isBone) continue;
    const controllerKey = Object.keys(rig.rest).find(key=>rig.rest[key].bone === bone);
    if(controllerKey) keys.push(controllerKey);
  }
  return keys.reverse();
}
function measureFullBodyTargetError(target){
  if(target.chain === 'head' && target.position){
    const head = rig.rest.Head ? rig.rest.Head.bone : rig.rest.Neck && rig.rest.Neck.bone;
    if(!head) return { error:Infinity, positionError:null, rotationError:Infinity, unreachable:true, stretchFactor:1 };
    const headPosition = new THREE.Vector3(), currentWorld = new THREE.Quaternion();
    head.getWorldPosition(headPosition); head.getWorldQuaternion(currentWorld);
    const desiredDirection = new THREE.Vector3(target.position.x, target.position.y, target.position.z).sub(headPosition).normalize();
    const currentDirection = new THREE.Vector3(0, 0, 1).applyQuaternion(currentWorld).normalize();
    const lookError = Math.acos(Math.max(-1, Math.min(1, currentDirection.dot(desiredDirection))));
    let rotationError = 0;
    if(target.rotation){
      const desired = resolveTargetRotation(target, head);
      rotationError = 2 * Math.acos(Math.max(-1, Math.min(1, Math.abs(currentWorld.dot(desired)))));
    }
    const reach = getTargetReach(target);
    const root = getTargetRoot(target), rootPosition = new THREE.Vector3();
    if(root) root.getWorldPosition(rootPosition);
    const distance = root ? rootPosition.distanceTo(new THREE.Vector3(target.position.x, target.position.y, target.position.z)) : 0;
    const stretchFactor = reach > 1e-6 ? distance / reach : 1;
    return { error:Math.hypot(lookError, rotationError), positionError:null, rotationError:Math.hypot(lookError, rotationError), unreachable:stretchFactor > 1.001, stretchFactor:Math.max(1, stretchFactor) };
  }
  const end = getFullBodyTargetEnd(target);
  if(!end) return { error:Infinity, positionError:Infinity, rotationError:null, unreachable:true, stretchFactor:Infinity };
  const position = new THREE.Vector3();
  end.getWorldPosition(position);
  const positionError = target.position ? position.distanceTo(new THREE.Vector3(target.position.x, target.position.y, target.position.z)) : 0;
  let rotationError = 0;
  if(target.rotation){
    const endWorld = new THREE.Quaternion(); end.getWorldQuaternion(endWorld);
    const desiredWorld = resolveTargetRotation(target, end);
    rotationError = 2 * Math.acos(Math.max(-1, Math.min(1, Math.abs(endWorld.dot(desiredWorld)))));
  }
  const reach = getTargetReach(target);
  const root = getTargetRoot(target);
  let distance = 0;
  if(root && target.position){
    const rootPosition = new THREE.Vector3(); root.getWorldPosition(rootPosition);
    distance = rootPosition.distanceTo(new THREE.Vector3(target.position.x, target.position.y, target.position.z));
  }
  const stretchFactor = reach > 1e-6 ? distance / reach : 1;
  const unreachable = target.position && reach > 0 ? stretchFactor > 1.001 || (target.minReach > 0 && distance < target.minReach) : false;
  return { error:Math.hypot(positionError, rotationError), positionError, rotationError:target.rotation ? rotationError : null, unreachable:!!unreachable, stretchFactor:Math.max(1, stretchFactor) };
}
function getTargetRoot(target){
  const key = target.chain === 'arm' ? target.side+'Arm' : target.chain === 'leg' ? target.side+'UpLeg' : target.chain === 'pelvis' ? 'Hips' : target.chain === 'head' ? (rig.rest.Neck ? 'Neck' : 'Head') : target.chain === 'joint' ? getJointChainKeys(target.boneKey)[0] : 'Hips';
  return rig.rest[key] && rig.rest[key].bone;
}
function getTargetReach(target){
  if(target.chain === 'arm' || target.chain === 'leg'){
    const lengths = rig[target.chain === 'arm' ? 'armLengths' : 'legLengths'] && rig[target.chain === 'arm' ? 'armLengths' : 'legLengths'][target.side];
    return lengths ? lengths.total : 0;
  }
  const keys = target.chain === 'spine' ? CHAIN_JOINTS.spine() : target.chain === 'head' ? CHAIN_JOINTS.head() : target.chain === 'joint' ? getJointChainKeys(target.boneKey) : [];
  return keys.reduce((sum, key)=>sum + (rig.rest[key] ? rig.rest[key].boneLength : 0), 0);
}
function resolveTargetRotation(target, bone){
  const rotation = target.rotation;
  const local = Number.isFinite(rotation.w)
    ? new THREE.Quaternion(rotation.x, rotation.y, rotation.z, rotation.w)
    : new THREE.Quaternion().setFromEuler(new THREE.Euler(rotation.x, rotation.y, rotation.z, 'XYZ'));
  if(target.rotationSpace === 'world') return local;
  const parentWorld = new THREE.Quaternion();
  if(bone.parent) bone.parent.getWorldQuaternion(parentWorld);
  return parentWorld.multiply(local);
}
function targetRotationBone(target){
  const key = target.chain === 'arm' ? target.side+'Hand' : target.chain === 'leg' ? target.side+'Foot' : target.chain === 'head' ? (rig.rest.Head ? 'Head' : 'Neck') : target.chain === 'spine' ? (rig.rest.Spine2 ? 'Spine2' : 'Spine') : target.chain === 'pelvis' ? 'Hips' : target.boneKey;
  return rig.rest[key] && rig.rest[key].bone;
}
function applyTargetRotation(target, influence){
  if(!target.rotation) return;
  const bone = targetRotationBone(target);
  if(!bone) return;
  const current = new THREE.Quaternion(); bone.getWorldQuaternion(current);
  const desired = resolveTargetRotation(target, bone);
  current.slerp(desired, influence);
  const boneKey = target.chain === 'joint' ? target.boneKey : Object.keys(rig.rest).find(key=>rig.rest[key].bone === bone);
  if(boneKey) setBoneWorldQuaternion(boneKey, current);
}
function getTargetPriorityInfluence(target, maximumPriority){
  return target.weight / (1 + Math.max(0, maximumPriority - target.priority) * FULL_BODY_IK.priorityFalloff);
}
function targetHasConverged(result){
  return (result.positionError == null || result.positionError <= FULL_BODY_IK.positionTolerance)
    && (result.rotationError == null || result.rotationError <= FULL_BODY_IK.rotationTolerance);
}
function normalizedTargetError(result){
  const position = result.positionError == null ? 0 : result.positionError / FULL_BODY_IK.positionTolerance;
  const rotation = result.rotationError == null ? 0 : result.rotationError / FULL_BODY_IK.rotationTolerance;
  return Math.hypot(position, rotation);
}
function targetsShareChain(first, second){
  const firstKeys = CHAIN_JOINTS[first.chain] && CHAIN_JOINTS[first.chain](first.side) || (first.chain === 'joint' ? getJointChainKeys(first.boneKey) : []);
  const secondKeys = CHAIN_JOINTS[second.chain] && CHAIN_JOINTS[second.chain](second.side) || (second.chain === 'joint' ? getJointChainKeys(second.boneKey) : []);
  return firstKeys.some(key=>secondKeys.includes(key));
}
function applyBodyCoupling(target){
  if(!target.position || target.bodyCoupling <= 1e-6 || !['arm', 'leg'].includes(target.chain)) return;
  const root = getTargetRoot(target);
  const reach = getTargetReach(target);
  if(!root || reach <= 1e-5) return;
  const rootPosition = new THREE.Vector3(); root.getWorldPosition(rootPosition);
  const offset = new THREE.Vector3(target.position.x, target.position.y, target.position.z).sub(rootPosition);
  const distance = offset.length();
  const extension = distance / reach;
  if(extension < 0.72) return;
  const correctionDistance = Math.min(0.025, (extension - 0.72) * 0.07) * target.bodyCoupling * target.influence;
  if(correctionDistance < 1e-5) return;
  const pelvis = rig.rest.Hips && rig.rest.Hips.bone;
  const frame = pelvis && window.characterRuntime.getCoordinateFrames().get(pelvis);
  if(!frame) return;
  offset.normalize().multiplyScalar(correctionDistance);
  ctrl._pelvis.hipDrop += offset.dot(frame.world.down);
  ctrl._pelvis.hipBack += offset.dot(frame.world.backward);
  ctrl._pelvis.hipSide += offset.dot(frame.world.outside);
  const maximumOffset = 0.16;
  ctrl._pelvis.hipDrop = Math.max(-maximumOffset, Math.min(maximumOffset, ctrl._pelvis.hipDrop));
  ctrl._pelvis.hipBack = Math.max(-maximumOffset, Math.min(maximumOffset, ctrl._pelvis.hipBack));
  ctrl._pelvis.hipSide = Math.max(-maximumOffset, Math.min(maximumOffset, ctrl._pelvis.hipSide));
  applyPelvisSolver();
  applyPose();
  holder.updateMatrixWorld(true);
}
function solveFullBodyIKTargets(){
  if(!fullBodyIKTargets.length) return;
  const metricStart = startSolverMetric();
  const targets = fullBodyIKTargets.slice().sort((a, b)=>b.priority - a.priority);
  const maximumPriority = targets[0].priority;
  for(const target of targets) target.influence = getTargetPriorityInfluence(target, maximumPriority);
  if(window.selfCollisionRuntime) window.selfCollisionRuntime.resolveTargets(targets);
  let previousError = Infinity;
  let iterationsUsed = 0;
  let converged = false;
  for(let iteration = 0; iteration < FULL_BODY_IK.iterations; iteration++){
    iterationsUsed++;
    if(window.selfCollisionRuntime) window.selfCollisionRuntime.beginPass();
    for(const target of targets){
      if(target.influence <= 1e-6) continue;
      refreshFullBodyTarget(target);
      applyBodyCoupling(target);
      refreshFullBodyTarget(target);
      if(window.selfCollisionRuntime) window.selfCollisionRuntime.resolveTargets([target], true);
      if(target.chain === 'head'){
        if(target.position) solveHeadLookTarget({ ...target, weight:target.influence });
        applyTargetRotation(target, target.influence);
        continue;
      }
      if(target.chain === 'spine'){
        if(target.position) solveCCDChain(CHAIN_JOINTS.spine(), target.position, target.influence);
        applyTargetRotation(target, target.influence);
        continue;
      }
      if(target.chain === 'pelvis'){
        if(target.position) solvePelvisPositionTarget({ ...target, weight:target.influence });
        applyTargetRotation(target, target.influence);
        continue;
      }
      if(target.chain === 'joint'){
        if(target.position) solveCCDChain(getJointChainKeys(target.boneKey), target.position, target.influence);
        applyTargetRotation(target, target.influence);
        continue;
      }
      const chain = target.chain === 'arm'
        ? { rootKey: target.side + 'Arm', middleKey: target.side + 'ForeArm', endKey: target.side + 'Hand', lengthsKey: 'armLengths', side: target.side }
        : { rootKey: target.side + 'UpLeg', middleKey: target.side + 'Leg', endKey: target.side + 'Foot', lengthsKey: 'legLengths', side: target.side };
      const poleHint = target.poleHint || (target.chain === 'leg' ? getKneePoleHint(target.side) : 'down-out');
      if(target.position) solveTwoBoneIK(chain, target.position, poleHint, target.influence);
      applyTargetRotation(target, target.influence);
    }
    const targetErrors = targets.map(target=>measureFullBodyTargetError(target));
    const totalError = targetErrors.reduce((sum, result, index)=>sum + normalizedTargetError(result) * targets[index].influence, 0);
    if(targetErrors.every(targetHasConverged)){ converged = true; break; }
    if(iteration > 0 && Math.abs(previousError - totalError) < 1e-4) break;
    previousError = totalError;
  }
  const results = targets.map(target=>{
    const error = measureFullBodyTargetError(target);
    return { ...target, position:target.position ? { ...target.position } : null, ...error };
  });
  const conflicts = [];
  for(let first = 0; first < results.length; first++){
    for(let second = first + 1; second < results.length; second++){
      if(targetsShareChain(results[first], results[second]) && (!targetHasConverged(results[first]) || !targetHasConverged(results[second]))){
        conflicts.push({ first:first, second:second, shared:true, priorityWinner:results[first].priority >= results[second].priority ? first : second });
      }
    }
  }
  lastFullBodyIKTargets = results;
  lastFullBodyIKReport = { iterations:iterationsUsed, converged, targets:results, conflicts, totalWeightedError:results.reduce((sum, result)=>sum + normalizedTargetError(result) * result.influence, 0) };
  finishSolverMetric(metricStart, targets.length, iterationsUsed);
}

window.fullBodyIK = {
  get iterations(){ return FULL_BODY_IK.iterations; },
  set iterations(value){ FULL_BODY_IK.iterations = Math.max(1, Math.min(8, Math.floor(value) || 1)); },
  getLastTargets:()=>lastFullBodyIKTargets.map(({ positionProvider, ...target })=>({ ...target, position:target.position ? { ...target.position } : null })),
  getLastReport:()=>({ ...lastFullBodyIKReport, targets:lastFullBodyIKReport.targets.map(({ positionProvider, ...target })=>({ ...target, position:target.position ? { ...target.position } : null })), conflicts:lastFullBodyIKReport.conflicts.map(conflict=>({ ...conflict })) }),
  queueExternal:queueExternalFullBodyIKTarget,
};