function solveTwoBoneIK(chain, target, poleHint, weight = 1){
  if(!rig || !chain || !target) return false;
  const lengths = rig[chain.lengthsKey] && rig[chain.lengthsKey][chain.side];
  const rootKey = chain.rootKey, middleKey = chain.middleKey, endKey = chain.endKey;
  if(!lengths || !rig.rest[rootKey] || !rig.rest[middleKey]) return false;
  const rootFrame = _boneFrame(rootKey);
  if(!rootFrame) return false;
  const start = rootFrame.pos;
  const targetPosition = new THREE.Vector3(target.x, target.y, target.z);
  if(weight < 1){
    const endPosition = new THREE.Vector3();
    (rig.rest[endKey] || rig.rest[middleKey]).bone.getWorldPosition(endPosition);
    targetPosition.lerp(endPosition, 1 - Math.max(0, weight));
  }
  const upperLength = Math.max(lengths.upper, 1e-4);
  const lowerLength = Math.max(lengths.fore, 1e-4);
  const toTarget = targetPosition.sub(start);
  let distance = toTarget.length();
  if(distance < 1e-5){ toTarget.set(0, -1, 0); distance = 1e-5; }
  const targetDirection = toTarget.normalize();
  const reachableDistance = clampN(distance, Math.abs(upperLength - lowerLength) + 1e-4 * (upperLength + lowerLength), upperLength + lowerLength - 1e-4 * (upperLength + lowerLength));
  const rootAngle = Math.acos(clampN((upperLength * upperLength + reachableDistance * reachableDistance - lowerLength * lowerLength) / (2 * upperLength * reachableDistance), -1, 1));
  const middleAngle = Math.acos(clampN((upperLength * upperLength + lowerLength * lowerLength - reachableDistance * reachableDistance) / (2 * upperLength * lowerLength), -1, 1));
  const sideSign = chain.side === 'Left' ? 1 : -1;
  const poleLocal = poleHint && typeof poleHint === 'object'
    ? new THREE.Vector3(poleHint.x || 0, poleHint.y || 0, poleHint.z || 0)
    : (POLE_HINTS[poleHint] || POLE_HINTS['down-out'])(sideSign);
  const poleWorld = poleLocal.normalize().applyQuaternion(rootFrame.parentQuat);
  let bendDirection = poleWorld.clone().sub(targetDirection.clone().multiplyScalar(poleWorld.dot(targetDirection)));
  if(bendDirection.lengthSq() < 1e-8){
    bendDirection.set(0, 0, 1).sub(targetDirection.clone().multiplyScalar(targetDirection.z));
  }
  bendDirection.normalize();
  const firstDirection = targetDirection.clone().multiplyScalar(Math.cos(rootAngle)).add(bendDirection.multiplyScalar(Math.sin(rootAngle))).normalize();
  _aimBone(rootKey, middleKey, firstDirection);
  const middlePosition = start.clone().add(firstDirection.clone().multiplyScalar(upperLength));
  const finalPosition = start.clone().add(targetDirection.clone().multiplyScalar(reachableDistance));
  const lastDirection = finalPosition.sub(middlePosition);
  if(lastDirection.lengthSq() > 1e-10 && rig.rest[endKey]) _aimBone(middleKey, endKey, lastDirection.normalize());
  else ctrl.set(middleKey, 0, -sideSign * (Math.PI - middleAngle), 0);
  return true;
}