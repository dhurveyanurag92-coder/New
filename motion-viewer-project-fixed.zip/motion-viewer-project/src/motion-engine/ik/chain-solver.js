function setBoneWorldQuaternion(jointKey, desiredWorldRotation){
  const entry = rig.rest[jointKey];
  if(!entry) return false;
  const parentWorld = new THREE.Quaternion();
  if(entry.bone.parent) entry.bone.parent.getWorldQuaternion(parentWorld);
  const parentDelta = parentWorld.multiply(entry.PrInv);
  const restLocal = entry.Pr.clone().multiply(entry.Lr);
  const controllerDelta = parentDelta.invert().multiply(desiredWorldRotation).multiply(restLocal.invert());
  const euler = new THREE.Euler().setFromQuaternion(controllerDelta, 'XYZ');
  ctrl.set(jointKey, euler.x, euler.y, euler.z);
  applyPose();
  holder.updateMatrixWorld(true);
  return true;
}

function solveCCDChain(boneKeys, target, weight = 1){
  const keys = boneKeys.filter(key=>rig.rest[key]);
  if(keys.length < 2) return { solved:false, error:null };
  const endBone = rig.rest[keys[keys.length - 1]].bone;
  const targetPosition = new THREE.Vector3(target.x, target.y, target.z);
  const endPosition = new THREE.Vector3();
  endBone.getWorldPosition(endPosition);
  targetPosition.lerp(endPosition, 1 - Math.max(0, Math.min(1, weight)));
  let error = Infinity;
  for(let pass = 0; pass < 2; pass++){
    for(let index = keys.length - 2; index >= 0; index--){
      applyPose(); holder.updateMatrixWorld(true);
      const joint = rig.rest[keys[index]].bone;
      const jointPosition = new THREE.Vector3();
      joint.getWorldPosition(jointPosition);
      endBone.getWorldPosition(endPosition);
      const currentDirection = endPosition.sub(jointPosition);
      const targetDirection = targetPosition.clone().sub(jointPosition);
      if(currentDirection.lengthSq() < 1e-10 || targetDirection.lengthSq() < 1e-10) continue;
      const correction = new THREE.Quaternion().setFromUnitVectors(currentDirection.normalize(), targetDirection.normalize());
      const currentRotation = new THREE.Quaternion();
      joint.getWorldQuaternion(currentRotation);
      setBoneWorldQuaternion(keys[index], correction.multiply(currentRotation));
    }
    endBone.getWorldPosition(endPosition);
    error = endPosition.distanceTo(targetPosition);
    if(error < 0.005) break;
  }
  return { solved:true, error };
}