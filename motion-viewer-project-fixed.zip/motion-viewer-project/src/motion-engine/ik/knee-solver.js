function getKneePoleHint(side, outwardBias = 0.2){
  const rootKey = side + 'UpLeg';
  const root = rig && rig.rest[rootKey];
  const frame = root && window.characterRuntime.getCoordinateFrames().get(root.bone);
  if(!frame) return { x:0, y:0, z:1 };
  const direction = frame.world.forward.clone().addScaledVector(frame.world.outside, outwardBias).normalize();
  const parentRotation = new THREE.Quaternion();
  if(root.bone.parent) root.bone.parent.getWorldQuaternion(parentRotation);
  direction.applyQuaternion(parentRotation.invert()).normalize();
  return { x:direction.x, y:direction.y, z:direction.z };
}