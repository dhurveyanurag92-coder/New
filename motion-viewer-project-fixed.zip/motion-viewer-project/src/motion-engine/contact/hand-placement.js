let handContactTargets = [];

function resetHandContactFrame(){ handContactTargets = []; }

function getKneeSurfaceTarget(side, config){
  const measurements = window.characterRuntime.getMeasurements();
  const thighLength = measurements && measurements.dimensions.thighLength || 0.4;
  const bone = rig.rest[side + 'Leg'] && rig.rest[side + 'Leg'].bone;
  const frames = window.characterRuntime.getCoordinateFrames();
  const frame = bone && frames && frames.get(bone);
  if(!bone) return null;
  const position = new THREE.Vector3();
  const rotation = new THREE.Quaternion();
  bone.getWorldPosition(position); bone.getWorldQuaternion(rotation);
  const localAxes = frame ? frame.local : {
    up:new THREE.Vector3(0, 1, 0),
    forward:new THREE.Vector3(0, 0, 1),
    outside:new THREE.Vector3(side === 'Left' ? 1 : -1, 0, 0),
  };
  const up = localAxes.up.clone().applyQuaternion(rotation).normalize();
  const forward = localAxes.forward.clone().applyQuaternion(rotation).normalize();
  const outside = localAxes.outside.clone().applyQuaternion(rotation).normalize();
  const surfaceRadius = config.surface === false ? 0 : Math.max(0.025, thighLength * 0.11);
  position.addScaledVector(up, Number(config.heightOffset) || 0);
  position.addScaledVector(forward, surfaceRadius + Math.max(0, Number(config.clearance) || 0) + (Number(config.forwardOffset) || 0) + Math.max(0, Math.min(1, Number(config.pressure) || 0)) * 0.01);
  position.addScaledVector(outside, Number(config.outwardOffset) || 0);
  const palmOffset = config.palmRotation
    ? new THREE.Quaternion().setFromEuler(new THREE.Euler(config.palmRotation.x || 0, config.palmRotation.y || 0, config.palmRotation.z || 0, 'XYZ'))
    : new THREE.Quaternion();
  rotation.multiply(palmOffset).normalize();
  return { position:{x:position.x,y:position.y,z:position.z}, rotation:{x:rotation.x,y:rotation.y,z:rotation.z,w:rotation.w} };
}

function queueHandsOnKnees(options = {}){
  const config = typeof options === 'string' ? { poleHint: options } : options;
  const clearance = Math.max(0, Number(config.clearance) || 0);
  for(const side of ['Left', 'Right']){
    const computed = getKneeSurfaceTarget(side, config);
    if(!computed) continue;
    handContactTargets.push({ side, targetPart:'knee', target:computed.position, rotation:computed.rotation, surface:config.surface !== false, clearance, pressure:config.pressure || 0 });
    queueFullBodyIKTarget({
      chain:'arm', side, position:computed.position, rotation:computed.rotation,
      positionProvider:()=>getKneeSurfaceTarget(side, config),
      poleHint:config.poleHint || 'down-out',
      priority:10,
      weight:Math.max(0, Math.min(1, Number(config.weight ?? 1))),
      bodyCoupling:Math.max(0, Math.min(1, Number(config.bodyCoupling ?? 0.35))),
      contactClearance:clearance,
    });
  }
}

Object.assign(ctrl, { handsOnKnees: queueHandsOnKnees });
window.handContactRuntime = { getTargets: () => handContactTargets.map(target=>({ ...target, target:{ ...target.target } })) };