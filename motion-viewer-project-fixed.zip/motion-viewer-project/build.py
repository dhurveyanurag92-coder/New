"""Assemble registered feature sources into a standalone page under dist/."""
import base64
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_FBX = sys.argv[1] if len(sys.argv) > 1 else "assets/characters/X_Bot.fbx"
MOTION_ORDER = {name: index for index, name in enumerate((
    "t-pose", "idle", "walk", "run", "tired", "jump", "wave"
))}
MOTION_MODULES = sorted(
    (
        path.relative_to(ROOT / "src").parts
        for path in (ROOT / "src" / "motion" / "motions").glob("*/motion.js")
    ),
    key=lambda parts: (
        MOTION_ORDER.get(Path(*parts).parent.name, len(MOTION_ORDER)),
        parts,
    ),
)


def read(*parts):
    return ROOT.joinpath(*parts).read_text(encoding="utf-8")


def join_sources(paths):
    return "\n".join(read("src", *path) for path in paths)


# Register a feature's assets here. Runtime phases preserve dependency order.
FEATURES = {
    "app": {
        "styles": [],
        "markup": {"host": ("literal", '<main id="pageHost" hidden></main>')},
        "runtime": {
            "start": [("app", "app-start.js")],
            "home": [("app", "home-page.js")],
            "init": [("app", "app-init.js")],
        },
    },
    "core": {
        "styles": [("core", "core.css")],
        "markup": {},
        "runtime": {
            "motion-data": [
                ("core", "motion-data", "frame-formatting.js"),
                ("core", "motion-data", "skeleton-records.js"),
                ("core", "motion-data", "frame-format.js"),
                ("core", "motion-data", "frame-timing.js"),
                ("core", "motion-data", "frame-sampling.js"),
                ("core", "motion-data", "motion-data-api.js"),
            ],
        },
    },
    "motion": {
        "styles": [("motion", "action-dialog.css"), ("motion", "motion.css")],
        "markup": {"dialogs": ("file", ("motion", "motion-dialogs.html"))},
        "runtime": {
            "registry": [("motion", "motion-registry.js")],
            "built-ins": MOTION_MODULES,
            "state": [("motion", "motion-state.js")],
            "storage": [("motion", "custom-storage.js"), ("motion", "pose-overrides.js")],
            "controls": [("motion", "motion-controls.js")],
            "pose": [("motion", "pose-engine.js")],
            "editors": [("motion", "action-editor.js"), ("motion", "pose-editor.js")],
        },
    },
    "character": {
        "styles": [],
        "markup": {},
        "runtime": {
            "state": [("character", "character-state.js")],
            "skeleton": [
                ("character", "skeleton-map.js"),
                ("character", "semantic-mapper.js"),
                ("character", "skeleton-registry.js"),
                ("character", "character-measurements.js"),
                ("character", "coordinate-frames.js"),
                ("character", "pose-controller.js"),
            ],
            "rig": [("character", "rig-setup.js"), ("character", "character-loader.js")],
        },
    },
    "motion-engine": {
        "styles": [],
        "markup": {},
        "runtime": {
            "constraints": [("motion-engine", "constraints", "joint-limits.js")],
            "ik": [
                ("motion-engine", "ik", "two-bone-ik.js"),
                ("motion-engine", "ik", "knee-solver.js"),
                ("motion-engine", "ik", "chain-solver.js"),
                ("motion-engine", "ik", "full-body-ik.js"),
            ],
            "feet": [("motion-engine", "feet", "foot-grounding.js")],
            "body": [
                ("motion-engine", "body", "pelvis-solver.js"),
                ("motion-engine", "body", "balance-solver.js"),
                ("motion-engine", "body", "head-target.js"),
            ],
            "contact": [("motion-engine", "contact", "hand-placement.js")],
            "pose": [
                ("motion-engine", "pose", "pose-transition.js"),
                ("motion-engine", "pose", "pose-generator.js"),
                ("motion-engine", "pose", "pose-validation.js"),
            ],
            "secondary": [("motion-engine", "motion", "breathing.js")],
            "actions": [("motion-engine", "actions", "action-compiler.js")],
            "retarget": [("motion-engine", "retarget", "motion-retargeter.js")],
            "reference": [("motion-engine", "reference", "reference-mapper.js")],
            "ai": [("motion-engine", "ai", "motion-model-adapter.js")],
            "debug": [
                ("motion-engine", "debug", "solver-inspector.js"),
                ("motion-engine", "debug", "solver-visualizer.js"),
            ],
            "collision": [
                ("motion-engine", "collision", "collision-volumes.js"),
                ("motion-engine", "collision", "self-collision.js"),
            ],
            "performance": [("motion-engine", "performance", "solver-metrics.js")],
        },
    },
    "viewer": {
        "styles": [("viewer", "viewer.css")],
        "markup": {"page": ("file", ("viewer", "viewer.html"))},
        "runtime": {
            "state": [("viewer", "viewer-state.js")],
            "runtime": [("viewer", "viewer-runtime.js")],
            "directions": [("viewer", "directions", "camera-directions.js")],
            "position": [("viewer", "camera-position.js")],
            "render": [("viewer", "render-loop.js")],
        },
    },
    "import": {
        "styles": [],
        "markup": {},
        "runtime": {
            "manager": [
                ("import", "import-validation.js"),
                ("import", "file-reader.js"),
                ("import", "import-manager.js"),
            ],
        },
    },
    "imported-motions": {
        "styles": [("imported-motions", "imported-motions.css")],
        "markup": {"page": ("template", "importedMotionsPageTpl", ("imported-motions", "page.html"))},
        "runtime": {
            "runtime": [
                ("imported-motions", "storage", "imported-motion-storage.js"),
                ("imported-motions", "analysis", "source-motion-analysis.js"),
                ("motion-learning", "motion-frame-sampler.js"),
                ("motion-learning", "motion-ir.js"),
                ("motion-learning", "motion-learning-runtime.js"),
                ("imported-motions", "parser", "fbx-motion-parser.js"),
                ("imported-motions", "animation-extractor", "animation-extractor.js"),
                ("imported-motions", "bone-mapper", "xbot-bone-mapper.js"),
                ("imported-motions", "retarget", "root-motion-retarget.js"),
                ("imported-motions", "retarget", "xbot-motion-retarget.js"),
                ("imported-motions", "registry", "imported-motion-registry.js"),
                ("imported-motions", "importer", "imported-motion-importer.js"),
                ("imported-motions", "imported-motions-page.js"),
            ],
        },
    },
    "menu": {
        "styles": [("menu", "menu.css")],
        "markup": {"page": ("file", ("menu", "menu.html"))},
        "runtime": {"runtime": [("menu", "menu.js")]},
    },
    "keyframe": {
        "styles": [("keyframe", "keyframe.css")],
        "markup": {"page": ("template", "keyframePageTpl", ("keyframe", "page.html"))},
        "runtime": {
            "page": [
                ("keyframe", "keyframe-state.js"),
                ("keyframe", "keyframe-accuracy.js"),
                ("keyframe", "keyframe-runtime.js"),
                ("keyframe", "frame-importer.js"),
            ],
        },
    },
    "frame-gallery": {
        "styles": [("frame-gallery", "frame-gallery.css")],
        "markup": {"page": ("template", "frameGalleryPageTpl", ("frame-gallery", "page.html"))},
        "runtime": {"page": [("frame-gallery", "frame-gallery.js")]},
    },
    "frame-profile": {
        "styles": [("frame-profile", "frame-profile.css")],
        "markup": {"page": ("template", "frameProfilePageTpl", ("frame-profile", "page.html"))},
        "runtime": {
            "page": [
                ("frame-profile", "profile-generator.js"),
            ],
        },
    },
    "frame-code": {
        "styles": [("frame-code", "frame-code.css")],
        "markup": {"page": ("template", "frameCodePageTpl", ("frame-code", "page.html"))},
        "runtime": {
            "page": [
                ("frame-code", "frame-code-state.js"),
                ("frame-code", "frame-export.js"),
                ("frame-code", "frame-renderer.js"),
                ("frame-code", "frame-code.js"),
            ],
        },
    },
    "motion-analysis": {
        "styles": [("motion-analysis", "motion-analysis.css")],
        "markup": {"page": ("template", "motionAnalysisPageTpl", ("motion-analysis", "motion-analysis.html"))},
        "runtime": {
            "page": [
                ("motion-analysis", "analysis-state.js"),
                ("motion-analysis", "analysis-math.js"),
                ("motion-analysis", "quaternion-analysis.js"),
                ("motion-analysis", "frame-analysis.js"),
                ("motion-analysis", "movement-analysis.js"),
                ("motion-analysis", "motion-quality.js"),
                ("motion-analysis", "analysis-engine.js"),
                ("motion-analysis", "analysis-renderer.js"),
                ("motion-analysis", "analysis-export.js"),
                ("motion-analysis", "analysis-events.js"),
            ],
        },
    },
    "export-glb": {
        "styles": [("export", "glb", "glb-export.css")],
        "markup": {},
        "runtime": {
            "page": [
                ("export", "glb", "glb-baker.js"),
                ("export", "glb", "glb-skeleton.js"),
                ("export", "glb", "glb-export.js"),
            ],
        },
    },
}

RUNTIME_ORDER = [
    ("app", "start"),
    ("motion", "registry"),
    ("motion", "built-ins"),
    ("character", "state"),
    ("motion", "state"),
    ("motion", "storage"),
    ("motion", "controls"),
    ("character", "skeleton"),
    ("viewer", "state"),
    ("viewer", "runtime"),
    ("viewer", "directions"),
    ("viewer", "position"),
    ("motion-engine", "retarget"),
    ("character", "rig"),
    ("motion-engine", "constraints"),
    ("motion-engine", "performance"),
    ("motion-engine", "ik"),
    ("motion-engine", "feet"),
    ("motion-engine", "body"),
    ("motion-engine", "contact"),
    ("motion-engine", "collision"),
    ("motion-engine", "pose"),
    ("motion-engine", "secondary"),
    ("motion-engine", "actions"),
    ("motion-engine", "debug"),
    ("motion-engine", "reference"),
    ("motion-engine", "ai"),
    ("motion", "pose"),
    ("viewer", "render"),
    ("import", "manager"),
    ("motion", "editors"),
    ("menu", "runtime"),
    ("imported-motions", "runtime"),
    ("app", "home"),
    ("core", "motion-data"),
    ("keyframe", "page"),
    ("frame-gallery", "page"),
    ("frame-profile", "page"),
    ("frame-code", "page"),
    ("motion-analysis", "page"),
    ("export-glb", "page"),
    ("app", "init"),
]
STYLE_ORDER = ["core", "viewer", "keyframe", "frame-gallery", "frame-profile", "frame-code", "motion-analysis", "motion", "imported-motions", "export-glb", "menu"]
MARKUP_ORDER = [
    ("viewer", "page"),
    ("app", "host"),
    ("menu", "page"),
    ("imported-motions", "page"),
    ("keyframe", "page"),
    ("frame-gallery", "page"),
    ("frame-profile", "page"),
    ("frame-code", "page"),
    ("motion-analysis", "page"),
    ("motion", "dialogs"),
]

template = read("src", "index.template.html")
all_styles = "\n".join(
    read("src", *path)
    for feature_name in STYLE_ORDER
    for path in FEATURES[feature_name]["styles"]
)
all_markup = []
for feature_name, asset_name in MARKUP_ORDER:
    entry = FEATURES[feature_name]["markup"][asset_name]
    if entry[0] == "file":
        all_markup.append(read("src", *entry[1]))
    elif entry[0] == "template":
        all_markup.append(f'<template id="{entry[1]}">\n{read("src", *entry[2])}</template>')
    else:
        all_markup.append(entry[1])
all_runtime = join_sources([
    path
    for feature_name, phase in RUNTIME_ORDER
    for path in FEATURES[feature_name]["runtime"][phase]
])
for marker, content in {
    "/*__FEATURE_CSS__*/": all_styles,
    "<!--__FEATURE_HTML__-->": "\n".join(all_markup),
    "/*__FEATURE_JS__*/": all_runtime,
}.items():
    if template.count(marker) != 1:
        raise ValueError(f"Expected one build marker: {marker}")
    template = template.replace(marker, content)

fbx_path = Path(DEFAULT_FBX)
if not fbx_path.is_absolute():
    fbx_path = ROOT / fbx_path
fbx_data = base64.b64encode(fbx_path.read_bytes()).decode("ascii")
template = template.replace(
    'const DEFAULT_NAME = "X_Bot.fbx";',
    f'const DEFAULT_NAME = "{fbx_path.name}";',
).replace("__FBX_B64__", fbx_data)

output = ROOT / "dist" / "index.html"
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(template, encoding="utf-8")
print(f"{os.path.relpath(output, ROOT)} written with {fbx_path.name}")
