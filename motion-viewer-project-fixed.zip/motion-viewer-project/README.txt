MOTION VIEWER
=============

Build and open
  Run: python build.py
  Open dist/index.html in Chrome, or serve the project over HTTP.
  Use python build.py MyCharacter.fbx to embed another FBX. The root index.html
  redirects to the generated dist page; source files stay under src/.

Feature map
  src/menu/                 Header, drawer, navigation and page registry API
  src/viewer/               Three.js scene, camera, controls and viewer markup
  src/character/             Character state, skeleton mapping, rig and pose controller
  src/import/                Character file validation, reading and import orchestration
  src/motion/motions/        One file per built-in motion
  src/motion/               Playback, custom actions and pose editing
  src/imported-motions/     FBX animation-only import, X_Bot retarget, IndexedDB registry and management page
  src/keyframe/              Keyframe pose editor and named motion saving
  src/frame-gallery/         Saved Keyframe motion library and playback
  src/frame-code/            Frame Code page, rendering and ZIP download
  src/motion-analysis/       Quaternion, frame/range, movement, engine, UI and export
  src/export/glb/            GLB animation baking and download page
  src/core/motion-data/      Shared frame sampling and data API
  src/app/                   App bootstrap and Home page registration

Pages register themselves with nav.registerPage({...}); the menu owns navigation
and does not contain page-specific behavior. build.py lists source modules and
assembles the standalone output into dist/ without overwriting root index.html.
build.py's FEATURES manifest is the central asset registry; each feature's page
registers through nav.registerPage({...}). See src/README.md for module ordering
and extension notes.

Existing controls remain: orbit/pinch camera, eight cardinal/diagonal camera views,
built-in and imported motions, custom actions and pose edits, Frame Code,
Keyframe editing and Frame Gallery playback, Motion Analysis, and
per-motion/all-motion/character-only GLB exports.
In Keyframe, use Copy AI Prompt to copy the loaded character's bone profile and
selected frame together, or Download AI Guide to save that same complete prompt
and model-specific information as a TXT file. Give the prompt/file to an AI,
describe the requested change, then paste the returned Frame Code back and
Validate Code before applying it. Frame Code must use the exact skeleton names
supplied by the profile.
The app loads Three.js and its loaders/exporter from jsDelivr, so internet access
is required. assets/characters/X_Bot.fbx is the default embedded character source.
